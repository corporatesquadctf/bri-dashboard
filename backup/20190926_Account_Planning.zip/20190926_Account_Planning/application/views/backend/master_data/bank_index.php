<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/2.0.16/jspdf.plugin.autotable.js"></script>
<style type="text/css">
    .cntrl {
        text-align: center;
    }

    .lft {
        text-align: left;
    }
    .fixed-table-container{
        border-top: none;
    }
    .dataTables_info , .dataTables_paginate{display: none;}

</style>


<div class="right_col" role="main">
    <div class="container">
        <!-- <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><i class="fa fa-plus"></i> <small>Add New Bank</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <form class="form-horizontal form-label-left cmxform" id="bankForm" method="GET">
                            <div class="form-group">
                                <label for="bankName" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Bank Name</label>
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <input type="hidden" id="currentUser" name="currentUser" value="<?php echo $_SESSION['USER_ID']; ?>">
                                    <input type="text" name="bankName" id="bankName" class="form-control" minlength="2" placeholder="Input new bank name here...">
                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-6 pull-right">
                                    <input type="button" class="btn btn-sm btn-danger" id="cancelBtn" value="Cancel" onclick="this.form.reset();">
                                    <input type="submit" class="btn btn-sm btn-success" value="Submit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div> -->

        <div class="row" id="indexDiv">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Banks</h2>
                        <div class="pull-right">
                            <button id="addBtn" class="btn btn-success btn-sm addBtn" type="button" data-toggle="modal" data-target="#add_">
                                <i class="fa fa-plus"></i>&nbsp;
                                <b>Add New</b>
                            </button>
                        </div>
                        <div class="clearfix"></div>
                    </div>

                    <div class="x_content">
                        <!-- <div id="toolbar">
                            <select class="form-control">
                                <option value="">Export Basic</option>
                                <option value="all" selected="true">Export All</option>
                                <option value="selected">Export Selected</option>
                            </select>
                        </div> -->
                        <table id="data1 section-to-print" data-toggle="table" data-pagination="true" data-search="true"
                               data-page-size="10"
                               data-page-list="[10, 50, ALL]"
                               data-toolbar="#toolbar"
                               data-click-to-select="true"
                               data-show-export="true"
                               data-export-options='{
                               "fileName": "MasterBank",
                               "ignoreColumn": [7]

                               }'
                               class="table table-condensed table-striped table-hover">
                            <thead style="background-color: #012D5A; color: #FFF;">
                                <tr>
                                    <th class="cntrl" data-sortable="true">No</th>
                                    <th class="lft" data-sortable="true">Bank Name</th>
                                    <th class="cntrl" data-sortable="true">Status</th>
                                    <th class="cntrl" data-sortable="true">Created On</th>
                                    <th class="cntrl">Created By</th>
                                    <th class="cntrl" data-sortable="true">Last Modified</th>
                                    <th class="cntrl">Modified By</th>
                                    <th class="cntrl">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($data as $k) :
                                    ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo $k->Name; ?></td>
                                        <td>
                                            <?php
                                            if ($k->IsActive == 1) {
                                                echo "Active";
                                            } else {
                                                echo "Not Active";
                                            };
                                            ?>
                                        </td>
                                        <td class="lft"><?php
                                            $addon = new DateTime($k->CreatedDate);
                                            echo $addon->format('d/m/Y H:i:s');
                                            ?></td>
                                        <td class="lft"><?php echo $k->MAKER; ?></td>
                                        <td class="cntrl"><?php
                                            $modion = $k->ModifiedDate;
                                            if ($modion) {
                                                $modifiedOn = new DateTime($modion);
                                                echo $modifiedOn->format('d/m/Y H:i:s');
                                            } else {
                                                echo '-';
                                            }
                                            ?></td>
                                        <td class="cntrl"><?php echo ($k->MODIFIER) ? $k->MODIFIER : '-'; ?></td>
                                        <td>
                                            <a href="#" class="btn btn-xs btn-info editBtn" data-toggle="modal" data-target="#modal_<?php echo $k->BankId; ?>" data-id="<?php echo $k->BankId; ?>">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL UPDATE -->
<div class="modal fade" id="add_" role="dialog">
    <div class="modal-dialog">    
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Bank Registration</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal form-label-left cmxform" id="bankForm" method="GET">
                    <div class="form-group">
                        <label for="bankName" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Bank Name</label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <input type="hidden" id="currentUser" name="currentUser" value="<?php echo $_SESSION['USER_ID']; ?>">
                            <input type="hidden" id="editBankId" name="editBankId" value="<?php echo $k->BankId; ?>">
                            <input type="text" name="bankName" id="bankName" class="form-control textOnly" minlength="2" placeholder="Input new bank name here...">
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-6 pull-right" style="margin-top: 20px">
                            <!-- <input type="button" class="btn btn-sm btn-danger" id="cancelBtn" value="Cancel" onclick="this.form.reset();"> -->
                            <input type="submit" class="btn btn-sm btn-success form-control" value="Submit">
                        </div>
                    </div>
                </form>
            </div>
            <!-- <div class="modal-footer">
                <input type="submit"  id="saveBtn" class="btn btn-primary saveBtn" value="Submit" data-dismiss="modal">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div> -->
        </div>    
    </div>
</div>

<?php foreach ($data as $k) : ?>
    <div id="modal_<?php echo $k->BankId; ?>" class="modal fade bankModal" role="dialog" >
        <div class="modal-dialog">
            <!-- MODAL CONTENT -->
            <div class="modal-content">
                <div class="modal-header" style="background: #4682B4; color: #FFF;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">EDIT <small style="color: #FFF;">Bank</small></h4>
                </div>

                <div class="modal-body">
                    <form class="form-horizontal form-label-left" id="bankForm">
                        <div class="form-group">
                            <label for="editBankName" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Bank Name</label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                                <input type="hidden" id="curUser" name="curUser" value="<?php echo $_SESSION['USER_ID']; ?>">
                                <input type="hidden" id="editBankId" name="editBankId" value="<?php echo $k->BankId; ?>">
                                <input type="text" name="editBankName" id="editBankName" class="form-control textOnly" value="<?php echo $k->Name; ?>" required>
                            </div>
                        </div>
                        <div class="pull-right">
                            <button id="saveBtn" type="button" class="btn btn-success btn-sm saveBtn" onclick="myFunction()">Save</button>
                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>

                <!-- <div class="modal-footer">
                    <button id="saveBtn" type="button" class="btn btn-success btn-sm saveBtn" data-dismiss="modal" onclick="myFunction()">Save</button>
                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
                </div> -->
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- MODAL DELETE -->
<?php foreach ($data as $k) : ?>
    <div id="delModal_<?php echo $k->BankId; ?>" class="modal fade deleteModal" role="dialog" >
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header" style="background: #CD5C5C; color: #FFF;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" >DELETE <small style="color: #FFF;">Bank</small></h4>
                </div>
                <div class="modal-body">
                    <p> Are you sure to delete this data? </p>
                    <input type="hidden" id="curUser" name="curUser" value="<?php echo $_SESSION['USER_ID']; ?>">
                    <input type="hidden" id="delBankId" name="delBankId">
                </div>
                <div class="modal-footer">
                    <button id="yesBtn" type="button" class="btn btn-success btn-sm" data-dismiss="modal">Yes</button>
                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<script src="<?= base_url(); ?>assets/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?= base_url(); ?>assets/jquery-validation/dist/additional-methods.min.js"></script>                               
<script>
                            function myFunction() {
                                var x, text;

                                // Get the value of the input field with id="numb"
                                x = document.getElementById("editBankName").value;

                                // If x is Not a Number or less than one or greater than 10
                                if (isNaN(x) || x < 1 || x > 10) {
                                    text = "Input not valid";
                                } else {
                                    text = "Input OK";
                                }
                            }
</script>
<script type="text/javascript">

    $(window).load(function () {
        // UPDATE
        $(document).on('click', '.editBtn', function (event) {
            var row = $(this).closest('tr');
            var nrow = row[0];

            //$('#editBankId').val($(this).data('id'));

            var getModal = $($(this).data("target"))[0];
            modalId = '#' + getModal.id;

            $(document).on('shown.bs.modal', modalId, function (e) {
                $(modalId + ' ' + '#saveBtn').on('click', function () {
                    var bankId = $('#editBankId').val();
                    var bankName = $(modalId + ' ' + '#editBankName').val();
                    var userId = $('#curUser').val();
                    var newData = {
                        'bankId': bankId,
                        'bankName': bankName,
                        'userId': userId
                    };

                    event.preventDefault();
                    if (bankName.trim() == "") {
                        new PNotify({
                            title: 'Notification!',
                            text: 'You must fill the Bank Name',
                            type: 'danger',
                            styling: 'bootstrap3'
                        });

                        PNotify.prototype.options.delay = 1200;
                        return;
                    }

                    $.ajax({
                        type: 'POST',
                        url: 'banks/updateData',
                        data: newData,
                        success: function (response) {
                            if (response == 1) {
                                new PNotify({
                                    title: 'Success!',
                                    text: 'The Bank you selected has been successfully updated.<br>New Bank name is <b>' + bankName + '</b>',
                                    type: 'success',
                                    styling: 'bootstrap3'
                                });
                                $("#modal_<?= $k->BankId ?>").modal('hide');
                                PNotify.prototype.options.delay = 1200;

                                setTimeout(function () {
                                    location.reload();
                                }, 1500);
                            }
                        }
                    });
                });
            });
        });

        // DELETE
        $(document).on('click', '.btnDel', function (j) {
            var row = $(this).closest('tr');
            var nrow = row[0];

            $('#delBankId').val($(this).data('id'));

            var modal = $($(this).data('target'))[0];
            modalId = '#' + modal.id;

            $(document).on('shown.bs.modal', modalId, function (e) {
                $(modalId + ' ' + '#yesBtn').on('click', function (event) {
                    var bankId = $('#delBankId').val();
                    var userId = $('#curUser').val();

                    var data = {
                        'bankId': bankId,
                        'userId': userId
                    };

                    event.preventDefault();

                    $.ajax({
                        type: 'POST',
                        url: 'banks/deleteData',
                        data: data,
                        success: function (response) {
                            if (response == 1) {
                                new PNotify({
                                    title: 'Success!',
                                    text: 'The Bank you selected has been successfully deleted',
                                    type: 'success',
                                    styling: 'bootstrap3'
                                });

                                PNotify.prototype.options.delay = 1200;

                                setTimeout(function () {
                                    location.reload();
                                }, 1500);
                            }
                        }
                    });
                });
            });
        });
    });

</script>
<script>
    $(window).load(function () {
        $('.textOnly').on('keydown', function (e) {
            -1 !== $.inArray(e.keyCode, [32, 46, 8, 9, 27, 13, 110, ]) || (/65|67|86|88/.test(e.keyCode) && (e.ctrlKey === true || e.metaKey === true)) && (!0 === e.ctrlKey || !0 === e.metaKey) || 35 <= e.keyCode && 40 >= e.keyCode || (65 > e.keyCode || 90 < e.keyCode) && (96 > e.keyCode || 105 < e.keyCode) && e.preventDefault()
        });
        $('#toolbar').find('select').on('change', function (e) {
            $('#data1').bootstrapTable('destroy').bootstrapTable({
                exportDataType: $(this).val()
            });
        });
    });

    $('#bankForm').validate({
        debug: true,
        rules: {
            bankName: {
                required: true
            }
        },
        messages: {
            bankName: {
                required: "Please enter bank name..."
            }
        },
        submitHandler: function (form) {
            $.ajax({
                type: "POST",
                url: "banks/insertNew",
                data: $(form).serialize(),
                success: function (response) {
                    if (response == 1) {
                        new PNotify({
                            title: 'Success!',
                            text: 'New Bank has been saved successfuly.',
                            type: 'success',
                            styling: 'bootstrap3'
                        });

                        PNotify.prototype.options.delay = 1200;

                        setTimeout(function () {
                            location.reload();
                        }, 1500);
                    }
                }
            });
        }
    });

</script>
<script type="text/javascript">
    function printini() {
        window.print();
    }
</script>