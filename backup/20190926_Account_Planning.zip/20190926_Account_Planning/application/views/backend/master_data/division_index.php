<!-- <script src="<?= base_url(); ?>assets/bootstrap-table-export.js"></script> -->
<!-- <script src="<?= base_url(); ?>assets/FileSaver.min.js"></script>
<script src="<?= base_url(); ?>assets/xlsx.core.min.js"></script> -->
<!-- <script src="<?= base_url(); ?>assets/tableExport.js"></script> -->


<style type="text/css">
    .cntrl {
        text-align: center;
    }

    .lft {
        text-align: left;
    }
    .fixed-table-container{
        border-top: none;
    }
    .dataTables_info , .dataTables_paginate{display: none;}
    @media print
    {    
        .no-print, .no-print *
        {
            display: none !important;
        }
    }
</style>

<div class="right_col" role="main">
    <div class="container">

        <div class="row" id="indexDiv">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Divisions</h2>
                        <div class="pull-right">
                            <button id="addBtn" class="btn btn-success btn-sm addBtn" type="button" data-toggle="modal" data-target="#add_">
                                <i class="fa fa-plus"></i>&nbsp;
                                <b>Add Divisions</b>
                            </button>
                        </div>
                        <!-- <ul class="nav navbar-right panel_toolbox">
                            <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        </ul> -->
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div id="toolbar">
                            <select class="form-control" >

                                <option value="all">Export All</option>
                                <option value="">Export Basic</option>
                                <option value="selected">Export Selected</option>
                            </select>

                            <button onClick ="$('#data2').tableExport({type: 'excel', escape: 'false', fileName: 'Division', exportDataType: 'all'});"> Download Excel </button>
                        </div>
                        <table id="data2" data-click-to-select="true" 
                               data-show-export="true" 
                               data-search="true" data-toggle="table" 
                               data-toolbar="#toolbar"
                               data-page-list="[5,8,10]"
                               data-export-options='{
                               "fileName": "MasterDivision",
                               "ignoreColumn": [8]
                               }'
                               data-pagination="true" class="table table-condensed table-striped table-hover">
                            <thead style="background-color: #012D5A; color: #FFF;">
                                <tr>
                                    <th class="cntrl" data-sortable="true">No</th>
                                    <th class="lft" data-sortable="true">Division Name</th>
                                    <th class="lft" data-sortable="true">Segment</th>
                                    <th class="lft" data-sortable="true">Division Type</th>
                                    <th class="cntrl" data-sortable="true">Status</th>
                                    <th class="cntrl" data-sortable="true">Created On</th>
                                    <th class="cntrl">Created By</th>
                                    <th class="cntrl" data-sortable="true">Last Modified</th>
                                    <th class="cntrl">Modified By</th>
                                    <th class="cntrl no-print">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($data as $k) :
                                    ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo $k->Name; ?></td>
                                        <td class="cntrl"><?php echo $k->Segment; ?></td>
                                        <td class="cntrl"><?php
                                            if ($k->UnitKerjaTypeId == 1) {
                                                echo "Business";
                                            } else if ($k->UnitKerjaTypeId == 2) {
                                                echo "Product Owner";
                                            } else {
                                                echo "-";
                                            }
                                            ?></td>
                                        <td class="cntrl">
                                            <?php
                                            if ($k->IsActive == 1) {
                                                echo "Active";
                                            } else {
                                                echo "Non Active";
                                            };
                                            ?>
                                        </td>
                                        <td class="lft"><?php
                                            $addon = new DateTime($k->CreatedDate);
                                            echo $addon->format('d/m/Y H:i:s');
                                            ?></td>
                                        <td class="lft"><?php echo $k->MAKER; ?></td>
                                        <td class="cntrl"><?php
                                            $modion = $k->ModifiedDate;
                                            if ($modion) {
                                                $modifiedOn = new DateTime($modion);
                                                echo $modifiedOn->format('d/m/Y H:i:s');
                                            } else {
                                                echo '-';
                                            }
                                            ?></td>
                                        <td class="cntrl"><?php echo ($k->MODIFIER) ? $k->MODIFIER : '-'; ?></td>
                                        <td class="no-print">
                                            <a href="#" class="btn btn-xs btn-info editBtn" data-toggle="modal" data-target="#modal_<?php echo $k->UnitKerjaId; ?>" data-id="<?php echo $k->UnitKerjaId; ?>">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                            <a href="#" class="btn btn-xs btn-danger btnDel" data-toggle="modal" data-target="#delModal_<?php echo $k->UnitKerjaId; ?>" data-id="<?php echo $k->UnitKerjaId; ?>">
                                                <i class="fa fa-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
<?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="add_" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Divisions</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal form-label-left cmxform" id="divForm" method="GET">
                    <div class="form-group">
                        <label for="divisionId" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Division Id</label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <input type="text" name="divisionId" id="divisionId class="form-control" minlength="2" placeholder="Enter text here...">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="divisionName" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Division Name</label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <input type="hidden" id="currentUser" name="currentUser" value="<?php echo $_SESSION['USER_ID']; ?>">
                            <input type="text" name="divisionName" id="divisionName" class="form-control" minlength="2" placeholder="Enter text here...">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="divisionSegment" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Segment</label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <select id="divisionSegment" name="divisionSegment" class="form-control">
                                <option value="" selected disabled>Please select...</option>
                                <option value="1">Korporasi</option>
                                <option value="2">Menengah</option>
                            </select>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="divisionType" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Division Type</label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <select id="divisionType" name="divisionType" class="form-control">
                                <option value="" selected disabled>Please select...</option>
                                <option value="1">Business</option>
                                <option value="2">Product Owner</option>
                            </select>
                        </div>
                    </div>  
                    <div class="form-group">
                        <div class="col-md-3 col-sm-3 col-xs-9 pull-right">
                            <!-- <input type="button" class="btn btn-sm btn-danger" id="cancelBtn" value="Cancel" onclick="this.form.reset();"> -->
                            <input type="submit" class="btn btn-sm btn-success form-control" value="Submit">
                        </div>
                    </div>
                </form>
            </div>
            <!-- <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div> -->
        </div>

    </div>
</div>

<!-- MODAL UPDATE -->
<?php foreach ($data as $k) : ?>
    <div id="modal_<?php echo $k->UnitKerjaId; ?>" class="modal fade divModal" role="dialog" >
        <div class="modal-dialog">
            <!-- MODAL CONTENT -->
            <div class="modal-content">
                <div class="modal-header" style="background: #4682B4; color: #FFF;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">EDIT <small style="color: #FFF;">Divisions</small></h4>
                </div>

                <div class="modal-body">
                    <form class="form-horizontal form-label-left cmxform">
                        <div class="form-group">
                            <label for="editDivName" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Division Name</label>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <input type="hidden" id="curUser" name="curUser" value="<?php echo $_SESSION['USER_ID']; ?>">
                                <input type="hidden" id="editDivId" name="editDivId">
                                <input type="text" name="editDivName" id="editDivName" class="form-control" value="<?php echo $k->Name; ?>" required>
                            </div>
                        </div>
                        <br />
                        <div class="form-group">
                            <label for="editDivStatus" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Division Status</label>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <?php
                                if ($k->IsActive == 1) {
                                    $dt = "Active";
                                } else if ($k->IsActive == 0) {
                                    $dt = "Non Active";
                                }
                                ?>
                                <select id="editDivStatus" name="editDivStatus" class="form-control" value="<?php echo $dt; ?>">
                                    <option value="1"  <?php
                                    if ($k->IsActive == 1) {
                                        echo 'selected';
                                    }
                                    ?>>Active</option>
                                    <option value="0"  <?php
                                    if ($k->IsActive == 0) {
                                        echo 'selected';
                                    }
                                    ?>>Non Active</option>
                                </select>
                            </div>
                        </div>	
                        <br />
                        <div class="form-group">
                            <label for="editDivSegment" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Segment</label>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <?php
                                if ($k->SegmentId == 1) {
                                    $dt = "Korporasi";
                                } else if ($k->SegmentId == 2) {
                                    $dt = "Menengah";
                                }
                                ?>
                                <select id="editDivSegment" name="editDivSegment" class="form-control" value="<?php echo $dt; ?>">
                                    <option value="1"  <?php
                                    if ($k->SegmentId == 1) {
                                        echo 'selected';
                                    }
                                    ?>>Korporasi</option>
                                    <option value="2"  <?php
                                    if ($k->SegmentId == 2) {
                                        echo 'selected';
                                    }
                                    ?>>Menengah</option>
                                </select>
                            </div>
                        </div>
                        <br />
                        <div class="form-group">
                            <label for="editDivType" class="control-label col-md-3 col-sm-3 col-xs-12 pull-left">Division Type</label>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <?php
                                if ($k->UnitKerjaTypeId == 1) {
                                    $dt = "Business";
                                } else if ($k->UnitKerjaTypeId == 2) {
                                    $dt = "Product Owner";
                                }
                                ?>
                                <select id="editDivType" name="editDivType" class="form-control" value="<?php echo $dt; ?>">
                                    <option value="1"  <?php
                                    if ($k->UnitKerjaTypeId == 1) {
                                        echo 'selected';
                                    }
                                    ?>>Business</option>
                                    <option value="2"  <?php
                                    if ($k->UnitKerjaTypeId == 2) {
                                        echo 'selected';
                                    }
                                    ?>>Product Owner</option>
                                </select>
                            </div>
                        </div>	
                    </form>
                </div>

                <div class="modal-footer">
                    <button id="saveBtn" type="button" class="btn btn-success btn-sm saveBtn" data-dismiss="modal">Save</button>
                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<!-- MODAL DELETE -->
<?php foreach ($data as $k) : ?>
    <div id="delModal_<?php echo $k->UnitKerjaId; ?>" class="modal fade deleteModal" role="dialog" >
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header" style="background: #CD5C5C; color: #FFF;">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" >DELETE <small style="color: #FFF;">Division</small></h4>
                </div>
                <div class="modal-body">
                    <p> Are you sure to delete this data? </p>
                    <input type="hidden" id="curUser" name="curUser" value="<?php echo $_SESSION['USER_ID']; ?>">
                    <input type="hidden" id="delDivId" name="delDivId">
                </div>
                <div class="modal-footer">
                    <button id="yesBtn" type="button" class="btn btn-success btn-sm" data-dismiss="modal">Yes</button>
                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<script src="<?= base_url(); ?>assets/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?= base_url(); ?>assets/jquery-validation/dist/additional-methods.min.js"></script>

<script src="<?= base_url(); ?>/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>

<script type="text/javascript">
$('#divForm').validate({
    debug: true,
    rules: {
        divisionName: {
            required: true
        },
        divisionType: {
            required: true
        }
    },
    messages: {
        divisionName: {
            required: "Please enter division name..."
        },
        divisionType: {
            required: "Please select division type..."
        }
    },
    submitHandler: function (form) {
        $.ajax({
            type: "POST",
            url: "divisions/insertNew",
            data: $(form).serialize(),
            success: function (response) {
                if (response == 1) {
                    new PNotify({
                        title: 'Success!',
                        text: 'New Division has been saved successfuly.',
                        type: 'success',
                        styling: 'bootstrap3'
                    });

                    PNotify.prototype.options.delay = 1200;

                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                }
            }
        });
    }
});

$(window).load(function () {
    // UPDATE
    $(document).on('click', '.editBtn', function (event) {
        var row = $(this).closest('tr');
        var nrow = row[0];

        $('#editDivId').val($(this).data('id'));
        var getModal = $($(this).data("target"))[0];

        modalId = '#' + getModal.id;

        $(document).on('shown.bs.modal', modalId, function (e) {
            $(modalId + ' ' + '#saveBtn').on('click', function () {
                var divisionId = $('#editDivId').val();
                var divisionName = $(modalId + ' ' + '#editDivName').val();
                var divisionType = $(modalId + ' ' + '#editDivType').find(":selected").text();
                var divisionSegment = $(modalId + ' ' + '#editDivSegment').find(":selected").text();
                var divisionStatus = $(modalId + ' ' + '#editDivStatus').find(":selected").text();
                var userId = $('#curUser').val();

                var newData = {
                    'divisionId': divisionId,
                    'divisionName': divisionName,
                    'divisionSegment': divisionSegment,
                    'divisionType': divisionType,
                    'divisionStatus': divisionStatus,
                    'userId': userId
                };

                event.preventDefault();

                if (divisionName.trim() == "") {
                    new PNotify({
                        title: 'Notification!',
                        text: 'You must fill the Division Name',
                        type: 'danger',
                        styling: 'bootstrap3'
                    });

                    PNotify.prototype.options.delay = 1200;
                    return;
                }

                $.ajax({
                    type: 'POST',
                    url: 'divisions/updateData',
                    data: newData,
                    success: function (response) {
                        if (response == 1) {
                            new PNotify({
                                title: 'Success!',
                                text: 'The Division you selected has been successfully updated.<br>New Division name is <b>' + divisionName + '</b>',
                                type: 'success',
                                styling: 'bootstrap3'
                            });

                            PNotify.prototype.options.delay = 1200;

                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        }
                    }
                });
            });
        });
    });

    // DELETE
    $(document).on('click', '.btnDel', function (j) {
        var row = $(this).closest('tr');
        var nrow = row[0];

        $('#delDivId').val($(this).data('id'));

        var modal = $($(this).data('target'))[0];
        modalId = '#' + modal.id;

        $(document).on('shown.bs.modal', modalId, function (event) {
            $(modalId + ' ' + '#yesBtn').on('click', function () {
                var divisionId = $('#delDivId').val();
                var userId = $('#curUser').val();

                var data = {
                    'divisionId': divisionId,
                    'userId': userId
                };

                event.preventDefault();

                $.ajax({
                    type: 'POST',
                    url: 'divisions/deleteData',
                    data: data,
                    success: function (response) {
                        if (response == 1) {
                            new PNotify({
                                title: 'Success!',
                                text: 'The Division you selected has been successfully deleted',
                                type: 'success',
                                styling: 'bootstrap3'
                            });

                            PNotify.prototype.options.delay = 1200;

                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        }
                    }
                });
            });
        });
    });
});

</script>

<script>
    $(window).load(function () {
        $('#toolbar').find('select').on('change', function (e) {
            $('#data2').bootstrapTable('destroy').bootstrapTable({
                exportDataType: $(this).val()
            });
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#pageTables').dataTable();
    });
</script>