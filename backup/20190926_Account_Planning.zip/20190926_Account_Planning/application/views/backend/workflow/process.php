<div class="right_col" role="main">
    <div class="container">
    	<!-- isi konten ditaro disini -->
    	Process
    </div>
</div>
                