<style type="text/css">
    .index {
        width: 2px;
        text-align: center;
    }
    .actionrole {
        width: 18%;
        text-align: left;
    }
</style>
<div class="right_col" role="main">
    <div class="container">
        <!-- isi konten ditaro disini -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Role<small>Master Data</small></h2>
                        <div class="pull-right">
                            <button id="addBtn" data-toggle="modal" data-target="#add_" class="btn btn-success btn-sm" type="button">
                                <i class="fa fa-plus"></i>&nbsp;
                                <b>Add New</b>
                            </button>
                        </div>
                        <div class="clearfix"></div>
                        <div id="notif">

                        </div>
                    </div>

                    <div class="x_content">

                        <table data-toggle="table" data-pagination="true" class="table table-striped table-hover" width="100%">
                            <thead style="background-color: #012D5A; color: #FFF;">
                                <tr class="headings">
                                    <th class="index" data-sortable="true">No</th>
                                    <th class="" width="20%" data-sortable="true" data-field="name">Role Name</th>
                                   <!--  <th class="" width="30%" >Signer Role</th> -->
                                    <th class="" width="40%" data-sortable="true">Description</th>
                                    <th class="actionrole" align="center" style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($data as $key_users) :
                                    ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo $key_users->Name; ?></td>
                                        <!-- <td><?php echo $key_users->SUBROLENAME; ?></td> -->
                                        <td><?php echo $key_users->Description; ?></td>
                                        <td class="last" align="center" style="text-align: center;">
                                            <a href="#" class="btn btn-xs btn-info editRoleBtn"
                                               data-toggle="modal"  
                                               data-target="#edit<?php echo $key_users->RoleId; ?>" 
                                               data-id="<?php echo $key_users->RoleId; ?>"
                                               >
                                                <i class="fa fa-edit"></i>&nbsp;<b>Edit</b>
                                            </a>
                                            <a href="#" class="btn btn-xs btn-danger btnDel"
                                               data-toggle="modal" 
                                               data-target="#delModal_<?php echo $key_users->RoleId; ?>"
                                               data-id="<?php echo $key_users->RoleId; ?>"
                                               >
                                                <i class="fa fa-trash"></i>&nbsp;<b>Delete</b>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="add_" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Role</h4>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="roleName">Role name:</label>
                            <input type="text" class="form-control textOnly" id="roleName" name="roleName">
                            <input type="hidden" id="curUser" name="curUser" value="<?php echo $_SESSION['PERSONAL_NUMBER']; ?>">
                        </div>
                        <!-- <div class="form-group">
                            <label for="sel1">Choose Signer Role:</label>
                            <select class="form-control" id="subRole" name="subRole">
                        <?php
                        $i = 1;
                        foreach ($data_subrole as $key) :
                            ?>
                                        <option value="<?php echo $key->ID; ?>"><?php echo $key->SUBROLE_NAME; ?></option>
                        <?php endforeach; ?>
                            </select>
                        </div> -->
                        <div class="form-group">
                            <label for="comment">Description:</label>
                            <textarea class="form-control" rows="5" id="description" name="description"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <input type="button" id="saveBtn" class="btn btn-primary saveBtn" data-dismiss="modal" value="Submit">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

    <!-- MODAL EDIT -->
    <?php foreach ($data as $key_users) : ?>
        <div id="edit<?php echo $key_users->RoleId; ?>" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Edit Role</h4>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div class="form-group">
                                <label style="width: 100%">Name:</label>
                                <input type="text" id="editRoleName" name="editRoleName" class="form-control textOnly"  value="<?php echo $key_users->Name; ?>">

                            </div>
                            <input type="hidden" class="form-control" id="editRoleId" name="editRoleId">    
                            <input type="hidden" class="form-control" id="editCurUser" name="editCurUser" value="<?php echo $_SESSION['PERSONAL_NUMBER']; ?>">

                            <!--  <div class="form-group">
                                 <label for="editSubRole">Choose Signer Role:</label>
                                 
                                 
                                 <select class="form-control" id="editSubRole" name="editSubRole">
                            <?php foreach ($data_subrole as $ds) : ?>
                                             <option value="<?php echo $ds->ID; ?>" <?php
                                if ($ds->ID == $key_users->SUBROLE_ID) {
                                    echo 'selected';
                                }
                                ?>><?php echo $ds->SUBROLE_NAME; ?></option>
    <?php endforeach; ?>
                                 </select>
                             </div> -->


                            <div class="form-group">
                                <label for="editDescription">Description:</label>
                                <textarea class="form-control" rows="5" id="editDescription" value="<?php echo $key_users->RoleId; ?>"><?php echo $key_users->Description; ?></textarea>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button id="saveEditRole" type="button" class="btn btn-primary saveEditRole" data-dismiss="modal">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                    </div>
                </div>

            </div>
        </div>
    <?php endforeach; ?>

    <!-- MODAL DELETE -->
<?php foreach ($data as $key_role) : ?>
        <div id="delModal_<?php echo $key_role->RoleId; ?>" class="modal fade deleteModal" role="dialog" >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header" style="background: #CD5C5C; color: #FFF;">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title" >Delete <small style="color: #FFF;">Role</small></h4>
                    </div>
                    <div class="modal-body">
                        <p> Are you sure to delete this data? </p>
                        <input type="hidden" id="currentUser" name="currentUser" value="<?php echo $_SESSION['PERSONAL_NUMBER']; ?>">
                        <input type="hidden" id="delUserId" name="delUserId">
                    </div>
                    <div class="modal-footer">
                        <button id="yesBtn" type="button" class="btn btn-success btn-sm saveBtn" data-dismiss="modal">Yes</button>				
                        <button id="noBtn" type="button" class="btn btn-danger btn-sm" data-dismiss="modal">No</button>
                    </div>
                </div>
            </div>
        </div>
<?php endforeach; ?>


</div>


<script src="<?= base_url(); ?>assets/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?= base_url(); ?>assets/jquery-validation/dist/additional-methods.min.js"></script>

<script type="text/javascript">

$(window).load(function () {

    $('#saveBtn').on('click', function (event) {
        var name = $('#roleName').val();
        var subRoleType = $('#subRole').find(":selected").val();
        var userId = $('#curUser').val();
        var description = $('#description').val();


        var newData = {
            'name': name,
            'subRoleType': subRoleType,
            'userId': userId,
            'description': description
        };

        event.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'addNewRole',
            data: newData,
            success: function (response) {
                if (response == 1) {
                    new PNotify({
                        title: 'Success!',
                        text: 'The Role has been successfully saved.',
                        type: 'success',
                        styling: 'bootstrap3'
                    });
                    PNotify.prototype.options.delay = 1200;
                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                }
            }
        });
    });

    //EDIT

    $(document).on('click', '.editRoleBtn', function (event) {
        var row = $(this).closest('tr');
        var nrow = row[0];

        $('#editRoleId').val($(this).data('id'));

        var getModal = $($(this).data("target"))[0];
        modalId = '#' + getModal.id;

        $(document).on('shown.bs.modal', modalId, function (e) {
            $(modalId + ' ' + '#saveEditRole').on('click', function () {
                var editRoleId = $('#editRoleId').val();
                var name = $(modalId + ' ' + '#editRoleName').val();
                var description = $(modalId + ' ' + '#editDescription').val();
                var userId = $('#editCurUser').val();
               var editedData = {
                    'editRoleId': editRoleId,
                    'name': name,
                    'userId': userId,
                    'description': description
                };
                event.preventDefault();

                $.ajax({
                    type: 'POST',
                    url: 'updateDataRole',
                    data: editedData,
                    success: function (response) {
                        if (response == 1) {
                            new PNotify({
                                title: 'Success!',
                                text: 'The Role you selected has been successfully updated',
                                type: 'success',
                                styling: 'bootstrap3'
                            });

                            PNotify.prototype.options.delay = 1200;

                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        }
                    }
                });
            });
        });
    });

    $(document).on('click', '.btnDel', function (event) {
        var row = $(this).closest('tr');
        var nrow = row[0];

        $('#delUserId').val($(this).data('id'));

        var modal = $($(this).data('target'))[0];
        modalId = '#' + modal.id;
        $(document).on('shown.bs.modal', modalId, function (e) {
            $(modalId + ' ' + '#yesBtn').on('click', function () {
                var userId = $('#delUserId').val();
                var userId2 = $('#currentUser').val();
                var data = {
                    'userId': userId,
                    'userId2': userId2
                };
                event.preventDefault();
                $.ajax({
                    type: 'POST',
                    url: 'deleteRoleData',
                    data: data,
                    success: function (response) {
                        if (response == 1) {
                            new PNotify({
                                title: 'Success!',
                                text: 'The Role you selected has been successfully deleted',
                                type: 'success',
                                styling: 'bootstrap3'
                            });

                            PNotify.prototype.options.delay = 1200;

                            setTimeout(function () {
                                location.reload();
                            }, 1500);
                        }
                    }
                });
            });
        });
    });
    $('.textOnly').on('keydown', function (e) {
        -1 !== $.inArray(e.keyCode, [32, 46, 8, 9, 27, 13, 110, ]) || (/65|67|86|88/.test(e.keyCode) && (e.ctrlKey === true || e.metaKey === true)) && (!0 === e.ctrlKey || !0 === e.metaKey) || 35 <= e.keyCode && 40 >= e.keyCode || (65 > e.keyCode || 90 < e.keyCode) && (96 > e.keyCode || 105 < e.keyCode) && e.preventDefault()
    });
});

</script>