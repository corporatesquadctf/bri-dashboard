<div class="right_col" role="main">
    <div class="container">
    	<!-- isi konten ditaro disini -->
    	report
    </div>
</div>
                