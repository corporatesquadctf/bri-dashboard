<div class="right_col" role="main">
    <div class="">
    	<?php $this->load->view('performance/company/table/log.php'); ?>
    </div>
</div>