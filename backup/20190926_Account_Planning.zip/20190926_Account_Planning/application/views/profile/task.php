<style type="text/css">
   th { text-align: center; }
</style>


<div class="right_col" role="main">
   <div class="">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
               <div class="x_title">
                  <h2>PROFILE</small></h2>
                  <div class="clearfix"></div>
               </div>
               <div class="x_content">
                  <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                     <?php $this->load->view('layout/profile_sidebar.php'); ?>
                  </div>
                  <div class="col-md-9">
                     <?php $this->load->view('profile/task_table.php'); ?>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

