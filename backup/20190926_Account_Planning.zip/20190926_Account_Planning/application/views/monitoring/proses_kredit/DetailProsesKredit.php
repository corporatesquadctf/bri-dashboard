<style type="text/css">
    .div-action{
        display: inline-flex;
        margin: auto;
        color: #218FD8;
    }
    .div-action i{
        font-size: 14px;
        font-weight: normal;
        margin: auto;
    }
    .div-action label{
        font-size: 14px;
        font-weight: normal;
        padding-left: 5px;
        margin-bottom: 0px;
    }
    .li-card {
        margin: 0 0 0 50px;
        border-left: 1.2px dashed #808080;
        overflow: visible;
        padding: 0 0 0 50px;
        background: transparent;
    }
    .li-block {
        margin: 0 0 0 50px;
        overflow: visible;
        padding: 10px 25px;
        margin: 0px;
        box-shadow: 0px 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
        border-radius: 4px;
        background: #fff;
    }
    .li-separator{
        margin: 0 0 0 50px;
        border-left: 1.2px dashed #808080;
        overflow: visible;
        padding: 5px;
    }
    .ellipse {
        position: absolute;
        width: 30px;
        height: 30px;
        margin-left: -65px;
        background: #42BC3F;
        border: 1px solid #F0F0F0;
        box-sizing: border-box;
        box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.15);
        border-radius: 15px;
    }
    .ellipse-active{
        background: #FF1259;
    }
    .ellipse-finished{
        background: #3498DB;
    }
    .detail_div{
        margin: 0px;
        padding-top: 15px;
        padding-bottom: 10px;
        background: #E5F0FF;
        display: none;
    }
    .btn_detail_div{
        margin: 0px;
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
        background: #218FD8;
        box-shadow: 0px 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
        cursor: pointer;
    }
    .btn_detail_div label{
        cursor: pointer;
    }
    .datepicker table thead{
        background: none;
    }
    .datepicker table thead tr{
        color: #73879C;
    }
</style>
<div class="right_col" role="main">    
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel container_header">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Monitoring</li>
                            <li class="breadcrumb-item"><a href="<?= base_url().'monitoring/proseskredit'; ?>">Proses Kredit</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Detail</li>
                        </ol>
                    </nav>
                    <div class="x_title">
                        <div class="page_title">
                            <div class="pull-left">Detail Proses Kredit</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <?php
                            $startDate = date("Y-m-d", strtotime($prosesKredit->CreatedDate));
                            $startDateTime = strtotime($startDate);
                            $endDate = $prosesKredit->TanggalPutusan;
                            if($endDate == null){
                                $endDate = date("Y-m-d");
                            }else{
                                $endDate = date("Y-m-d", strtotime($prosesKredit->TanggalPutusan));
                            }
                            $endDateTime = strtotime($endDate);
                            $difference = $endDateTime - $startDateTime;
                            $TAT = floor($difference / (60*60*24) );                
                            if($TAT < 0) $TAT = 0;
                        ?>
                        <div class="row">
                            <div class="col-xs-12 col-lg-8">
                            
                                <div class="row">
                                    <div class="col-xs-6 col-sm-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Debitur :</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $pipeline->CustomerName; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Status Permohonan :</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $pipeline->DataSourceName; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Usulan Plafond :</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight:normal;" class="money" data-a-sep="," data-a-dec="."><?= $pipeline->Plafond; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">TAT :</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $TAT; ?> Hari</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-lg-4">
                                <?php
                                    if($prosesKredit->StatusPutusan == 0){
                                        if($prosesKredit->StatusApplicationId == $user['ROLE_ID']) :
                                            echo '<button id="btn_teruskan_proses_kredit" class="btn w150 btn-sm btn-primary pull-right" style="margin-bottom:0px;" type="button" data-toggle="modal" data-target=".modal-teruskan-proses-kredit">Kirim</button>';
                                            if($user['ROLE_ID'] != 12) :
                                                echo '<button id="btn_kembalikan_proses_kredit" class="btn w150 btn-sm btn-primary pull-right" style="margin-bottom:0px;" type="button" data-toggle="modal" data-target=".modal-kembalikan-proses-kredit">Kembalikan</button>';
                                            endif;
                                        endif;
                                    }else if($prosesKredit->StatusPutusan == 1){
                                        if($user['ROLE_ID'] == 17 && $prosesKredit->StatusApplicationId == 17 && $prosesKredit->IsAkad == 0):
                                            echo '<button id="btn_akad_kredit" class="btn w150 btn-sm btn-primary pull-right" style="margin-bottom:0px;" type="button" data-toggle="modal" data-target=".modal-akad-kredit">Akad Kredit</button>';
                                        endif;
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if($prosesKredit->IsAkad == 1): ?>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <div class="row">
                            <div class="col-xs-12 col-lg-8">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Tanggal Akad:</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= date("d F Y", strtotime($prosesKredit->TanggalAkad)); ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Nama Notaris:</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $prosesKredit->NamaNotaris; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Keterangan:</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight:normal;"><?= $prosesKredit->Keterangan; ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if(!empty($historyProsesKreditKadiv)): ?>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <div class="row">
                            <div class="col-xs-12 col-lg-8">
                                <div class="row">
                                    <div class="col-sm-2 col-xs-12">
                                        <label class="control-label">Komentar Kadiv</label>
                                    </div>
                                    <div class="col-sm-10 col-xs-12">
                                        <table>
                                        <?php foreach($historyProsesKreditKadiv as $row){
                                            if($row->Comment == NULL) continue;
                                            echo '<tr>';
                                            echo '<td>'.date("d F Y H:i:s", strtotime($row->CreatedDate)).'</td>';
                                            echo '<td style="padding:0 5px;">-</td>';
                                            echo '<td>['.$row->CreatedByName.']</td>';
                                            echo '<td style="padding:0 5px;">:</td>';
                                            echo '<td>'.$row->Comment.'</td>';
                                            echo '</tr>';
                                        }
                                        ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
            <?php 
                $activeRM = '';
                $activeADK = '';
                $activeARK = '';
                $activeKomite = '';
                switch($prosesKredit->StatusApplicationId){
                    case 12: $activeRM = 'ellipse-active'; break;
                    case 14: $activeKomite = 'ellipse-active'; break;
                    case 17: 
                        if($prosesKredit->StatusPutusan == 0){
                            $activeADK = 'ellipse-active'; 
                        }else{
                            $activeADK = 'ellipse-finished';
                        }                        
                        break;
                    case 18: $activeARK = 'ellipse-active'; break;
                    default: break;
                }
            ?>
            <div class="col-xs-12">
                <div class="x_panel" style="background:none; border:none; padding: 0px;">
                    <div class="x_content" style="padding:0px; margin-top:0px;">
                        <div class="dashboard-widget-content" style="padding:0px;">
                            <ul class="list-unstyled widget" style="max-width: none;">
                                <li class="li-card">
                                    <?php
                                        if(!empty($historyProsesKreditKomite)){
                                            $komiteDesc = $historyProsesKreditKomite[0]->CreatedByName;
                                            if($historyProsesKreditKomite[0]->IsApproved == 1){
                                                $komiteDesc .= ' Mengirim Paket ke ';
                                            }else $komiteDesc .= ' Mengembalikan Paket ke ';
                                            $komiteDesc .= $historyProsesKreditKomite[0]->ROLE_NAME;
                                            $komiteLastDescription = $komiteDesc;
                                            $komiteLastDate = date("d F Y H:i:s", strtotime($historyProsesKreditKomite[0]->CreatedDate));
                                            $komiteLastComment = $historyProsesKreditKomite[0]->Comment;
                                        }else{
                                            $komiteLastDescription = '-';
                                            $komiteLastDate = '-';
                                            $komiteLastComment = '-';
                                        }
                                    ?>
                                    <div class="ellipse <?= $activeKomite; ?>"></div>
                                    <div class="li-block" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;">
                                        <div class="block_content">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="form-group col-xs-12">
                                                        <label style="color: #218FD8; font-weight: bold; font-size:20px;">Komite</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">contacts</i>
                                                            <label>Aktifitas</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: bold; color:#000;"><?= $komiteLastDescription; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">today</i>
                                                            <label>Tanggal</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $komiteLastDate; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">comment</i>
                                                            <label>Komentar</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $komiteLastComment; ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="li-block" style="padding: 0px;">
                                        <div class="block-content">
                                            <div class="row detail_div" id="rowDetailKomite">
                                                <div class="col-xs-12">
                                                <?php
                                                    $iKomite = 0;
                                                    if(count($historyProsesKreditKomite) < 2){
                                                        echo '<div class="row" style="margin:0 5px;">';
                                                        echo    '<div class="col-xs-12" style="text-align:center; margin-bottom:5px;">';
                                                        echo    'Tidak Ada Data Detail';
                                                        echo    '</div>';
                                                        echo '</div>';
                                                    }else{
                                                    foreach($historyProsesKreditKomite as $row) {
                                                        $iKomite++;
                                                        if($iKomite == 1) continue;
                                                        $detailKomiteDesc = $row->CreatedByName;
                                                        if($row->IsApproved == 1){
                                                            $detailKomiteDesc .= ' Mengirim Paket ke ';
                                                        }else $detailKomiteDesc .= ' Mengembalikan Paket ke ';
                                                        $detailKomiteDesc .= $row->ROLE_NAME;
                                                        $detailKomiteLastDescription = $detailKomiteDesc;
                                                        $detailKomiteLastDate = date("d F Y H:i:s", strtotime($row->CreatedDate));
                                                        $detailKomiteLastComment = $row->Comment;
                                                ?>
                                                        <div class="row" style="margin:0 5px;">
                                                            <div class="col-lg-3">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">contacts</i>
                                                                        <label>Aktifitas</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: bold; color:#000;"><?= $detailKomiteLastDescription; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">today</i>
                                                                        <label>Tanggal</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailKomiteLastDate; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-7">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">comment</i>
                                                                        <label>Komentar</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailKomiteLastComment; ?></label>
                                                                </div>
                                                            </div>
                                                        </div>                                                        
                                                    <?php }} ?>                                                    
                                                </div>
                                            </div>
                                            <div class="row btn_detail_div" id="rowShowDetailKomite">
                                                <div class="col-xs-12">
                                                    <a style="display: block; padding: 5px; color: #FFF; text-align: center;">
                                                        <label id="labelDetailKomite" style="font-weight: normal; margin-bottom:0px;">Tampilkan Lebih Banyak<i class="fa fa-chevron-down" style=" margin-left:10px;"></i></label>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="li-separator"></div>
                                </li>                                
                                <li class="li-card">
                                    <?php
                                        if(!empty($historyProsesKreditARK)){
                                            $ARKDesc = $historyProsesKreditARK[0]->CreatedByName;
                                            if($historyProsesKreditARK[0]->IsApproved == 1){
                                                $ARKDesc .= ' Mengirim Paket ke ';
                                            }else $ARKDesc .= 'Mengembalikan Paket ke ';
                                            $ARKDesc .= $historyProsesKreditARK[0]->ROLE_NAME;
                                            $ARKLastDescription = $ARKDesc;
                                            $ARKLastDate = date("d F Y H:i:s", strtotime($historyProsesKreditARK[0]->CreatedDate));
                                            $ARKLastComment = $historyProsesKreditARK[0]->Comment;
                                        }else{
                                            $ARKLastDescription = '-';
                                            $ARKLastDate = '-';
                                            $ARKLastComment = '-';
                                        }
                                    ?>
                                    <div class="ellipse <?= $activeARK; ?>"></div>
                                    <div class="li-block" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;">
                                        <div class="block_content">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="form-group col-xs-12">
                                                        <label style="color: #218FD8; font-weight: bold; font-size:20px;">ARK</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">contacts</i>
                                                            <label>Aktifitas</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: bold; color:#000;"><?= $ARKLastDescription; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">today</i>
                                                            <label>Tanggal</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $ARKLastDate; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">comment</i>
                                                            <label>Komentar</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $ARKLastComment; ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="li-block" style="padding: 0px;">
                                        <div class="block-content">
                                            <div class="row detail_div" id="rowDetailARK">
                                                <div class="col-xs-12">
                                                <?php
                                                    $iARK = 0;
                                                    if(count($historyProsesKreditARK) < 2){
                                                        echo '<div class="row" style="margin:0 5px;">';
                                                        echo    '<div class="col-xs-12" style="text-align:center; margin-bottom:5px;">';
                                                        echo    'Tidak Ada Data Detail';
                                                        echo    '</div>';
                                                        echo '</div>';
                                                    }else{
                                                    foreach($historyProsesKreditARK as $row) {
                                                        $iARK++;
                                                        if($iARK == 1) continue;
                                                        $detailARKDesc = $row->CreatedByName;
                                                        if($row->IsApproved == 1){
                                                            $detailARKDesc .= ' Mengirim Paket ke ';
                                                        }else $detailARKDesc .= 'Mengembalikan Paket ke ';
                                                        $detailARKDesc .= $row->ROLE_NAME;
                                                        $detailARKLastDescription = $detailARKDesc;
                                                        $detailARKLastDate = date("d F Y H:i:s", strtotime($row->CreatedDate));
                                                        $detailARKLastComment = $row->Comment;
                                                ?>
                                                        <div class="row" style="margin:0 5px;">
                                                            <div class="col-lg-3">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">contacts</i>
                                                                        <label>Aktifitas</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: bold; color:#000;"><?= $detailARKLastDescription; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">today</i>
                                                                        <label>Tanggal</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailARKLastDate; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-7">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">comment</i>
                                                                        <label>Komentar</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailARKLastComment; ?></label>
                                                                </div>
                                                            </div>
                                                        </div>                                                        
                                                    <?php }} ?>                                                    
                                                </div>
                                            </div>
                                            <div class="row btn_detail_div" id="rowShowDetailARK">
                                                <div class="col-xs-12">
                                                    <a style="display: block; padding: 5px; color: #FFF; text-align: center;">
                                                        <label id="labelDetailARK" style="font-weight: normal; margin-bottom:0px;">Tampilkan Lebih Banyak<i class="fa fa-chevron-down" style=" margin-left:10px;"></i></label>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="li-separator"></div>
                                </li>
                                <li class="li-card">
                                    <?php
                                        if(!empty($historyProsesKreditADK)){
                                            $ADKDesc = $historyProsesKreditADK[0]->CreatedByName;
                                            if($historyProsesKreditADK[0]->IsApproved == 1){
                                                $ADKDesc .= ' Mengirim Paket ke ';
                                            }else $ADKDesc .= ' Mengembalikan Paket ke ';
                                            $ADKDesc .= $historyProsesKreditADK[0]->ROLE_NAME;
                                            $ADKLastDescription = $ADKDesc;
                                            $ADKLastDate = date("d F Y H:i:s", strtotime($historyProsesKreditADK[0]->CreatedDate));
                                            $ADKLastComment = $historyProsesKreditADK[0]->Comment;
                                        }else{
                                            $ADKLastDescription = '-';
                                            $ADKLastDate = '-';
                                            $ADKLastComment = '-';
                                        }
                                    ?>
                                    <div class="ellipse <?= $activeADK; ?>"></div>
                                    <div class="li-block" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;">
                                        <div class="block_content">
                                        <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="form-group col-xs-12">
                                                        <label style="color: #218FD8; font-weight: bold; font-size:20px;">ADK</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">contacts</i>
                                                            <label>Aktifitas</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: bold; color:#000;"><?= $ADKLastDescription; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">today</i>
                                                            <label>Tanggal</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $ADKLastDate; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">comment</i>
                                                            <label>Komentar</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $ADKLastComment; ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="li-block" style="padding: 0px;">
                                        <div class="block-content">
                                            <div class="row detail_div" id="rowDetailADK">
                                                <div class="col-xs-12">
                                                    <?php
                                                        $iADK = 0;
                                                        if(count($historyProsesKreditADK) < 2){
                                                            echo '<div class="row" style="margin:0 5px;">';
                                                            echo    '<div class="col-xs-12" style="text-align:center; margin-bottom:5px;">';
                                                            echo    'Tidak Ada Data Detail';
                                                            echo    '</div>';
                                                            echo '</div>';
                                                        }else{
                                                        foreach($historyProsesKreditADK as $row) {
                                                            $iADK++;
                                                            if($iADK == 1) continue;
                                                            $detailADKDesc = $row->CreatedByName;
                                                            if($row->IsApproved == 1){
                                                                $detailADKDesc .= ' Mengirim Paket ke ';
                                                            }else $detailADKDesc .= ' Mengembalikan Paket ke ';
                                                            $detailADKDesc .= $row->ROLE_NAME;
                                                            $detailADKLastDescription = $detailADKDesc;
                                                            $detailADKLastDate = date("d F Y H:i:s", strtotime($row->CreatedDate));
                                                            $detailADKLastComment = $row->Comment;
                                                    ?>
                                                        <div class="row" style="margin:0 5px;">
                                                            <div class="col-lg-3">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">contacts</i>
                                                                        <label>Aktifitas</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: bold; color:#000;"><?= $detailADKLastDescription; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">today</i>
                                                                        <label>Tanggal</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailADKLastDate; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-7">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">comment</i>
                                                                        <label>Komentar</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailADKLastComment; ?></label>
                                                                </div>
                                                            </div>
                                                        </div>                                                        
                                                    <?php }} ?>                                                    
                                                </div>
                                            </div>
                                            <div class="row btn_detail_div" id="rowShowDetailADK">
                                                <div class="col-xs-12">
                                                    <a style="display: block; padding: 5px; color: #FFF; text-align: center;">
                                                        <label id="labelDetailADK" style="font-weight: normal; margin-bottom:0px;">Tampilkan Lebih Banyak<i class="fa fa-chevron-down" style=" margin-left:10px;"></i></label>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="li-separator"></div>
                                </li>
                                <li class="li-card">
                                    <?php
                                        if(!empty($historyProsesKreditRM)){
                                            $RMDesc = $historyProsesKreditRM[0]->CreatedByName;
                                            if($historyProsesKreditRM[0]->IsApproved == 1){
                                                $RMDesc .= ' Mengirim Paket ke ';
                                            }else $RMDesc .= 'Mengembalikan Paket ke ';
                                            $RMDesc .= $historyProsesKreditRM[0]->ROLE_NAME;
                                            $RMLastDescription = $RMDesc;
                                            $RMLastDate = date("d F Y H:i:s", strtotime($historyProsesKreditRM[0]->CreatedDate));
                                            $RMLastComment = $historyProsesKreditRM[0]->Comment;
                                        }else{
                                            $RMLastDescription = '-';
                                            $RMLastDate = '-';
                                            $RMLastComment = '-';
                                        }
                                    ?>
                                    <div class="ellipse <?= $activeRM; ?>"></div>
                                    <div class="li-block" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;">
                                        <div class="block_content">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="form-group col-xs-12">
                                                        <label style="color: #218FD8; font-weight: bold; font-size:20px;">RM Menengah:</label>
                                                        <label style="font-weight: normal;  font-weight: bold; font-size:20px;  color:#218FD8;"><?= $prosesKredit->RMName; ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">contacts</i>
                                                            <label>Aktifitas</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: bold; color:#000;"><?= $RMLastDescription; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">today</i>
                                                            <label>Tanggal</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $RMLastDate; ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-7">
                                                    <div class="form-group col-xs-12">
                                                        <div class="div-action">
                                                            <i class="material-icons">comment</i>
                                                            <label>Komentar</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group col-xs-12">
                                                        <label style="font-weight: normal;"><?= $RMLastComment; ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="li-block" style="padding: 0px;">
                                        <div class="block-content">
                                            <div class="row detail_div" id="rowDetailRM">
                                                <div class="col-xs-12">
                                                    <?php
                                                        $iRM = 0;
                                                        if(count($historyProsesKreditRM) < 2){
                                                            echo '<div class="row" style="margin:0 5px;">';
                                                            echo    '<div class="col-xs-12" style="text-align:center; margin-bottom:5px;">';
                                                            echo    'Tidak Ada Data Detail';
                                                            echo    '</div>';
                                                            echo '</div>';
                                                        }else{
                                                        foreach($historyProsesKreditRM as $row) {
                                                            $iRM++;
                                                            if($iRM == 1) continue;
                                                            $detailRMDesc = $row->CreatedByName;
                                                            if($row->IsApproved == 1){
                                                                $detailRMDesc .= ' Mengirim Paket ke ';
                                                            }else $detailRMDesc .= ' Mengembalikan Paket ke ';
                                                            $detailRMDesc .= $row->ROLE_NAME;
                                                            $detailRMLastDescription = $detailRMDesc;
                                                            $detailRMLastDate = date("d F Y H:i:s", strtotime($row->CreatedDate));
                                                            $detailRMLastComment = $row->Comment;
                                                    ?>
                                                        <div class="row" style="margin:0 5px;">
                                                            <div class="col-lg-3">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">contacts</i>
                                                                        <label>Aktifitas</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: bold; color:#000;"><?= $detailRMLastDescription; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">today</i>
                                                                        <label>Tanggal</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailRMLastDate; ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-7">
                                                                <div class="form-group col-xs-12">
                                                                    <div class="div-action">
                                                                        <i class="material-icons">comment</i>
                                                                        <label>Komentar</label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-xs-12">
                                                                    <label style="font-weight: normal;"><?= $detailRMLastComment; ?></label>
                                                                </div>
                                                            </div>
                                                        </div>                                                        
                                                    <?php 
                                                        }}
                                                    ?>                                                    
                                                </div>
                                            </div>
                                            <div class="row btn_detail_div" id="rowShowDetailRM">
                                                <div class="col-xs-12">
                                                    <a style="display: block; padding: 5px; color: #FFF; text-align: center;">
                                                        <label id="labelDetailRM" style="font-weight: normal; margin-bottom:0px;">Tampilkan Lebih Banyak<i class="fa fa-chevron-down" style=" margin-left:10px;"></i></label>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>            
            </div>
        </div>        
        <div class="modal fade modal-teruskan-proses-kredit" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Komentar</h4>
                    </div>
                    <div class="modal-body">
                        <form id="formTeruskanProsesKredit" action="<?= base_url().'monitoring/proseskredit/teruskan_proses_kredit'; ?>" method="POST">
                            <div class="row form-group">
                                <div class="col-xs-12">
                                <input type="hidden" id="prosesKreditId" name="prosesKreditId" value="<?= $prosesKredit->ProsesKreditId; ?>"> 
                                <?php
                                    if($user['ROLE_ID'] == 14):
                                ?>
                                    <p style="font-weight: bold; color: #000;">Putusan:</p>
                                    <p>
                                        <label style="font-weight: normal;"><input type="radio" name="putusanId" value="1" style="margin-right:10px;">Setuju</label>
                                        <label style="font-weight: normal;"><input type="radio" name="putusanId" value="2" style="margin:0 10px;">Tolak</label>
                                        <label style="font-weight: normal;"><input type="radio" name="putusanId" value="0" style="margin:0 10px;">Tunda</label>                                        
                                    </p>
                                <?php
                                    endif;
                                ?>
                                <p style="font-weight: bold; color: #000;">Tujuan:</p>
                                    <p><select class="form-control js-example-basic-single" id="tujuanDiteruskanId" name="tujuanDiteruskanId" style="width:100%;">
                                        <?php
                                            foreach ($tujuanDiteruskanOption as $row){
                                                if($row->ID == 14) $roleName = 'Komite';
                                                else $roleName = $row->ROLE_NAME;
                                                $selected = '';
                                                echo '<option value="'.$row->ID.'" '.$selected.'>'.$roleName.'</option>';
                                            }
                                        ?>                                       
                                    </select></p>
                                    <p style="font-weight: bold; color: #000;">Komentar:</p>
                                    <p><textarea id="comment" maxlength="100" name="comment" class="form-control" rows="3" placeholder="Max 100 Character"></textarea></p>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn w150 btn-default" data-dismiss="modal">Batal</button>
                        <button id="btn_confirm_teruskan_proses_kredit" type="button" class="btn w150 btn-primary modal-button-ok">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade modal-kembalikan-proses-kredit" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Komentar</h4>
                    </div>
                    <div class="modal-body">
                        <form id="formBatalkanProsesKredit" action="<?= base_url().'monitoring/proseskredit/kembalikan_proses_kredit'; ?>" method="POST">
                        <div class="row form-group">
                            <div class="col-xs-12">
                                <input type="hidden" id="prosesKreditId" name="prosesKreditId" value="<?= $prosesKredit->ProsesKreditId; ?>">     
                                <p style="font-weight: bold; color: black;">Tujuan:</p>
                                <p><select class="form-control js-example-basic-single" id="tujuanDikembalikanId" name="tujuanDikembalikanId" style="width:100%;">
                                    <?php
                                            foreach ($tujuanDikembalikanOption as $row){
                                                if($row->ID == 14) $roleName = 'Komite ('.$row->ROLE_NAME.')';
                                                else $roleName = $row->ROLE_NAME;
                                                $selected = '';
                                                echo '<option value="'.$row->ID.'" '.$selected.'>'.$roleName.'</option>';
                                            }
                                        
                                    ?>                                       
                                </select></p>
                                <p style="font-weight: bold; color: #000;">Komentar:</p>
                                <p><textarea maxlength="100" id="comment" name="comment" class="form-control" rows="3" placeholder="Max 100 Character"></textarea></p>
                            </div>
                        </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn w150 btn-default" data-dismiss="modal">Batal</button>
                        <button id="btn_confirm_kembalikan_proses_kredit" type="button" class="btn w150 btn-primary modal-button-ok">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade modal-akad-kredit" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Informasi</h4>
                    </div>
                    <div class="modal-body">
                        <form id="formAkadKredit" class="form-horizontal" action="<?= base_url().'monitoring/proseskredit/akad_kredit'; ?>" method="POST">
                            <div class="row form-group">
                                <div class="col-xs-12">
                                    <input type="hidden" id="prosesKreditId" name="prosesKreditId" value="<?= $prosesKredit->ProsesKreditId; ?>"> 
                                    <p style="font-weight: bold; color: #000;">Tanggal Akad:</p>
                                    <p>
                                        <div class='input-group date tanggalAkad' style="width:228px;">
                                            <input type='text' class="form-control tanggalAkad" id='tanggalAkad' name='tanggalAkad' />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </p>
                                    <p style="font-weight: bold; color: #000;">Nama Notaris:</p>
                                    <input type="text" id="notarisName" name="notarisName" class="form-control form-group">
                                    <p style="font-weight: bold; color: #000;">Keterangan:</p>
                                    <p><textarea id="desc" maxlength="250" name="desc" class="form-control" rows="3"></textarea></p>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn w150 btn-default" data-dismiss="modal">Batal</button>
                        <button id="btn_confirm_akad_kredit" type="button" class="btn w150 btn-primary modal-button-ok">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?= base_url();?>assets/auto-numeric/autoNumeric.js"></script>

<script>
    var base_url = "<?= base_url(); ?>";
    var user_role = <?= $user['ROLE_ID']; ?>;
    var showRM = 0;
    var showADK = 0;
    var showARK = 0;
    var showKomite = 0;
    var tanggalPutusan = new Date("<?= date("m/d/Y", strtotime($prosesKredit->TanggalPutusan)); ?>");
    
    $(document).ready(function() {
        $('.money').autoNumeric('init');
        $('.js-example-basic-single').select2();
        $('.tanggalAkad').datetimepicker({
            format: 'DD/MM/YYYY',
            minDate: tanggalPutusan,
        });

        $('.modal-teruskan-proses-kredit #btn_confirm_teruskan_proses_kredit').click(function(){
            $('#formTeruskanProsesKredit').submit();
        });

        $('.modal-kembalikan-proses-kredit #btn_confirm_kembalikan_proses_kredit').click(function(){
            $('#formBatalkanProsesKredit').submit();
        });

        $('#rowShowDetailKomite').click(function(){
            if(showKomite == 0){
                showKomite = 1;
                $('#labelDetailKomite').html('Tampilkan Lebih Sedikit <i class="fa fa-chevron-up" style=" margin-left:10px;"></i>');
                $('#rowDetailKomite').fadeIn();                
            }else{
                showKomite = 0;
                $('#labelDetailKomite').html('Tampilkan Lebih Banyak <i class="fa fa-chevron-down" style=" margin-left:10px;"></i>');
                $('#rowDetailKomite').fadeOut();                
            }
        });

        $('#rowShowDetailARK').click(function(){
            if(showARK == 0){
                showARK = 1;
                $('#labelDetailARK').html('Tampilkan Lebih Sedikit <i class="fa fa-chevron-up" style=" margin-left:10px;"></i>');
                $('#rowDetailARK').fadeIn();                
            }else{
                showARK = 0;
                $('#labelDetailARK').html('Tampilkan Lebih Banyak <i class="fa fa-chevron-down" style=" margin-left:10px;"></i>');
                $('#rowDetailARK').fadeOut();                
            }
        });

        $('#rowShowDetailADK').click(function(){
            if(showADK == 0){
                showADK = 1;
                $('#labelDetailADK').html('Tampilkan Lebih Sedikit <i class="fa fa-chevron-up" style=" margin-left:10px;"></i>');
                $('#rowDetailADK').fadeIn();                
            }else{
                showADK = 0;
                $('#labelDetailADK').html('Tampilkan Lebih Banyak <i class="fa fa-chevron-down" style=" margin-left:10px;"></i>');
                $('#rowDetailADK').fadeOut();                
            }
        });

        $('#rowShowDetailRM').click(function(){
            if(showRM == 0){
                showRM = 1;
                $('#labelDetailRM').html('Tampilkan Lebih Sedikit <i class="fa fa-chevron-up" style=" margin-left:10px;"></i>');
                $('#rowDetailRM').fadeIn();                
            }else{
                showRM = 0;
                $('#labelDetailRM').html('Tampilkan Lebih Banyak <i class="fa fa-chevron-down" style=" margin-left:10px;"></i>');
                $('#rowDetailRM').fadeOut();                
            }
        });

        $('.modal-akad-kredit #btn_confirm_akad_kredit').click(function(){
            $('#formAkadKredit').submit();
        });
    });
</script>