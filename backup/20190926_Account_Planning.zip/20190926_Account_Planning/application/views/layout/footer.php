				<footer>
                    <div class="pull-right">
                        <!--
                        <p>&copy; Copyright © 2018 <a href="http://bri.co.id/" style="font-weight: bold;">Bank Rakyat Indonesia</a> (Persero) Tbk.</p>
                        -->
                        <p>© Copyright © <?= date('Y') ?> Bank Rakyat Indonesia (Persero) Tbk.</p>
                    </div>
                    <div class="clearfix"></div>
                </footer>
                <!-- /footer content -->
            </div>
        </div>

        <!-- JQuery -->
        <!-- <script src="<?=base_url();?>template/vendors/jquery/dist/jquery.min.js"></script> -->
        
        <!-- Bootstrap -->
        <script src="<?=base_url();?>template/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
        <!-- Bootrstrap Table -->
        <script src="<?=base_url();?>assets/bootstrap-table/dist/bootstrap-table.min.js"></script>
        
        <!-- FastClick -->
        <script src="<?=base_url();?>template/vendors/fastclick/lib/fastclick.js"></script>
        <!-- NProgress -->
        <script src="<?=base_url();?>template/vendors/nprogress/nprogress.js"></script>
        <!-- Chart.js -->
        <script src="<?=base_url();?>template/vendors/Chart.js-2.7.3/dist/Chart.js"></script>
        <!-- <script src="<?=base_url();?>template/vendors/Chart.js/dist/Chart.PieceLabel.min.js"></script> -->
        <script src="<?=base_url();?>template/vendors/Chart.js/dist/Chart.min.js"></script>

        <!-- morris.js -->
        <script src="<?=base_url();?>template/vendors/raphael/raphael.min.js"></script>
        <script src="<?=base_url();?>template/vendors/morris.js/morris.min.js"></script>
        
        <!-- pNotify -->
        <script src="<?=base_url();?>template/vendors/pnotify/dist/pnotify.js"></script>
        <script src="<?=base_url();?>template/vendors/pnotify/dist/pnotify.buttons.js"></script>
        <script src="<?=base_url();?>template/vendors/pnotify/dist/pnotify.nonblock.js"></script>
        
        <!-- Select 2 -->
        <script src="<?=base_url();?>assets/select2/dist/js/select2.full.min.js"></script>

        <!-- bootstrap-progressbar -->
        <script src="<?=base_url();?>template/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>

        <!-- iCheck -->
        <script src="<?=base_url()?>template/vendors/iCheck/icheck.min.js"></script>
        <script src="<?=base_url();?>template/vendors/moment/min/moment.min.js"></script>
        <script src="<?=base_url();?>template/vendors/fullcalendar/dist/fullcalendar.min.js"></script>

        <!-- Datepicker -->
        <script src="<?= base_url();?>template/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
        <script src="<?= base_url();?>template/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>

        <script src="<?= base_url(); ?>assets/jquery-validation/dist/jquery.validate.min.js"></script>
        <script src="<?= base_url(); ?>assets/jquery-validation/dist/additional-methods.min.js"></script>
        <script src="<?= base_url(); ?>assets/bootstrap-table-export.js"></script>
        <script src="<?= base_url(); ?>assets/tableExport.js"></script>
        <!-- Custom Theme Scripts -->
        <!-- <script src="<?=base_url();?>template/build/js/custom.min2.js"></script> -->
        <script src="<?=base_url();?>template/src/js/custom.min2.js"></script>

    </body>
</html>