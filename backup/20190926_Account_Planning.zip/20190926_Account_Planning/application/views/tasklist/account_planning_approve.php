<style type="text/css">
    .detail_button_con {
      background: #218FD8; 
      padding-top: 3px; 
      text-align: center; 
      height: 30px; 
      border-radius: 0px 0px 4px 4px; 
      vertical-align: middle;
    }
    .detail_button, .detail_button:focus, .detail_button:hover {
      letter-spacing: 0.15px; 
      color: #fff; 
      font-size: 10px; 
      font-weight: bold; 
    }
    .img_logo {
      padding-right:2px; 
      width:100%; 
      height:100%; 
      vertical-align: bottom;
    }
    .detail_title {
      font-weight: 600;
      font-size: 16px;
      line-height: 22px;
      letter-spacing: 0.5px;
      color: #252525;
    }
    .detail_property_title {
      font-weight: 600;
      font-size: 14px;
      line-height: 136.89%;
      align-items: center;
      letter-spacing: 0.15px;
      color: #707070;
      vertical-align: middle;
    }
    .detail_property_title2 {
      font-weight: 600;
      font-size: 12px;
      line-height: 136.89%;
      align-items: center;
      letter-spacing: 0.15px;
      color: #707070;
      vertical-align: middle;
    }
    .detail_property_title_icon {
      font-size: 15px;
      color: #218FD8;
      vertical-align: middle;
      margin-left: -10px;
    }
    .detail_head_title_icon {
      font-size: 15px;
      color: #F58C38;
      vertical-align: middle;
      /*margin-left: -10px;*/
    }
    .detail_property_text {
      font-weight: normal;
      font-size: 12px;
      line-height: 22px;
      letter-spacing: 0.15px;
      color: #707070;
    }
    .detail_property_text2 {
      font-style: normal;
      font-weight: 600;
      font-size: 11px;
      line-height: 20px;
      letter-spacing: 0.15px;
      color: #218FD8;
      margin-left: -20px;
    }
    .detail_cont_header {
      background: #FFFFFF;
      border-radius: 4px;
      min-height: 120px;
      padding-top: 20px
    }
    .margintop_con {
      margin-top: 20px;
    }
    .marginleft_con {
      margin-left: 15px;
    }
    .paddingleft_con {
      padding-left: 15px;
    }
    .padding_con {
      padding: 15px;
    }

</style>
<?php $this->load->view('tasklist/account_planning_list_member.php'); ?>

<div class="right_col" role="main">
  <div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel container_header">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                      <li class="breadcrumb-item">Tasklist</li>
                      <li class="breadcrumb-item active" aria-current="page"><a href="<?=base_url('tasklist/AccountPlanning');?>">Account Planning</a></li>
                  </ol>
                </nav>
                <div class="x_title">
                    <div class="page_title">
                        <div class="pull-left">Account Planning</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <!-- <div class="col-md-2 col-sm-2 col-xs-12">
                Button
              </div> -->
              <div class="col-md-9 col-sm-9 col-xs-12">
                <div class="col-md-2 col-sm-2 col-xs-12">
                  <i class="material-icons detail_head_title_icon">album</i> Value
                  <br>
                  In Million
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12">
                  <i class="material-icons detail_head_title_icon">business_center</i> Pinjaman
                  <br>
                  
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12">
                  <i class="material-icons detail_head_title_icon">account_balance_wallet</i> Simpanan
                  <br>
                  
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12">
                  <i class="material-icons detail_head_title_icon">insert_chart</i> Current CPA
                  <br>
                  
                </div>
                <!--<div class="col-md-3 col-sm-3 col-xs-12">
                  <i class="material-icons detail_head_title_icon">local_activity</i> Value Chain
                  <br>
                  In Million
                </div>-->
              </div>
              <div class="col-md-3 col-sm-3 col-xs-12">
                <!-- Search -->
              </div>
            </div>
          </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
              <div class="x_content">
              <?php
                if (isset($results)) {
                ?>
                  <?php foreach ($results as $ap_id => $ap_row) : ?>
                    <div class="x_panel col-md-12 col-sm-12 col-xs-12" style="padding: 0px; border-radius: 4px;">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="min-height: 120px; padding-top: 20px">
                        <div class="col-md-4 col-sm-4 col-xs-12" style="padding: 0px;">
                          <div class="col-md-12 col-sm-12 col-xs-12">
                              <div class="col-md-3 col-sm-3 col-xs-12">
                                <img class="img-responsive img-circle img_logo" src="<?= base_url('assets/images/default.png'); ?>">
                              </div>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                                <h5 class="detail_title"><b><?= html_escape($ap_row['CustomerName']); ?></b></h5>
                                <b style="color: <?= $ap_row['ap_year_color'] ?>;"><?= html_escape($ap_row['Year']); ?></b>
                              </div>
                          </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12">
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <i class="material-icons detail_property_title_icon">business_center</i> <b class="detail_property_title"> Pinjaman</b>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="detail_property_text col-md-4 col-sm-4 col-xs-4" style="margin-left: -20px;">
                              Total
                            </div>
                            <div class="detail_property_text col-md-8 col-sm-8 col-xs-8">
                              : <?=$ap_row['PinjamanTotalGroup']?>
                            </div>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="detail_property_text col-md-4 col-sm-4 col-xs-4" style="margin-left: -20px;">
                              Ratas
                            </div>
                            <div class="detail_property_text col-md-8 col-sm-8 col-xs-8">
                              : <?=$ap_row['PinjamanRatasGroup']?>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12">
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <i class="material-icons detail_property_title_icon">account_balance_wallet</i> <b class="detail_property_title">Simpanan</b>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="detail_property_text col-md-4 col-sm-4 col-xs-4" style="margin-left: -20px;">
                              Total
                            </div>
                            <div class="detail_property_text col-md-8 col-sm-8 col-xs-8">
                              : <?=$ap_row['SimpananTotalGroup']?>
                            </div>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="detail_property_text col-md-4 col-sm-4 col-xs-4" style="margin-left: -20px;">
                              Ratas
                            </div>
                            <div class="detail_property_text col-md-8 col-sm-8 col-xs-8">
                              : <?=$ap_row['SimpananRatasGroup']?>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <i class="material-icons detail_property_title_icon">insert_chart</i> <b class="detail_property_title">Current CPA</b>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="detail_property_text col-md-4 col-sm-4 col-xs-4" style="margin-left: -20px;">
                              <?=$ap_row['CurrentCPAGroup']?>
                            </div>
                          </div>
                          <!--<div class="col-md-12 col-sm-12 col-xs-12">
                            <i class="material-icons detail_property_title_icon">local_activity</i> <b class="detail_property_title">Value Chain</b>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="detail_property_text col-md-4 col-sm-4 col-xs-4" style="margin-left: -20px;">
                              <?=$ap_row['ValueChainGroup']?>
                            </div>
                          </div>-->
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-xs-12" style="height: 2.3px; background: #C6D7EE; box-shadow: 0px 1px 1px rgba(181, 181, 181, 0.17);"></div>
                      <div class="collapse col-md-12 col-sm-12 col-xs-12" id="collapseExample<?= html_escape($ap_row['AccountPlanningId']); ?>" style="background: #E5F0FF; padding: 10px;">
                        <div class="card card-body">
                          <div class="col-md-4 col-sm-4 col-xs-12 padding_con">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <i class="material-icons detail_property_title_icon">domain</i> <b class="detail_property_title2">Company List</b>
                            </div>
                            <div class="detail_property_text2 col-md-12 col-sm-12 col-xs-12">
                              <?php if (isset($ap_row['account_planning_vcif_list'])) { ?>
                                <?php $index_vcif = 1; ?>
                                <?php foreach ($ap_row['account_planning_vcif_list'] as $row => $value) : ?>
                                      <div class="col-md-1 col-sm-1 col-xs-12">
                                        <?php if ($value['IsMain'] == 1) { ?>
                                          <i class="material-icons" title="Main Company" style="font-size: 15px; vertical-align: middle;">check_box</i>
                                        <?php } ?>
                                        </div> 
                                      <div class="col-md-1 col-sm-1 col-xs-12"><?= $index_vcif ?>. </div>
                                      <div class="col-md-10 col-sm-10 col-xs-12"><?= $value['Name'] ?></div>
                                <?php $index_vcif++?>
                                <?php endforeach; ?>
                              <?php } ?>
                            </div>
                          </div>
                          <div class="col-md-3 col-sm-3 col-xs-12 padding_con">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <i class="material-icons detail_property_title_icon">person</i> <b class="detail_property_title2">Relationship Manager</b>
                            </div>
                            <div class="detail_property_text2 col-md-12 col-sm-12 col-xs-12">
                              <div class="col-md-12 col-sm-12 col-xs-12">
                                <?= html_escape($ap_row['RMName']); ?>
                              </div>
                              <?php if (isset($ap_row['account_planning_member'])) { ?>
                                <?php foreach ($ap_row['account_planning_member'] as $row => $value) : ?>
                                  <div class="col-md-10 col-sm-12 col-xs-12"><?= $value['Name'] ?></div>
                                <?php endforeach; ?>
                              <?php } ?>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                              <i class="material-icons detail_property_title_icon">business_center</i> <b class="detail_property_title2">Pinjaman</b>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <div class="detail_property_text2 col-md-6 col-sm-6 col-xs-12">
                                <span class="detail_property_title2">Total :</span> 
                                <br>
                                <?= $ap_row['PinjamanTotalAP'] ?>
                              </div>
                              <div class="detail_property_text2 col-md-6 col-sm-6 col-xs-12">
                                <span class="detail_property_title2">Ratas :</span>
                                <br>
                                <?= $ap_row['PinjamanRatasAP'] ?>
                              </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                              <i class="material-icons detail_property_title_icon">account_balance_wallet</i> <b class="detail_property_title2">Simpanan</b>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <div class="detail_property_text2 col-md-6 col-sm-6 col-xs-12">
                                <span class="detail_property_title2">Total :</span>
                                <br>
                                <?= $ap_row['SimpananTotalAP'] ?>
                              </div>
                              <div class="detail_property_text2 col-md-6 col-sm-6 col-xs-12">
                                <span class="detail_property_title2">Ratas :</span>
                                <br>
                                <?= $ap_row['SimpananRatasAP'] ?>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-2 col-sm-2 col-xs-12 padding_con">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <i class="material-icons detail_property_title_icon">assistant_photo</i> <b class="detail_property_title2">Status</b>
                            </div>
                            <div class="detail_property_text2 col-md-12 col-sm-12 col-xs-12">
                              <div class="col-md-12 col-sm-12 col-xs-12">
                                <?= html_escape($ap_row['Status']); ?>
                              </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                              <i class="material-icons detail_property_title_icon">insert_chart</i> <b class="detail_property_title2">Current CPA</b>
                            </div>
                            <div class="detail_property_text2 col-md-12 col-sm-12 col-xs-12">
                              <div class="col-md-12 col-sm-12 col-xs-12">
                                <?= html_escape($ap_row['CurrentCPAAP']); ?>
                              </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                              <i class="material-icons detail_property_title_icon">local_activity</i> <b class="detail_property_title2">Value Chain</b>
                            </div>
                            <div class="detail_property_text2 col-md-12 col-sm-12 col-xs-12">
                              <div class="col-md-12 col-sm-12 col-xs-12">
                                <?= html_escape($ap_row['ValueChainAP']); ?>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-3 col-sm-3 col-xs-12 padding_con">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <button type="button" class="btn" style="font-size: 10px; line-height: 136.89%; letter-spacing: 0.15px; background: #F58C38; border-radius: 2px; color: #fff; width: 210px; height: 45px;" onclick="window.location.href='<?= base_url('tasklist/Approve/detail/'.$ap_row['AccountPlanningId']); ?>'">VIEW ACCOUNT PLANNING</button>
                            </div>
                          </div>
                          <div class="clearfix"></div>
                        </div>
                      </div>
                      <div class="detail_button_con col-md-12 col-sm-12 col-xs-12" data-toggle="collapse" href="#collapseExample<?= html_escape($ap_row['AccountPlanningId']); ?>" aria-expanded="true" aria-controls="collapseExample<?= html_escape($ap_row['AccountPlanningId']); ?>" style="cursor: pointer;">
                        <a class="detail_button">
                          LIHAT DETAIL ACCOUNT PLANNING
                        </a>
                      </div>
                    </div>
                    <div class="clearfix"></div>
                  <?php endforeach; ?>
                  <div class="pull-left">
                    <?php if (isset($links)) { ?>
                      <?php echo $links ?>
                    <?php } ?>
                  </div>
                <?php
                } else {
                ?>
                     <div>No data.</div>
                <?php
                }
                ?>
              </div>
          </div>
      </div>
    </div>
  </div>
</div>

<script src="<?= base_url(); ?>/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>


<script type="text/javascript">

  var base_url = "<?= base_url(); ?>";
  $(document).ready(function() {
  });

  function add_member(AccountPlanningId) {
    $(document).ready(function() {
      $('.modal-add-account_planning_member').modal('show');
      $('.loaderImage').show();

      var form = $('#addMemberModalForm');
      $(form).append('<input type="hidden" name="AccountPlanningId" value="'+AccountPlanningId+'" /> ');

      var member_list = $('#member_list');
      member_list.empty();

      var w ='<table width="100%" id="table_member_lists" class="table table-condensed table-striped table-hover"><thead style="background-color: #FFFFFF; color: #218FD8;" ><tr class="modal_table_title"><td width="5%"><i class="material-icons" style="color: rgba(0, 0, 0, 0.54);">check</i></td><td width="40%">Personal Number</td><td width="55%">Name</td></tr></thead>';

      $.getJSON(base_url+'tasklist/AccountPlanning/getMemberList/'+AccountPlanningId, function (data){
        if(data.length > 0){
          w += '<tbody>';
          $.each(data, function(index, item){
              w += '<tr class="modal_table_list">';
              w += '<td><label><input id="member_list" name="member_list[]" value="' + item.UserId + '" type="checkbox" class="flat"></label></td></td>';
              w += '<td>' + item.UserId + '</td>';
              w += '<td>' + item.Name + '</td>';
              w += '</tr>';
          })
          w += '</tbody>';
        }

        member_list.append(w);
        w += '</table>';        
        $('input').iCheck({
          checkboxClass: 'icheckbox_flat-green',
          radioClass: 'iradio_flat-green'
        });

        $('#table_member_lists').DataTable({
          "destroy": true,
          'dom': 'ft<"bottom"p>',
          "info": true,
          "pageLength": 10,
          "pagingType": "simple",
          "lengthChange": false,
          "columns": [
              { "orderable": false },
              null,
              null
            ]        
        });
      })
      
      var member_selected_list = $('#member_selected_list');
      member_selected_list.empty();

      var x ='<table width="100%" id="table_member_list_selected" class="table table-condensed table-striped table-hover"><thead style="background-color: #FFFFFF; color: #218FD8;" ><tr class="modal_table_title"><td width="40%">Personal Number</td><td width="55%">Name</td><td width="5%"><i class="material-icons" style="color: rgba(0, 0, 0, 0.54);">delete_sweep</i></td></tr></thead>';

      $.getJSON(base_url+'tasklist/AccountPlanning/getMemberSelected/'+AccountPlanningId, function (data){
        if(data.length > 0){
          x += '<tbody>';
          $.each(data, function(index, item){
              x += '<tr class="modal_table_list">';
              x += '<td>' + item.UserId + '</td>';
              x += '<td>' + item.RMName + '</td>';
              x += '<td><label><input id="member_selected_list" name="member_selected_list[]" value="' + item.UserId + '" type="checkbox" class="flat"></label></td></td>';
              x += '</tr>';
          })
          x += '</tbody>';
        }

        member_selected_list.append(x);
        x += '</table>';        
        $('input').iCheck({
          checkboxClass: 'icheckbox_flat-green',
          radioClass: 'iradio_flat-green'
        });

        $('#table_member_list_selected').DataTable({
          "destroy": true,
          'dom': 'ft<"bottom"p>',
          "info": true,
          "pageLength": 10,
          "pagingType": "simple",
          "lengthChange": false,
          "columns": [
              null,
              null,
              { "orderable": false }
            ]        
        });
      })
      setTimeout(function(){ 
        $('.loaderImage').hide();
      }, 1000);
    });
  }

  function retrieve_accountplanning($AccountPlanningId) {
      $.ajax({type: "GET",
          url: "<?= base_url('tasklist/AccountPlanning/retrieve/')?>" + $AccountPlanningId,
          data: '',
          beforeSend: function() {
              $('.loaderImage').show();
          },
          success:function(response) {
            console.log(response);
            new PNotify({
                title: 'Success!',
                text: 'Retireve Account Planning success.',
                type: 'success',
                styling: 'bootstrap3'
            });
            
            PNotify.prototype.options.delay = 1200;

            setTimeout(function(){ 
              $('.loaderImage').hide();
              location.reload();
            }, 2000);
/*            if(response.status === 'success'){
              new PNotify({
                  title: 'Success!',
                  text: 'Retireve Account Planning success.',
                  type: 'success',
                  styling: 'bootstrap3'
              });
              
              PNotify.prototype.options.delay = 1200;
            }else if(response.status === 'error'){
              new PNotify({
                  title: 'Error!',
                  text: response.message,
                  type: 'error',
                  styling: 'bootstrap3'
              });

              PNotify.prototype.options.delay = 1200;
            }
*/          },
          error:function(response) {
            alert('error');
          }
      });
  }
 
</script>


