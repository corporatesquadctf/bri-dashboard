<script src="<?= base_url(); ?>/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<div id="dispo_2" class="modal fade modal-add-CheckerSignerResponse" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
          <form class="form-horizontal form-label-left cmxform" id="addCheckerSignerResponseModalForm" method="POST" action="<?= site_url('tasklist/AccountPlanning/add_CheckerSignerResponse') ?>">
            <div class="modal-header" style="border-bottom: 1px solid #2980B9;">
              <div class="modal_property_title paddingleft_con">
                <i class="material-icons" style="vertical-align: middle;">description</i> <span>Add Checker & Signer</span> 
              </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12 modal-body">
                <div class="col-md-12 col-sm-12 col-xs-12">
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12" style="border-bottom: 1px solid #2980B9;">
                  <div class="col-md-6 col-sm-6 col-xs-12" style="border-right: 1px solid #C4C4C4;">
                    <p class="detail_head_title_icon">Checker</p>
                    <p id="checker_per_uker_list"></p>
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <p class="detail_head_title_icon">Signer</p>
                    <p id="signer_per_uker_list"></p>
                  </div>
                </div>
            </div>
            <div class="modal-footer" style="text-align: center;">
              <button type="button" class="btn btn-default w150" data-dismiss="modal" onclick="disableSaveButton()">Back</button>
              <button class="btn btn-warning btn-sm" type="submit" id="btn-save-disp" disabled>Submit Account Planning</button>
            </div>
          </form>
        </div>

    </div>
</div>           
<script type="text/javascript">
    $('#addCheckerSignerResponseModalForm').on('submit', function (e) {
      e.preventDefault();
      if(confirm('Anda yakin?')) {
        $.ajax({
          type: 'post',
          url : $('#addCheckerSignerResponseModalForm').attr('action'),
          data: $('#addCheckerSignerResponseModalForm').serialize(),
          dataType : 'json',
          beforeSend:function(){
            $('.modal-add-CheckerSignerResponse').modal('hide');
            $('.loaderImage').show();
          },
          error: function(jqXHR, textStatus, errorThrown){
            $('.loaderImage').hide();
            alert('<?=$this->config->item('ajax_error_message')?>');
          },
          success: function(response){
            $('.loaderImage').hide();
            if(response.status === 'success'){
              new PNotify({
                  title: 'Success!',
                  text: 'Account Planning successfully Submited.',
                  type: 'success',
                  styling: 'bootstrap3'
              });

              PNotify.prototype.options.delay = 1200;
            }else if(response.status === 'error'){
              new PNotify({
                  title: 'Error!',
                  text: response.message,
                  type: 'error',
                  styling: 'bootstrap3'
              });

              PNotify.prototype.options.delay = 1200;
            }

            setTimeout(function(){ 
              if(response.status === 'success'){
                  window.location.href= base_url+'tasklist/AccountPlanning/detail/<?= $account_planning['AccountPlanningId'] ?>';
              }else if(response.status === 'error'){
                  alert(response.message);
              }
            }, 2000);
          }
        });
      }
    });


  function account_planning_response(Response, AccountPlanningId){
    $(document).ready(function() {
      $('.loaderImage').show();
      var form = $('#addCheckerSignerResponseModalForm');
      $(form).append('<input type="hidden" name="Response" value="'+Response+'" /> ');
      $(form).append('<input type="hidden" name="AccountPlanningId" value="'+AccountPlanningId+'" /> ');


      setTimeout(function(){ 
        $('.loaderImage').hide();
      }, 1000);      

      $('.modal-add-CheckerSignerResponse').modal('show');  
      $('.loaderImage').hide();
    });
  }

</script>
