<style type="text/css">
    .form_container{
        margin: 0;
        padding: 15px 30px;
        box-shadow: 0 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
    }
    .form_container label{
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        color: rgba(0, 0, 0, 0.87);
    }
    .form_container .form-control{
        border-radius: 4px;
    }
    .form_action{
        margin: 0;
        padding: 30px 30px 0 15px;
    }
    .form_action button{
        border: 1px solid #F58C38;
        box-sizing: border-box;
        border-radius: 2px;
        font-size: 10px;
        color: #FFFFFF;
    }
    .form_action .btn_save{
        background: #F58C38;
    }
    .form_action .btn_save:hover{
        border: 1px solid #F58C38;
    }
    .form_action .btn_save:active:hover{
        background: #c4702c;
        border: 1px solid #F58C38;
    }
    .form_action .btn_cancel{
        color: #F58C38;
    }
    .form_action .btn_cancel:hover{
        border: 1px solid #F58C38;
    }
    .form_action .btn-default.focus, .btn-default:focus {
        border-color: #F58C38;
    }
    .div-action{
        display: inline-flex;
        margin: auto;
        color: #F58C38;
        float: right;
    }
    .div-action i{
        font-size: 14px;
        font-weight: normal;
        margin: auto;
    }
    .div-action label{
        color: #F58C38;
        font-size: 14px;
        font-weight: normal;
        padding-left: 5px;
        margin-bottom: 0px;
    }
    .div-action:hover i, .div-action:hover label{
        cursor: pointer;
        font-weight: bold !important;
    }
    .label-action{
        margin:0 !important; 
        padding-left:5px !important; 
        font-weight: normal !important;
    }
</style>
<div class="right_col" role="main">
  <div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel container_header">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                      <li class="breadcrumb-item">Tasklist</li>
                      <li class="breadcrumb-item"><a href="<?=base_url('tasklist/AccountPlanning');?>">Account Planning</a></li>
                      <li class="breadcrumb-item"><a href="<?=base_url('tasklist/AccountPlanning/input/'.$AccountPlanningId.'/action_plans');?>">Action Plans</a></li>
                      <li class="breadcrumb-item active" aria-current="page"><a href="<?=base_url('tasklist/AccountPlanning/input/'.$AccountPlanningId.'/action_plans/'.$BankFacilityGroupType);?>">Estimated Financial</a></li>
                      <!-- <li class="breadcrumb-item active" aria-current="page">Input Account Planning</li> -->
                  </ol>
                </nav>
                <div class="page_title">
                    <div class="pull-left"><?= $BankFacilityGroupName; ?></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_content">
            <form class="form-horizontal" id="add-<?= $AccountPlanningTab; ?>-<?= $BankFacilityGroupType; ?>" method="POST" action="<?= site_url('tasklist/AccountPlanning/input_proc') ?>" style="text-align: left;">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <label class="label_title" style="font-size: 14px; color: #218FD8;"><?= $CompanyName ?></label>
                <div class="col-md-4 col-sm-4 col-xs-12 pull-right" style="text-align: right;">
                  Notes : <span style="font-weight: 600; font-size: 12px; line-height: 24px; letter-spacing: 0.5px; color: #F58C38;"><?=Form_Notes1?></span>
                </div>
                <table width="100%" cellpadding="2" cellspacing="2" style="color: #00000; font-size: 13px;">
                  <?php if (isset($inputform[$BankFacilityGroupType][$BankFacilityGroupId]['EstimatedFinancial_detail'])) {?>
                  <?php foreach ($inputform[$BankFacilityGroupType][$BankFacilityGroupId]['EstimatedFinancial_detail'] as $rows => $EstimatedFinancial) : ?>
                  <tr>
                    <td style="vertical-align: bottom;" width="20%"><label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left; padding-bottom: 8px;"><?= $EstimatedFinancial['BankFacilityItemName'] ?></label></td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Projection Customer By IDR</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="IDRProjection[]" id="IDRProjection" class="form-control col-md-7 col-xs-12 money" data-a-sep="," value="<?= $EstimatedFinancial['IDRProjection'] ?>" style="text-align: right;"></div>
                    </td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Projection Customer By Valas</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="ValasProjection[]" id="ValasProjection" class="form-control col-md-7 col-xs-12 money" data-a-dec="." value="<?= $EstimatedFinancial['ValasProjection'] ?>" style="text-align: right;"></div>
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Target BRI By IDR</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="IDRTarget[]" id="IDRTarget" class="form-control col-md-7 col-xs-12 money" data-a-sep="," value="<?= $EstimatedFinancial['IDRTarget'] ?>" style="text-align: right;"></div>
                    </td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Target BRI By Valas</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="ValasTarget[]" id="ValasTarget" class="form-control col-md-7 col-xs-12 money" data-a-dec="." value="<?= $EstimatedFinancial['ValasTarget'] ?>" style="text-align: right;"></div>
                    </td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td colspan="4" height="30">
                      <input type="hidden" name="BankFacilityItemId[]" value="<?= $EstimatedFinancial['BankFacilityItemId']; ?>">
                      <input type="hidden" name="EstimatedFinancialId[]" value="<?= $EstimatedFinancial['EstimatedFinancialId']; ?>">
                      <input type="hidden" name="VCIF[]" value="<?= $VCIF; ?>">
                      <input type="hidden" name="EstimatedFinancialSubmit[]" value="<?= $EstimatedFinancial['EstimatedFinancialSubmit']; ?>">
                      <input type="hidden" name="InputTable" value="EstimatedFinancial">
                    </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php } ?>
                  <?php if (isset($inputform[$BankFacilityGroupType][$BankFacilityGroupId]['EstimatedFinancialAddition_detail'])) {?>
                  <?php foreach ($inputform[$BankFacilityGroupType][$BankFacilityGroupId]['EstimatedFinancialAddition_detail'] as $rows => $EstimatedFinancialAddition) : ?>
                  <tr>
                    <td style="vertical-align: bottom;" width="20%"><label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left; padding-bottom: 8px;"><?= $EstimatedFinancialAddition['BankFacilityItemAdditionName'] ?></label></td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Projection Customer By IDR</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="IDRProjectionAddition[]" id="IDRProjectionAddition" class="form-control col-md-7 col-xs-12 money" data-a-sep="," value="<?= $EstimatedFinancialAddition['IDRProjectionAddition'] ?>" style="text-align: right;"></div>
                    </td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Projection Customer By Valas</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="ValasProjectionAddition[]" id="ValasProjectionAddition" class="form-control col-md-7 col-xs-12 money" data-a-sep="," value="<?= $EstimatedFinancialAddition['ValasProjectionAddition'] ?>" style="text-align: right;"></div>
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Target BRI By IDR</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="IDRTargetAddition[]" id="IDRTargetAddition" class="form-control col-md-7 col-xs-12 money" data-a-sep="," value="<?= $EstimatedFinancialAddition['IDRTargetAddition'] ?>" style="text-align: right;"></div>
                    </td>
                    <td>
                      <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;">Target BRI By Valas</label>
                      <div class="col-md-12 col-sm-12 col-xs-12"><input type="text" name="ValasTargetAddition[]" id="ValasTargetAddition" class="form-control col-md-7 col-xs-12 money" data-a-sep="," value="<?= $EstimatedFinancialAddition['ValasTargetAddition'] ?>" style="text-align: right;"></div>
                    </td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td colspan="4" height="30">
                      <input type="hidden" name="BankFacilityItemAdditionId[]" value="<?= $EstimatedFinancialAddition['BankFacilityItemAdditionId']; ?>">
                      <input type="hidden" name="EstimatedFinancialAdditionId[]" value="<?= $EstimatedFinancialAddition['EstimatedFinancialAdditionId']; ?>">
                      <input type="hidden" name="EstimatedFinancialAdditionSubmit[]" value="<?= $EstimatedFinancialAddition['EstimatedFinancialAdditionSubmit']; ?>">
                      <input type="hidden" name="InputTableAddition" value="EstimatedFinancialAddition">
                    </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php } ?>
                  <tr>
                    <td colspan="4">
                      <input type="hidden" name="VCIF" value="<?= $VCIF; ?>">
                      <input type="hidden" name="AccountPlanningId" value="<?= $AccountPlanningId; ?>">
                      <input type="hidden" name="AccountPlanningTab" value="<?= $AccountPlanningTab; ?>">
                      <input type="hidden" name="BankFacilityGroupType" value="<?= $BankFacilityGroupType; ?>">
                    </td>
                  </tr>
                </table>

              </div>

              <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                <div class="row form_action">
                  <div style="text-align: right;">
                    <button class="btn btn-sm btn-default btn_cancel" type="button" style="width: 200px;" onclick="window.location.href='<?=base_url('tasklist/AccountPlanning/input/'.$AccountPlanningId.'/action_plans/'.$BankFacilityGroupType);?>'">BACK</button>
                    <button id="btn_save_edit_estimated_financial" class="btn btn-sm btn-primary btn_save" type="submit" style="width: 200px;">SAVE</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="<?= base_url();?>assets/auto-numeric/autoNumeric.js"></script>

<script type="text/javascript">
var base_url = "<?= base_url(); ?>";

$(document).ready(function() {

  $('.money').autoNumeric('init',{
    aForm: true,
    mDec: '0',
    vMax: '999999999999999',
    unformatOnSubmit: true
  });
  $('.portion').autoNumeric('init',{
    aForm: true,
    mDec: '0',
    vMax: '100',
    unformatOnSubmit: true
  });

  $('#add-<?= $AccountPlanningTab; ?>-<?= $BankFacilityGroupType; ?>').on('submit', function (e) {
    e.preventDefault();
    if(confirm('Anda yakin?')) {
      $.ajax({
        type: 'post',
        url : $('#add-<?= $AccountPlanningTab; ?>-<?= $BankFacilityGroupType; ?>').attr('action'),
        data: $('#add-<?= $AccountPlanningTab; ?>-<?= $BankFacilityGroupType; ?>').serialize(),
          dataType : 'html',
        beforeSend:function(){
          $('.loaderImage').show();
        },
        error: function(jqXHR, textStatus, errorThrown){
          console.log(jqXHR);
          $('.loaderImage').hide();
          alert('<?=$this->config->item('ajax_error_message')?>');
        },
        success: function(data){
          setTimeout(function(){ 
            window.location.href= base_url+'tasklist/AccountPlanning/input/<?= $AccountPlanningId; ?>/<?= $AccountPlanningTab; ?>/<?= $BankFacilityGroupType; ?>';
            $('.loaderImage').hide();
          }, 1000);
        }
      });
    }
  });
    
});

</script>


