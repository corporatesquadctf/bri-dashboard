			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion" id="accordion_Cpa" role="tablist" aria-multiselectable="true">
                        <div class="panel">
                          <a class="panel-heading" role="tab" id="headingCpa1" data-toggle="collapse" data-parent="#accordion_Cpa" href="#collapseCpa1" aria-expanded="true" aria-controls="collapseCpa1" style="border-bottom: 1px solid #ddd;">
                            <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Customer Profitability Account</h4>
                          </a>
                          <div id="collapseCpa1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingCpa1">
                            <div class="panel-body" style="padding: 0px;">
                                <div class="x_panel row content_container shadow_content_container">
                                    <div class="x_title row collapse-link" style="padding:0; margin:0;">
                                      <div class="col-xs-12">
                                          <!-- <div class="col-xs-12" style="padding: 10px 15px 5px 10px; cursor: pointer;">
                                              <label class="label_title" style="font-size: 14px; cursor: pointer;"></label>
                                              <div class="col-xs-3 pull-right">
                                                <div class="div-action" onclick="window.location.href='<?= base_url('tasklist/AccountPlanning/inputform/'); ?>'">
                                                    <i class="material-icons">edit</i>
                                                    <label>Edit Data</label>
                                                </div>
                                              </div>
                                          </div> -->
                                      </div>
                                    </div>
                                    <div class="x_content">
                                        <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con" style="padding-top: 0;">
                                            <div class="row form_action">
                                              <div style="text-align: right;">
                                                <button class="btn btn-sm btn-default btn_cancel" type="button" style="width: 200px;" onclick="">VIEW CPA</button>
                                                <button class="btn btn-sm btn-success" type="button" style="width: 200px;" onclick="account_planning_submit(<?= $account_planning['AccountPlanningId'] ?>);">SUBMIT ACCOUNT PLANNING</button>
                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row margintop_con">
            </div>

<?php $this->load->view('tasklist/inputform/checker_signer.php'); ?>
