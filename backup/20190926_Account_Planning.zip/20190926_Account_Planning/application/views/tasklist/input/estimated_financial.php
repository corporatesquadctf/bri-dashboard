                    <div class="row" style="padding-top: 3px; border-radius: 4px;">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="accordion" id="accordion_EstimatedFinancial" role="tablist" aria-multiselectable="true">
                              <?php foreach ($account_planning['EstimatedFinancial'] as $row => $value) : ?>
                                <div class="panel">
                                  <a class="panel-heading<?=$value[0]['heading_panel']?>" role="tab" id="headingEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" data-toggle="collapse" data-parent="#accordion_EstimatedFinancial" href="#collapseEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" aria-expanded="<?=$value[0]['expanded_panel']?>" aria-controls="collapseEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" style="border-bottom: 1px solid #ddd;">
                                    <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> <?=$value[0]['BankFacilityGroupName']?></h4>
                                  </a>
                                  <div id="collapseEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" class="panel-collapse<?=$value[0]['tab_panel']?>" role="tabpanel" aria-labelledby="headingEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>">
                                    <div class="panel-body" style="padding: 0px;">
                                    <?php if (isset($account_planning_vcif_list)) {?>
                                      <?php foreach ($account_planning_vcif_list as $rowss => $valuess) : ?>
                                        <div class="x_panel row content_container shadow_content_container">
                                          <div class="x_title row collapse-link" style="padding:0; margin:0;">
                                              <div class="col-xs-12">
                                                  <div class="col-xs-12" style="padding: 10px 15px 5px 10px; cursor: pointer;">
                                                      <label class="label_title" style="font-size: 16px; cursor: pointer; color: #65B6F0;"><?= $valuess['Name'] ?></label>
                                                      <div class="col-xs-3 pull-right">
                                                        <div class="div-action" onclick="window.location.href='<?= base_url('tasklist/AccountPlanning/inputform/'.$account_planning['AccountPlanningId'].'/action_plans/estimated_financial/'.$value[0]['BankFacilityGroupId'].'/'.$valuess['VCIF']); ?>'">
                                                            <i class="material-icons">edit</i>
                                                            <label>Edit Data</label>
                                                        </div>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                          <div class="x_content">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                              <div class="col-md-4 col-sm-4 col-xs-12">
                                                Notes : 
                                                <!-- <br> -->
                                                <span class="detail_property_titles2"><?=View_Notes1?></span>
                                              </div>
                                              <table width="100%" class="table" cellpadding="20" cellspacing="20">
                                                <thead style="background-color: #FFFFFF; color: #4BB8FF; font-weight: bold; font-size: 12px;" >
                                                  <tr class="modal_table_title">
                                                    <td style="text-align: left; width: 20%;">Facilities</td>
                                                    <td style="text-align: left; width: 10%;">Currency</td>
                                                    <td style="text-align: right; width: 20%;">Projection Customer</td>
                                                    <td style="text-align: right; width: 20%;">Target BRI</td>
                                                    <td style="text-align: center; width: 30%;">Portion</td>
                                                  </tr>
                                                </thead>
                                                <tbody>
                                              <?php if (isset($value['EstimatedFinancial_detail'][$valuess['VCIF']])) { ?>
                                              <?php foreach ($value['EstimatedFinancial_detail'][$valuess['VCIF']] as $rows => $EstimatedFinancial) : ?>
                                                  <tr class="modal_table_title">
                                                    <td rowspan="2" style="font-weight: bold;"><?=$EstimatedFinancial['BankFacilityItemName']?></td>
                                                    <td style="text-align: left; font-weight: bold;">IDR</td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancial['IDRProjection']?></td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancial['IDRTarget']?></td>
                                                    <td style="text-align: left;">
                                                      <div class="progress" style="height: 20px; width: 100%;">
                                                        <div class="progress-bar" data-transitiongoal="<?=$EstimatedFinancial['IDRProgressBar']?>" style="background-color: #218FD8;" title="<?=$EstimatedFinancial['IDRProgressValue']?> %"><?=$EstimatedFinancial['IDRProgressValue']?> %</div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                  <tr class="modal_table_title">
                                                    <td style="text-align: left; font-weight: bold;">Valas</td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancial['ValasProjection']?></td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancial['ValasTarget']?></td>
                                                    <td style="text-align: left;">
                                                      <div class="progress" style="height: 20px; width: 100%;">
                                                        <div class="progress-bar" data-transitiongoal="<?=$EstimatedFinancial['ValasProgressBar']?>" style="background-color: #218FD8;" title="<?=$EstimatedFinancial['ValasProgressValue']?> %"><?=$EstimatedFinancial['ValasProgressValue']?> %</div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                              <?php endforeach; ?>
                                              <?php } ?>
                                               <?php if (isset($value['EstimatedFinancialAddition_detail'][$valuess['VCIF']])) { ?>
                                              <?php foreach ($value['EstimatedFinancialAddition_detail'][$valuess['VCIF']] as $rows => $EstimatedFinancialAddition) : ?>
                                                  <tr class="modal_table_title">
                                                    <td rowspan="2" style="font-weight: bold;"><?=$EstimatedFinancialAddition['BankFacilityItemAdditionName']?></td>
                                                    <td style="text-align: left;" style="font-weight: bold;">IDR</td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancialAddition['IDRProjectionAddition']?></td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancialAddition['IDRTargetAddition']?></td>
                                                    <td style="text-align: left;">
                                                      <div class="progress" style="height: 20px; width: 100%;">
                                                        <div class="progress-bar" data-transitiongoal="<?=$EstimatedFinancialAddition['IDRProgressAdditionBar']?>" style="background-color: #218FD8;" title="<?=$EstimatedFinancialAddition['IDRProgressAdditionBar']?> %"><?=$EstimatedFinancialAddition['IDRProgressAdditionValue']?> %</div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                  <tr class="modal_table_title">
                                                    <td style="text-align: left;" style="font-weight: bold;">Valas</td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancialAddition['ValasProjectionAddition']?></td>
                                                    <td style="text-align: right;"><?=$EstimatedFinancialAddition['ValasTargetAddition']?></td>
                                                    <td style="text-align: left;">
                                                      <div class="progress" style="height: 20px; width: 100%;">
                                                        <div class="progress-bar" data-transitiongoal="<?=$EstimatedFinancialAddition['ValasProgressAdditionBar']?>" style="background-color: #218FD8;" title="<?=$EstimatedFinancialAddition['ValasProgressAdditionBar']?> %"><?=$EstimatedFinancialAddition['ValasProgressAdditionValue']?> %</div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                              <?php endforeach; ?>
                                              <?php } ?>
                                                </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        </div>
                                      <?php endforeach; ?>
                                    <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                      </div>
                    </div>
