            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion" id="accordion_Initiatives" role="tablist" aria-multiselectable="true">
                        <div class="panel">
                          <a class="panel-heading" role="tab" id="headingInitiatives1" data-toggle="collapse" data-parent="#accordion_Initiatives" href="#collapseInitiatives1" aria-expanded="true" aria-controls="collapseInitiatives1" style="border-bottom: 1px solid #ddd;">
                            <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Fundings</h4>
                          </a>
                          <div id="collapseInitiatives1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingInitiatives1">
                            <div class="panel-body" style="padding: 0px;">
                            <?php if (isset($account_planning_vcif_list)) {?>
                              <?php foreach ($account_planning_vcif_list as $rowss => $valuess) : ?>
                                <div class="x_panel row content_container shadow_content_container">
                                    <div class="x_title row collapse-link" style="padding:0; margin:0;">
                                      <div class="col-xs-12">
                                          <div class="col-xs-12" style="padding: 10px 15px 5px 10px; cursor: pointer;">
                                              <label class="label_title" style="font-size: 16px; cursor: pointer; color: #65B6F0;"><?= $valuess['Name'] ?></label>
                                              <div class="col-xs-3 pull-right">
                                              </div>
                                          </div>
                                      </div>
                                    </div>
                                    <div class="x_content">
                                        <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con" style="padding-top: 0;">
                                            <div class="detail_property_title col-md-1 col-sm-1 col-xs-12" style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                No
                                            </div>
                                            <div class="detail_property_title col-md-3 col-sm-3 col-xs-12" style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                Kebutuhan Pendanaan
                                            </div>
                                            <div class="detail_property_title col-md-2 col-sm-2 col-xs-12" style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                Jangka Waktu
                                            </div>
                                            <div class="detail_property_title col-md-3 col-sm-3 col-xs-12" style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                Nominal
                                            </div>
                                            <div class="detail_property_title col-md-3 col-sm-3 col-xs-12" style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                Description
                                            </div>
                                        </div>
                                        <?php if (isset($account_planning['Funding'][$valuess['VCIF']])) {?>
                                        <?php $index_funding = 1; ?>
                                        <?php foreach ($account_planning['Funding'][$valuess['VCIF']] as $row => $value) : ?>
                                        <div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 10px;">
                                            <div class="detail_property_text col-md-1 col-sm-1 col-xs-12">
                                                <?= $index_funding ?>
                                            </div>
                                            <div class="detail_property_text col-md-3 col-sm-3 col-xs-12">
                                                <?=$value['FundingNeed']?>
                                            </div>
                                            <div class="detail_property_text col-md-2 col-sm-2 col-xs-12">
                                                <?=$value['TimePeriod']?> Bulan
                                            </div>
                                            <div class="detail_property_text col-md-3 col-sm-3 col-xs-12">
                                                Rp. <?=number_format($value['Amount'], 2)?>
                                            </div>
                                            <div class="detail_property_text col-md-3 col-sm-3 col-xs-12">
                                                <?=$value['Description']?>
                                            </div>
                                        </div>
                                        <?php $index_funding++?>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>
                                </div>
                              <?php endforeach; ?>
                            <?php } ?>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row margintop_con">
                <div class="col-md-12 col-sm-12 col-xs-12">    
                  <div class="accordion" id="accordion_Services" role="tablist" aria-multiselectable="true">
                    <div class="panel">
                      <a class="panel-heading" role="tab" id="headingServices1" data-toggle="collapse" data-parent="#accordion_Services" href="#collapseServices1" aria-expanded="true" aria-controls="collapseServices1" style="border-bottom: 1px solid #ddd;">
                        <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Services</h4>
                      </a>
                      <div id="collapseServices1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingServices1">
                        <div class="panel-body" style="padding: 0px;">
                            <?php if (isset($account_planning_vcif_list)) {?>
                              <?php foreach ($account_planning_vcif_list as $rowss => $valuess) : ?>
                                <div class="x_panel row content_container shadow_content_container">
                                    <div class="x_title row collapse-link" style="padding:0; margin:0;">
                                      <div class="col-xs-12">
                                          <div class="col-xs-12" style="padding: 10px 15px 5px 10px; cursor: pointer;">
                                              <label class="label_title" style="font-size: 16px; cursor: pointer; color: #65B6F0;"><?= $valuess['Name'] ?></label>
                                              <div class="col-xs-3 pull-right">
                                              </div>
                                          </div>
                                      </div>
                                    </div>
                                    <div class="x_content">
                                        <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con" style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                            <div class="detail_property_title col-md-1 col-sm-1 col-xs-12 " style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                No
                                            </div>
                                            <div class="detail_property_title col-md-4 col-sm-4 col-xs-12 " style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                Service Name
                                            </div>
                                            <div class="detail_property_title col-md-2 col-sm-2 col-xs-12 " style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                Service Target
                                            </div>
                                            <div class="detail_property_title col-md-5 col-sm-5 col-xs-12 " style="color: #4BB8FF; font-weight: bold; font-weight: 14px;">
                                                Service Description
                                            </div>
                                        </div>
                                        <?php if (isset($account_planning['Service'][$valuess['VCIF']])) {?>
                                        <?php $index_service = 1; ?>
                                        <?php foreach ($account_planning['Service'][$valuess['VCIF']] as $row => $value) : ?>
                                        <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con">
                                            <div class="detail_property_text col-md-1 col-sm-1 col-xs-12 ">
                                                <?= $index_service ?>
                                            </div>
                                            <div class="detail_property_text col-md-4 col-sm-4 col-xs-12 ">
                                                <?=$value['ServiceName']?>
                                            </div>
                                            <div class="detail_property_text col-md-2 col-sm-2 col-xs-12 ">
                                                <?=$value['ServiceTarget']?> Bulan
                                            </div>
                                            <div class="detail_property_text col-md-5 col-sm-5 col-xs-12 ">
                                                <?=$value['ServiceDescription']?>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con" style="margin-top: 0; margin-bottom: 10px;">
                                            <div class="detail_property_text col-md-1 col-sm-1 col-xs-12">
                                            </div>
                                            <div class="detail_property_text col-md-11 col-sm-11 col-xs-12 ">
                                                <?php if (isset($value['TagServiceUnitKerja'])) {?>
                                                <?php foreach ($value['TagServiceUnitKerja'] as $rows => $values) : ?>
                                                <label class="label label-info"># <?=$values['TagServiceUnitKerja']?></label>
                                                <?php endforeach; ?>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <?php $index_service++?>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>
                                </div>
                              <?php endforeach; ?>
                            <?php } ?>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <div class="row margintop_con">
            </div>
