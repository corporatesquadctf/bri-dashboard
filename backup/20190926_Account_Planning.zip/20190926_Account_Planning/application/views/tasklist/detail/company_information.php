<style type="text/css">
    .panel_container{
        padding:0;
        border-radius: 4px;
    }
    .panel_container .title_container{
        border-bottom: 1px solid #e5e5e5;
        padding: 15px 30px;
        box-shadow: 0 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
    }
    .panel_container .title_container label{
        margin: 0 0 0 15px;
        font-weight: 600;
        font-size: 14px;
    }
    .content_container{
        padding: 0 0 20px 0;
        margin: 0;
        border: none;
    }
    .content_container .child_company_content{
        margin: 0;
        padding: 15px 10px;
        box-shadow: 0px 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
    }
    .shadow_content_container{
        margin: 0;
        padding: 0;
        box-shadow: 0px 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
    }
    /*
    .content_container .child_company_content button{
        font-size: 10px;
        line-height: 136.89%;
        letter-spacing: 0.15px;
        background: #F58C38;
        border-radius: 2px;
        color: #fff;
        width: 125px;
        height: 36px;
    }
    */
    .content_container .label_title{
        color: #218FD8;
        font-weight: 600;
        font-size: 14px;
    }
    .content_container .label_desc{
        color: #707070;
        font-weight: normal;
        font-size: 14px;
    }
    .child_content{
        padding: 5px 30px !important;
        display: flex;
    }
    .div-action{
        display: inline-flex;
        margin: auto;
        color: #F58C38;
        float: right;
    }
    .div-action i{
        font-size: 14px;
        font-weight: normal;
        margin: auto;
    }
    .div-action .fa-chevron-down:before {
        content: "none";
    }
    .div-action label{
        font-size: 14px;
        font-weight: normal;
        padding-left: 5px;
        margin-bottom: 0px;
    }
    .div-action:hover i, .div-action:hover label{
        cursor: pointer;
        font-weight: bold !important;
    }
    .label-action{
        margin:0 !important; 
        padding-left:5px !important; 
        font-weight: normal !important;
    }
    .div-cst{
        display: inline-flex;
        margin: 10px 0;
    }
</style>
    <div class="row">
        <div class="col-xs-12">
            <div class="x_panel panel_container">
                <div class="x_title collapse-link title_container">
                    <i class="fa fa-chevron-up" style="color:#218FD8;"></i>
                    <label>Group Overview</label>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content content_container">
                <?php 
                    $iAssignedCompany = 0;
                    foreach($account_planning['AssignedCompany'] as $rowAssignedCompany): ?>
                    <div class="x_panel row content_container shadow_content_container">
                        <div class="x_title row collapse-link" style="padding:0; margin:0;">
                            <div class="col-xs-12 " style="padding:0;">
                                <div class="col-xs-12" style="padding: 10px 30px 5px 30px; cursor: pointer;">
                                    <label class="label_title" style="font-size: 14px; cursor: pointer;"><?= $rowAssignedCompany->Name; ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="x_content" style="padding:0;">
                            <div class="col-xs-12 col-md-12" style="padding:10px 20px 5px 20px;">
                                <div class="row form-group">
                                    <div class="col-xs-4">
                                        <div class="col-xs-12">
                                            <label class="label_title">ADDRESSS</label>
                                        </div>
                                        <div class="col-xs-12">
                                            <?php
                                                if(!empty($account_planning['GroupOverview'][$iAssignedCompany]))
                                                echo '<label class="label_desc">'.$account_planning['GroupOverview'][$iAssignedCompany][0]['Address1'].'</label>'; 
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-xs-4">
                                        <div class="col-xs-12">
                                            <label class="label_title">GLOBAL RATINGS</label>
                                        </div>
                                        <div class="col-xs-12">
                                            <?php 
                                                if(!empty($account_planning['GroupOverview'][$iAssignedCompany]))
                                                echo '<label class="label_desc">'.$account_planning['GroupOverview'][$iAssignedCompany][0]['GlobalRatingName'].' '.$account_planning['GroupOverview'][$iAssignedCompany][0]['GlobalRatingDescription'].'</label>';
                                            ?>
                                        </div>  
                                    </div>
                                    <div class="col-xs-4">
                                        <div class="col-xs-12">
                                            <label class="label_title">DOMESTIC RATINGS</label>
                                        </div>
                                        <div class="col-xs-12">
                                            <?php 
                                                if(!empty($account_planning['GroupOverview'][$iAssignedCompany]))
                                                echo '<label class="label_desc">'.$account_planning['GroupOverview'][$iAssignedCompany][0]['DomesticRating'].'</label>'; 
                                            ?>
                                        </div>                      
                                    </div>
                                </div>
                                <div class="row form-group">
                                    <div class="col-xs-4">
                                        <div class="col-xs-12">
                                            <label class="label_title">CITY</label>
                                        </div>
                                        <div class="col-xs-12">
                                            <?php 
                                                if(!empty($account_planning['GroupOverview'][$iAssignedCompany]))
                                                echo '<label class="label_desc">'.$account_planning['GroupOverview'][$iAssignedCompany][0]['Province'].'</label>'; 
                                            ?>
                                        </div>                   
                                    </div>
                                    <div class="col-xs-4">
                                        <div class="col-xs-12">
                                            <label class="label_title">INDUSTRY</label>
                                        </div>
                                        <div class="col-xs-12">
                                            <?php 
                                                if(!empty($account_planning['GroupOverview'][$iAssignedCompany]))
                                                echo '<label class="label_desc">'.$account_planning['GroupOverview'][$iAssignedCompany][0]['IndustryName'].'</label>';
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-xs-4">
                                        <div class="col-xs-12">
                                            <label class="label_title">INDUSTRY TREND</label>
                                        </div>
                                        <div class="col-xs-12">
                                            <?php 
                                                if(!empty($account_planning['GroupOverview'][$iAssignedCompany]))
                                                echo '<label class="label_desc">'.$account_planning['GroupOverview'][$iAssignedCompany][0]['IndustryTrend'].'</label>';
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-4">
                                        <div class="col-xs-12">
                                            <label class="label_title">LIFE CYCLE</label>
                                        </div>
                                        <div class="col-xs-12">
                                            <?php 
                                                if(!empty($account_planning['GroupOverview'][$iAssignedCompany]))
                                                echo '<label class="label_desc">'.$account_planning['GroupOverview'][$iAssignedCompany][0]['LifeCycle'].'</label>'; 
                                            ?>  
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $iAssignedCompany++; endforeach; ?>                    
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="x_panel panel_container">
                <div class="x_title collapse-link title_container">
                    <i class="fa fa-chevron-up" style="color:#218FD8;"></i>
                    <label>Key Shareholder</label>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content content_container">
                    <div class="row child_company_content" style="width: 100%; padding: 15px 20px;">
                        <div class="col-sm-6 col-xs-12" style="vertical-align: middle; text-align: center;">
                            <canvas id="shareholder-chart" height="150" width="150"></canvas>
                        </div>
                        <div class="col-sm-6 col-xs-12" style="vertical-align: middle; text-align: left;">
                            <table width="100%">
                                <?php if (isset($account_planning['Shareholder'])) {?>
                                    <?php foreach ($account_planning['Shareholder'] as $row => $value) : ?>
                                        <tr>
                                            <td><i class="fa fa-square" style="margin:0 5px 0  0; color:<?= $value['Color']; ?>"></i></td>
                                            <td><label class="label_desc" style="margin:0; color:#505D6F; font-weight:normal;"><?=$value['Name']?></label></td>
                                            <td style="text-align:right;"><label class="label_desc" style="margin:0; color:#218FD8; font-weight:600;"><?= $value['PortionPercentage']?> %</label></td>
                                            <td style="text-align:right;"><label class="label_desc" style="margin:0; color:#505D6F; font-weight:600;"><?= number_format($value['Value'], 0)?></label></td>
                                        </tr>
                                    <?php endforeach; ?>
                                        <tr>
                                            <td></td>
                                            <td><label class="label_desc" style="margin:15px 0 0 0; color:#505D6F; font-weight:bold;">Total</label></td>
                                            <td style="text-align:right;"><label class="label_desc" style="margin:15px 0 0 0; color:#218FD8; font-weight:600;"><?= number_format($account_planning['totalPortionShareholderPercentage'], 2); ?> %</label></td>
                                            <td style="text-align:right;"><label class="label_desc" style="margin:15px 0 0 0; color:#505D6F; font-weight:600;"><?= number_format($account_planning['totalPortionShareholder'], 0); ?></label></td>
                                        </tr>
                                <?php } ?>
                            </table>
                        </div>
                    </div>             
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="x_panel panel_container">
                <div class="x_title collapse-link title_container">
                    <i class="fa fa-chevron-up" style="color:#218FD8;"></i>
                    <label>Business Process and Organization</label>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content content_container">
                    <!-- GROUP STRUCTURE -->
                    <div class="row content_container shadow_content_container">
                        <div class="col-xs-12" style="padding: 0;">
                            <div class="col-xs-12" style="padding: 10px 30px 5px 30px;">
                                <label class="label_title" style="font-size: 14px;">Group Structure</label>
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-12" style="padding:0;">
                            <?php if (!empty($account_planning['FileStructure'][2])) {
                                $jmlGroupStructure = count($account_planning['FileStructure'][2]);
                                $i = 1;
                                foreach ($account_planning['FileStructure'][2] as $row => $value) : 
                                ?>
                                    <div class="col-xs-12 child_content" style="padding-right: 30px !important;">
                                        <div style="width:100%;">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <a href="<?php echo base_url().'uploads/account_planning/'.$account_planning['AccountPlanningId'].'/'.$value->FilePath;?>" target="_blank">
                                                    <i class="fa fa-file-pdf-o" style="color:red; cursor: pointer;"></i>
                                                    <label class="label_desc" style="margin-left: 5px; cursor: pointer;"><?= $value->FilePath; ?></label>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>                                    
                                <?php $i++; endforeach; ?>
                            <?php
                                }
                            ?>
                        </div>
                    </div>
                    <!-- BUSINESS PROCESS -->
                    <div class="row content_container shadow_content_container">
                        <div class="col-xs-12" style="padding: 0;">
                            <div class="col-xs-12" style="padding: 10px 30px 5px 30px;">
                                <label class="label_title" style="font-size: 14px;">Business Process</label>
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-12" style="padding:0;">
                            <?php if (!empty($account_planning['FileStructure'][1])) {
                                $jmlBusinessProcess = count($account_planning['FileStructure'][1]);
                                $i = 1;
                                foreach ($account_planning['FileStructure'][1] as $row => $value) : 
                                ?>
                                    <div class="col-xs-12 child_content" style="padding-right: 30px !important;">
                                        <div style="width:2%;"><label class="label_desc" style="margin-bottom: 0px;"><?= $i; ?>.</label></div>
                                        <div style="width:98%;">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="col-xs-4">
                                                        <label class="label_desc"><?= $value->Name; ?></label>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <a href="<?php echo base_url().'uploads/account_planning/'.$account_planning['AccountPlanningId'].'/'.$value->VCIF.'/'.$value->FilePath;?>" target="_blank">
                                                        <i class="fa fa-file-pdf-o" style="color:red; cursor: pointer;"></i> 
                                                        <label class="label_desc" style="margin-left: 5px; cursor: pointer;"><?= $value->FilePath; ?></label>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>                                    
                                <?php $i++; endforeach; ?>
                            <?php
                                }
                            ?>
                        </div>
                    </div>
                    <!-- COMPANY STRUCTURE -->
                    <div class="row content_container shadow_content_container">
                        <div class="col-xs-12" style="padding: 0;">
                            <div class="col-xs-12" style="padding: 10px 30px 5px 30px;">
                                <label class="label_title" style="font-size: 14px;">Company Structure</label>
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-12" style="padding:0;">
                            <?php if (!empty($account_planning['FileStructure'][3])) {
                                $jmlCompanyStructure = count($account_planning['FileStructure'][3]);
                                $i = 1;
                                foreach ($account_planning['FileStructure'][3] as $row => $value) : 
                                ?>
                                    <div class="col-xs-12 child_content" style="padding-right: 30px !important;">
                                        <div style="width:2%;"><label class="label_desc" style="margin-bottom: 0px;"><?= $i; ?>.</label></div>
                                        <div style="width:98%;">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="col-xs-4">
                                                        <label class="label_desc"><?= $value->Name; ?></label>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <a href="<?php echo base_url().'uploads/account_planning/'.$account_planning['AccountPlanningId'].'/'.$value->VCIF.'/'.$value->FilePath;?>" target="_blank">
                                                        <i class="fa fa-file-pdf-o" style="color:red; cursor: pointer;"></i> 
                                                        <label class="label_desc" style="margin-left: 5px; cursor: pointer;"><?= $value->FilePath; ?></label>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>                                    
                                <?php $i++; endforeach; ?>
                            <?php
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="x_panel panel_container">
                <div class="x_title collapse-link title_container">
                    <i class="fa fa-chevron-up" style="color:#218FD8;"></i>
                    <label>Strategic Plan</label>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content content_container">                        
                    <?php 
                    $iAssignedCompany = 0;
                    foreach($account_planning['AssignedCompany'] as $rowAssignedCompany): ?>
                    <div class="x_panel row content_container shadow_content_container">
                        <div class="x_title row collapse-link" style="padding:0; margin:0;">
                            <div class="col-xs-12" style="padding:0;">
                                <div class="col-xs-12" style="padding: 10px 30px 5px 30px; cursor: pointer;">
                                    <label class="label_title" style="font-size: 14px; cursor: pointer;"><?= $rowAssignedCompany->Name; ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="x_content" style="padding:0;">
                            <div class="col-xs-12 col-md-12" style="padding:0;">
                                <?php if (!empty($account_planning['StrategicPlan'][$iAssignedCompany])) {
                                        $jmlStrategicPlan = count($account_planning['StrategicPlan'][$iAssignedCompany]);
                                        $index_strategic = 1;
                                        foreach ($account_planning['StrategicPlan'][$iAssignedCompany] as $row) : 
                                        ?>
                                        <div class="col-xs-12 child_content">
                                            <div style="width:2%;"><label class="label_desc"><?= $index_strategic; ?>.</label></div>
                                            <div style="width:18%;"><label class="label_desc" style="font-weight: bold;"><?= $row->StrategicPlanTypeName; ?></label></div>
                                            <div style="width:80%;"><label class="label_desc"><?= $row->Name; ?></label></div>
                                        </div>
                                    <?php $index_strategic++; endforeach; ?>
                                <?php
                                    }
                                ?>
                            </div>
                        </div>
                    </div>   
                    <?php $iAssignedCompany++; endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="x_panel panel_container">
                <div class="x_title collapse-link title_container">
                    <i class="fa fa-chevron-up" style="color:#218FD8;"></i>
                    <label>Coverage Mapping</label>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content content_container">
                    <?php 
                    $iAssignedCompany = 0;
                    foreach($account_planning['AssignedCompany'] as $rowAssignedCompany): ?>
                    <div class="x_panel row content_container shadow_content_container">
                        <div class="x_title row collapse-link" style="padding:0; margin:0;">
                            <div class="col-xs-12" style="padding: 0;">
                                <div class="col-xs-12" style="padding: 10px 30px 5px 30px; cursor: pointer;">
                                    <label class="label_title" style="font-size: 14px; cursor: pointer;"><?= $rowAssignedCompany->Name; ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="x_content" style="padding:0;">
                            <div class="col-xs-12 col-md-12" style="padding:0;">
                                <?php if (!empty($account_planning['CoverageMapping'][$iAssignedCompany])) {
                                        $jmlCoverageMapping = count($account_planning['CoverageMapping'][$iAssignedCompany]);
                                        $i = 1;
                                        foreach ($account_planning['CoverageMapping'][$iAssignedCompany] as $row) : 
                                ?>                                    
                                        <div class="col-xs-12 child_content">
                                            <div style="width:2%;"><label class="label_desc" style="margin-bottom: 0px;"><?= $i; ?>.</label></div>
                                            <div style="width:98%;">
                                                <div class="row">
                                                    <div class="col-xs-3">
                                                        <div class="col-xs-12">
                                                            <label class="label_title">Client Name</label>
                                                        </div>
                                                        <div class="col-xs-12">
                                                            <label class="label_desc"><?= $row->ClientName; ?></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-3">
                                                        <div class="col-xs-12">
                                                            <label class="label_title">Client Contact</label>
                                                        </div>
                                                        <div class="col-xs-12">
                                                            <label class="label_desc"><?= $row->ContactNumber; ?></label>
                                                        </div>  
                                                    </div>
                                                    <div class="col-xs-3">
                                                        <div class="col-xs-12">
                                                            <label class="label_title">Client Position</label>
                                                        </div>
                                                        <div class="col-xs-12">
                                                            <label class="label_desc"><?= $row->ClientPosition; ?></label>
                                                        </div>                      
                                                    </div>
                                                    <div class="col-xs-3">
                                                        <div class="col-xs-12">
                                                            <label class="label_title">Other Information</label>
                                                        </div>
                                                        <div class="col-xs-12">
                                                            <label class="label_desc"><?= $row->OtherInformation; ?></label>
                                                        </div>  
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-xs-3">
                                                        <div class="col-xs-12">
                                                            <label class="label_title">Bank Person Name</label>
                                                        </div>
                                                        <div class="col-xs-12">
                                                            <label class="label_desc"><?= $row->BankPerson; ?></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-3">
                                                        <div class="col-xs-12">
                                                            <label class="label_title">Bank Contact</label>
                                                        </div>
                                                        <div class="col-xs-12">
                                                            <label class="label_desc"><?= $row->BankContact; ?></label>
                                                        </div>  
                                                    </div>
                                                    <div class="col-xs-3">
                                                        <div class="col-xs-12">
                                                            <label class="label_title">Bank Position</label>
                                                        </div>
                                                        <div class="col-xs-12">
                                                            <label class="label_desc"><?= $row->BankPosition; ?></label>
                                                        </div>                      
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    <?php $i++; endforeach; ?>
                                <?php
                                    }
                                ?>
                            </div>
                        </div>
                    </div>   
                    <?php $iAssignedCompany++; endforeach; ?>
                </div>            
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6 col-xs-12">
            <div class="x_panel panel_container">
                <div class="x_title collapse-link title_container">
                    <i class="fa fa-chevron-up" style="color:#218FD8;"></i>
                    <label>Recent Activities</label>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content content_container">                    
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xs-12">
            <div class="x_panel panel_container">
                <div class="x_title collapse-link title_container">
                    <i class="fa fa-chevron-up" style="color:#218FD8;"></i>
                    <label>CST Member</label>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content content_container">
                    <?php foreach($account_planning['CSTMember'] as $rowCSTMember): ?>
                        <div class="row content_container shadow_content_container" style="padding: 15px 30px;">
                            <div class="col-xs-12 col-sm-3">
                                <?php if($rowCSTMember->ProfilePicture != null){ ?>
                                
                                <?php }else{ ?>
                                    <img class="img-responsive" src="<?= base_url('/assets/images/user_profile/default.png'); ?>">
                                <?php } ?>
                            </div>
                            <div class="col-xs-12 col-sm-9">
                                <div class="row">
                                    <div class="col-xs-12">
                                        <label style="font-size: 16px; font-weight: 600; color: #252525;"><?= $rowCSTMember->UserName; ?></label>
                                        <label style="font-size: 12px; font-weight: normal; color: #707070;"> - <?= $rowCSTMember->Title; ?></label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12" style="border-bottom: 1px solid #BFC8D5;">                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-7">
                                        <div class="div-cst">
                                            <i class="material-icons" style="font-size: 18px; color: #218FD8; margin-right: 2px;">person_pin</i>
                                            <label style="font-size: 12px; font-weight: normal; color: #707070;"><?= $rowCSTMember->UkerName; ?></label>
                                        </div>                               
                                    </div>
                                    <div class="col-xs-5">
                                        <div class="div-cst">
                                            <i class="material-icons" style="font-size: 18px; color: #218FD8; margin-right: 2px;">event</i>
                                            <label style="font-size: 12px; font-weight: normal; color: #707070;"><?= date("d F Y", strtotime($rowCSTMember->CreatedDate)); ?></label>
                                        </div>                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>


    <script>
        var labelShareholder = [];
        var dataShareholder = [];
        var colorShareholder = [];        
        <?php
            foreach($account_planning['Shareholder'] as $row):
        ?>
            labelShareholder.push('<?= $row['Name']; ?>');
            dataShareholder.push(<?= $row['Value']; ?>);
            colorShareholder.push('<?= $row['Color']; ?>');
        <?php
            endforeach;
        ?>

        $(document).ready(function() {
            $('.btn_edit_company_overview').click(function(){

                var vcif = $(this).data('id');
                window.location.href= "<?= base_url('tasklist/AccountPlanning/editgroupoverview/'.$account_planning['AccountPlanningId'].'/company_information'); ?>/"+vcif;

            });
            
            init_shareholder_chart(dataShareholder, labelShareholder, colorShareholder);
            $('.btn_edit_key_shareholder').click(function(){
                window.location.href= "<?= base_url('tasklist/AccountPlanning/editkeyshareholders/'.$account_planning['AccountPlanningId'].'/company_information'); ?>";
            });

            $('.btn_edit_business_process_organitation').click(function(){
                window.location.href= "<?= base_url('tasklist/AccountPlanning/editbusinessprocessorganisation/'.$account_planning['AccountPlanningId'].'/company_information'); ?>";
            });

            $('.btn_edit_strategic_plan').click(function(){
                var vcif = $(this).data('id');
                window.location.href= "<?= base_url('tasklist/AccountPlanning/editstrategicplan/'.$account_planning['AccountPlanningId'].'/company_information'); ?>/"+vcif;
            });

            $('.btn_edit_coverage_mapping').click(function(){
                var vcif = $(this).data('id');
                window.location.href= "<?= base_url('tasklist/AccountPlanning/editcoveragemapping/'.$account_planning['AccountPlanningId'].'/company_information'); ?>/"+vcif;
            });
        });

        function init_shareholder_chart(dataShareholder, labelShareholder, colorShareholder){               
            if( typeof (Chart) === 'undefined'){ return; }                
            if ($('#shareholder-chart').length){                    
            var chart_doughnut_settings = {
                    type: 'doughnut',
                    tooltipFillColor: "rgba(51, 51, 51, 0.55)",
                    data: {
                        labels: labelShareholder,
                        datasets: [{
                            data: dataShareholder,
                            backgroundColor: colorShareholder
                        }]
                    },
                    options: { 
                        legend: false, 
                        responsive: false,
                        tooltips: {
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    var dataset = data.datasets[tooltipItem.datasetIndex];
                                    var meta = dataset._meta[Object.keys(dataset._meta)[0]];
                                    var total = meta.total;
                                    var currentValue = dataset.data[tooltipItem.index];
                                    var percentage = parseFloat((currentValue/total*100).toFixed(2));
                                    return percentage+' %';
                                }
                            }
                        }
                    },
                    
                }
            
                $('#shareholder-chart').each(function(){                        
                    var chart_element = $(this);
                    var chart_doughnut = new Chart( chart_element, chart_doughnut_settings);                        
                });                
            }               
        }        
    </script>