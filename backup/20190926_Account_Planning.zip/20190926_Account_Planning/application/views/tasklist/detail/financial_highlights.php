<style type="text/css">
.detail_title {
  font-weight: 600;
  font-size: 14px;
  line-height: 136.89%;
  display: flex;
  align-items: center;
  letter-spacing: 0.25px;
  color: #707070;
}
.detail_property_titles {
  font-weight: 600;
  font-size: 12px;
  line-height: 24px;
  letter-spacing: 0.5px;
  color: #218FD8;
}

  .div-action{
      display: inline-flex;
      margin: auto;
      color: #F58C38;
      float: right;
  }
  .div-action i{
      font-size: 14px;
      font-weight: normal;
      margin: auto;
  }
  .div-action .fa-chevron-down:before {
      content: "none";
  }
  .div-action label{
      font-size: 14px;
      font-weight: normal;
      padding-left: 5px;
      margin-bottom: 0px;
  }
  .div-action:hover i, .div-action:hover label{
      cursor: pointer;
      font-weight: bold !important;
  }
  .label-action{
      margin:0 !important; 
      padding-left:5px !important; 
      font-weight: normal !important;
  }

</style>

                    <div class="row" style="padding-top: 3px; border-radius: 4px;">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="accordion" id="accordion_FinancialHighlight" role="tablist" aria-multiselectable="true">
                            <?php foreach ($account_planning['FinancialHighlight'] as $row => $value) : ?>
                            <div class="panel">
                              <a class="panel-heading<?=$value[0]['heading_panel']?>" role="tab" id="headingFinancialHighlight<?=$value[0]['FinancialHighlightGroupId']?>" data-toggle="collapse" data-parent="#accordion_FinancialHighlight" href="#collapseFinancialHighlight<?=$value[0]['FinancialHighlightGroupId']?>" aria-expanded="<?=$value[0]['expanded_panel']?>" aria-controls="collapseFinancialHighlight<?=$value[0]['FinancialHighlightGroupId']?>" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> <?=$value[0]['FinancialHighlightGroupName']?></h4>
                              </a>
                              <div id="collapseFinancialHighlight<?=$value[0]['FinancialHighlightGroupId']?>" class="panel-collapse<?=$value[0]['tab_panel']?>" role="tabpanel" aria-labelledby="headingFinancialHighlight<?=$value[0]['FinancialHighlightGroupId']?>">
                                <div class="panel-body" style="min-height: 70px;">
                                  <?php if ($value[0]['FinancialHighlightGroupId'] == 1 || $value[0]['FinancialHighlightGroupId'] == 2 || $value[0]['FinancialHighlightGroupId'] == 3 || $value[0]['FinancialHighlightGroupId'] == 5 || $value[0]['FinancialHighlightGroupId'] == 6) { ?>
                                    <?php if ($value[0]['FinancialHighlightGroupId'] == 1 || $value[0]['FinancialHighlightGroupId'] == 2) { ?>
                                    <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                                      <div class="col-md-4 col-sm-4 col-xs-12">
                                        Notes : 
                                        <!-- <br> -->
                                        <span class="detail_property_title">#All values in million</span>
                                      </div>
                                      <div class="col-md-4 col-sm-4 col-xs-12" style="height: 40px; vertical-align: bottom;">
                                        <!-- <br> -->
                                        <!-- <span class="detail_property_titles2">#Currency in <?= $account_planning['Currency'] ?></span> -->
                                      </div>
                                    </div>
                                  <?php  } ?>
                                    <div class="col-md-12 col-sm-12 col-xs-12 margintop_con" style="border-bottom: 1px solid #ddd;">
                                      <div class="col-md-9 col-sm-9 col-xs-12">
                                          <p class="detail_property_titles"></p>
                                          <?php if ($value[0]['FinancialHighlightGroupId'] == 3 || $value[0]['FinancialHighlightGroupId'] == 5 || $value[0]['FinancialHighlightGroupId'] == 6) { ?>
                                            <canvas id="FinancialHighlight_barChart_<?=$value[0]['FinancialHighlightGroupId']?>"></canvas>
                                          <?php } else {?>
                                            <canvas id="FinancialHighlight_lineChart_<?=$value[0]['FinancialHighlightGroupId']?>" height="100px"></canvas>
                                          <?php } ?>
                                      </div>
                                      <div class="col-md-3 col-sm-3 col-xs-12">
                                        <table width="100%" class="table-condensed table-hover">
                                          <tbody>
                                            <?php if (isset($value['FinancialHighlight_details'])) {?>
                                            <?php $indexss = 0; ?>
                                            <?php foreach ($value['FinancialHighlight_details'] as $rows) : ?>
                                            <tr>
                                              <td width="2%" style="vertical-align: middle;">
                                                <div style="background: <?= $account_planning['backgroundColors'][$indexss] ?>;  width: 12px; height: 12px;"></div>
                                              </td>
                                              <td><?=$rows[0]['FinancialHighlightItemName']?></td>
                                            </tr>
                                            <?php $indexss++?>
                                            <?php endforeach; ?>
                                            <?php } ?>
                                          </tbody>
                                        </table>                                    
                                      </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                                      <?php //if ($value[0]['FinancialHighlightGroupId'] == 3 || $value[0]['FinancialHighlightGroupId'] == 6) { ?>
                                        <table width="100%" class="table table-condensed table-striped table-hover">
                                          <thead>
                                            <tr>
                                              <td>Table Sheet</td>
                                              <td style="text-align: right;"><?= $account_planning['Years'][0] ?></td>
                                              <td style="text-align: right;"><?= $account_planning['Years'][1] ?></td>
                                              <td style="text-align: right;"><?= $account_planning['Years'][2] ?></td>
                                            </tr>
                                          </thead>
                                          <tbody>
                                        <?php if (isset($value['FinancialHighlight_details'])) {?>
                                            <?php foreach ($value['FinancialHighlight_details'] as $rows) : ?>
                                            <tr>
                                              <td><?=$rows[0]['FinancialHighlightItemName']?></td>
                                              <td style="text-align: right;"><?= $rows[$account_planning['Years'][0]]['Amount'] ?></td>
                                              <td style="text-align: right;"><?= $rows[$account_planning['Years'][1]]['Amount'] ?></td>
                                              <td style="text-align: right;"><?= $rows[$account_planning['Years'][2]]['Amount'] ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php } ?>
                                      <?php //} else {?>
                                        <?php if (isset($value['FinancialHighlight_details2'])) {?>
                                            <?php foreach ($value['FinancialHighlight_details2'] as $rows) : ?>
                                            <tr>
                                              <td><?=$rows[0]['FinancialHighlightItemName']?></td>
                                              <td style="text-align: right;"><?= $rows[$account_planning['Years'][0]]['Amount'] ?></td>
                                              <td style="text-align: right;"><?= $rows[$account_planning['Years'][1]]['Amount'] ?></td>
                                              <td style="text-align: right;"><?= $rows[$account_planning['Years'][2]]['Amount'] ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php } ?>
                                          </tbody>
                                        </table>
                                      <?php //} ?>
                                    </div>
                                  <?php } else if ($value[0]['FinancialHighlightGroupId'] == 4) { ?>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                      <table width="100%" class="table table-condensed table-striped table-hover">
                                        <thead>
                                          <tr>
                                            <td>Table Sheet</td>
                                            <td style="text-align: right;"><?= $account_planning['Years'][0] ?></td>
                                            <td style="text-align: right;"><?= $account_planning['Years'][1] ?></td>
                                            <td style="text-align: right;"><?= $account_planning['Years'][2] ?></td>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <?php foreach ($value['FinancialHighlight_details'] as $rows) : ?>
                                          <tr>
                                            <td><?=$rows[0]['FinancialHighlightItemName']?></td>
                                            <td style="text-align: right;"><?= $rows[$account_planning['Years'][0]]['Amount'] ?></td>
                                            <td style="text-align: right;"><?= $rows[$account_planning['Years'][1]]['Amount'] ?></td>
                                            <td style="text-align: right;"><?= $rows[$account_planning['Years'][2]]['Amount'] ?></td>
                                          </tr>
                                          <?php endforeach; ?>
                                        </tbody>
                                      </table>
                                    </div>
                                  <?php } ?>
                                </div>
                              </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                      </div>
                    </div>
