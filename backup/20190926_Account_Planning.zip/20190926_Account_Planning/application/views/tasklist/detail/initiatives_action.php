<style type="text/css">
.detail_title {
  font-weight: 600;
  font-size: 14px;
  line-height: 136.89%;
  display: flex;
  align-items: center;
  letter-spacing: 0.25px;
  color: #707070;
}
.detail_property_titles {
  font-weight: 600;
  font-size: 12px;
  line-height: 24px;
  letter-spacing: 0.5px;
  color: #218FD8;
}
.detail_property_titles2 {
  font-weight: 600;
  font-size: 12px;
  line-height: 24px;
  letter-spacing: 0.5px;
  color: #F58C38;
}
</style>

                          <div class="row" style="padding-top: 3px; border-radius: 4px;">
                            <div class="col-md-12 col-sm-12 col-xs-12">    
                              <div class="accordion" id="accordion_Initiatives" role="tablist" aria-multiselectable="true">
                                <div class="panel">
                                  <a class="panel-heading" role="tab" id="headingEstimatedFinancialInitiatives1" data-toggle="collapse" data-parent="#accordion_EstimatedFinancial" href="#collapseEstimatedFinancialInitiatives1" aria-expanded="true" aria-controls="collapseEstimatedFinancialInitiatives1" style="border-bottom: 1px solid #ddd;">
                                    <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Initiatives and Action Plan</h4>
                                  </a>
                                  <div id="collapseEstimatedFinancialInitiatives1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingEstimatedFinancialInitiatives1">
                                    <div class="panel-body" style="padding: 0px;">
                                    <?php if (isset($account_planning_vcif_list)) {?>
                                      <?php foreach ($account_planning_vcif_list as $rowss => $valuess) : ?>
                                        <div class="x_panel row content_container shadow_content_container">
                                          <div class="x_title row collapse-link" style="padding:0; margin:0;">
                                              <div class="col-xs-12">
                                                  <div class="col-xs-12" style="padding: 10px 15px 5px 10px; cursor: pointer;">
                                                    <label class="label_title" style="font-size: 16px; cursor: pointer; color: #65B6F0;"><?= $valuess['Name'] ?></label>
                                                      <div class="col-xs-3 pull-right">
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                          <div class="x_content">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                            <table width="100%" class="table table-condensed table-striped table-hover">
                                              <thead style="background-color: #FFFFFF; color: #4BB8FF; font-weight: bold;" >
                                                <tr>
                                                  <td style="text-align: left; width: 5%">No</td>
                                                  <td style="text-align: left; width: 35%">Initiatives</td>
                                                  <td style="text-align: left; width: 15%">Action Plans</td>
                                                  <td style="text-align: left; width: 45%">Description</td>
                                                </tr>
                                              </thead>
                                              <tbody>
                                          <?php if (!empty($account_planning['InitiativeAction'][$valuess['VCIF']])) {?>
                                          <?php $indexInitiativeAction = 1; ?>
                                          <?php foreach ($account_planning['InitiativeAction'][$valuess['VCIF']] as $row => $value) : ?>
                                                <tr>
                                                  <td style="text-align: left;"><?= $indexInitiativeAction ?></td>
                                                  <td style="text-align: left;"><?=$value['Name']?></td>
                                                  <td style="text-align: left;"><?=$value['DateTimePeriod']?></td>
                                                  <td style="text-align: left;"><?=$value['Description']?></td>
                                                </tr>
                                            <?php $indexInitiativeAction++?>
                                            <?php endforeach; ?>
                                            <?php } ?>
                                              </tbody>
                                            </table>
                                            </div>
                                          </div>
                                        </div>
                                      <?php endforeach; ?>
                                    <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>

                            </div>
                          </div>