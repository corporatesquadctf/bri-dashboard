<style type="text/css">
    .dataTables_paginate {
        float: left !important;
    }
    .dataTables_info {
        width: 40%;
        float: left;
        margin-left: 25px;
    }
    .dataTables_filter {
        width: auto;
        float: right;
        text-align: right;
    }
    .panel_toolbox>li>a {
        padding: 5px 10px;
        color: #000;
        font-size:12px;
    }
    .update_link{
        vertical-align:middle; 
        text-decoration: none; 
        color:#337ab7;
    }
    thead{
        background-color:#218FD8;
    }
    .pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover {
        z-index: 3;
        color: #fff;
        cursor: default;
        background-color: #218FD8;
        border-color: #337ab7;
    }
    .modal-dialog-pipeline{
        box-shadow: 1px 5px 5px #2980b9;
    }
    .modal-header-pipeline{
        padding: 15px 50px 0 50px;
        border-bottom: none;
    }
    .modal-body-pipeline{
        padding: 15px 50px;
    }
    .modal-title-pipeline{
        font-weight: bold;
        color: #337ab7;
        font-size: 25px;
    }
    .modal-divider-header-pipeline{
        margin-top:15px;
        border-bottom: 1px solid #337ab7;
    }
    .modal-footer-pipeline{
        padding: 15px 50px;
        text-align: right;
        border-top: none;
    }
    .detail_pipeline{
            font-weight: normal;
    }
    .search-form{
        margin-bottom: 0px;
        font-weight: normal;
    }
    table { 
        border-collapse: separate; 
        border-spacing: 0 10px; 
        margin-top: -10px;
    }
    tr{
        box-shadow: 0px 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
    }
    tr th{
        border: none !important;
    }
    td {
        border: 1px solid #ddd;
        border-style: solid none;
        padding: 10px;
        background: #FFF;        
    }
    td>a:hover{
        font-weight:bold;
    }
    td:first-child{
        border-left-style: solid;
        border-top-left-radius: 4px; 
        border-bottom-left-radius: 4px;
    }
    td:last-child{
        border-right-style: solid;
        border-bottom-right-radius: 4px; 
        border-top-right-radius: 4px; 
    }
    thead{
        color:#218FD8;
    }
    thead tr{
        background-color:#F7F7F7;
        box-shadow: none;
    }
    .div-action{
        display: inline-flex;
        margin: auto;
        color: #218FD8;
    }
    .div-action i{
        font-size: 14px;
        font-weight: normal;
        margin: auto;
    }
    .div-action label{
        font-size: 14px;
        font-weight: normal;
        padding-left: 5px;
        margin-bottom: 0px;
    }
    .div-action:hover i, .div-action:hover label{
        cursor: pointer;
        font-weight: bold;
    }
</style>
<div class="right_col" role="main">    
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel container_header">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Pipeline</li>
                            <li class="breadcrumb-item active" aria-current="page">Submitted</li>
                        </ol>
                    </nav>
                    <div class="x_title">
                        <div class="page_title">
                            <div class="pull-left">Submitted</div>
                            <!--<button id="btn_export_pipeline" class="btn w150 btn-sm btn-primary pull-right" type="button">Export File</button>-->
                        </div>
                        <div class="clearfix"></div>
                        <?php if($this->session->flashdata('Success')) { ?>
                        <div class="alert alert-success alert-dismissable fade in" role="alert" style="position: absolute; top: -65px; right: 0px; width: 25%;">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <strong>Success!</strong>
                            <?php echo $this->session->flashdata('Success'); ?>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title" style="padding:1px 0px;">
                        <ul class="nav navbar-right panel_toolbox" style="min-width:0px;">
                            <li><a class="collapse-link btn btn-sm w150 btn-default" style="margin-bottom:0px;"><label class="search-form">Hide Filter</label></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                    <form id="updatePipelineForm" method="POST" class="form-horizontal form-label-left">
                        <?php if($user['ROLE_ID'] != 12 && $user['ROLE_ID'] != 13 && $user['ROLE_ID'] != 14):?>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="uker_id">Unit Kerja</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select class="form-control js-example-basic-single" id="uker_id" name="uker_id" style="width:100%;">
                                    <?php
                                    if($user['ROLE_ID'] == 15 || $user['ROLE_ID'] == 16)
                                        echo '<option value="0" >Semua Unit Kerja</option>';
                                    foreach ($uker_option as $row){
                                        $selected = '';
                                        if($uker_id == $row->UnitKerjaId) $selected = 'selected="selected"';
                                        echo '<option value="'.$row->UnitKerjaId.'" '.$selected.'>'.$row->Name.'</option>';
                                    }
                                    ?>                                       
                                </select>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="rm_id">Nama RM</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select class="form-control js-example-basic-single" id="rm_id" name="rm_id" style="width:100%;">
                                    <option value="0">Semua RM</option>
                                    <?php
                                    foreach ($rm_option as $row){
                                        $selected = '';
                                        if($rm_id == $row->UserId) $selected = 'selected="selected"';
                                        echo '<option value="'.$row->UserId.'" '.$selected.'>'.$row->Name.'</option>';
                                    }
                                    ?>                                       
                                </select>
                            </div>
                        </div>
                        <?php if($user['ROLE_ID'] == 16): ?>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="uker_id">Sektor Usaha</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select class="form-control js-example-basic-single" id="sektorUsahaId" name="sektorUsahaId" style="width:100%;">
                                    <option value="0">Semua Sektor Usaha</option>
                                    <?php
                                        foreach ($sektor_usaha_option as $row){
                                            $selected = '';
                                            if($sektorUsahaId == $row->SegmentationId) $selected = 'selected="selected"';
                                            echo '<option value="'.$row->SegmentationId.'" '.$selected.'>'.$row->SegmentationName.'</option>';
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                         <?php endif; ?>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="keyword">Pencarian</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="keyword" name="keyword" class="form-control col-md-7 col-xs-12" value="<?= $keyword; ?>" placeholder="Ketik Keyword">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-sm-offset-3">
                                <button id="btn_filter_pipeline" class="btn w150 btn-sm btn-primary pull-left" style="margin-right:0px;" type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" style="background:none; border:none; padding: 0px;">
                    <div class="x_content">

                        <form id="approvalPipelineForm" action="<?= base_url().'pipeline/approval_pipeline'; ?>" method="POST">
                        <div class="row">
                            <div class="col-xs-12">
                                <table id="tbl_submitted_pipeline" class="table table-striped table-hover" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th style="width:5%; text-align:center;"><input name="select_all" value="1" type="checkbox"></th>
                                            <th style="width:5%;">No.</th>
                                            <th style="width:20%;">Nama Debitur</th>
                                            <th style="width:10%;">Nama RM</th>
                                            <th style="width:10%;">Status Permohonan</th>
                                            <th style="width:20%;">Alamat</th>
                                            <th style="width:10%;">Jenis Usaha</th>
                                            <th style="width:3%;">LPG</th>
                                            <th style="width:5%;">Sumber Debitur</th>
                                            <th style="width:9%;">Usulan Plafond</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $i = 1;
                                        foreach($pipeline as $row){
                                            switch($row->LPGStatus){
                                                case '1': $lpg = '<i id="lpg_red" class="fa fa-square" style="color:#E74545"></i>'; break;
                                                case '2': $lpg = '<i id="lpg_yellow" class="fa fa-square" style="color:#FFEF9D"></i>'; break;
                                                case '3': $lpg = '<i id="lpg_green" class="fa fa-square" style="color:#62D159"></i>'; break;
                                                case '4': $lpg = '<i id="lpg_blue" class="fa fa-square" style="color:#218FD8"></i>'; break;
                                                default: $ews = ''; break;
                                            }
                                            switch($row->CustomerResouceId){
                                                case '1': $tdb_status = 'TDB'; break;
                                                case '2': $tdb_status = 'Non TDB'; break;
                                                default: $tdb_status = ''; break;
                                            }
                                    ?>
                                            <tr>
                                                <td><?= $row->PipelineId; ?></td>
                                                <td><?= $i; ?></td>
                                                <td><a style="color:#218FD8; text-decoration:underline;" href="<?= base_url().'pipeline/detail/'.$row->PipelineId; ?>"><?= $row->CustomerName; ?></a></td>
                                                <td><?= $row->RM_NAME; ?></td>
                                                <td><?= $row->DataSourceName; ?></td>
                                                <td><?= $row->Address; ?></td>
                                                <td><?= $row->BusinessType; ?></td>
                                                <td><?= $lpg; ?></td>
                                                <td><?= $tdb_status; ?></td>
                                                <td><label style="font-weight:normal;" class="money" data-a-sep="," data-a-dec="."><?= $row->Plafond; ?></label></td>
                                            </tr>
                                    <?php
                                            $i++;
                                        }
                                    ?>
                                    </tbody>
                                </table>
                                
                            </div>
                        </div>
                        </form>
                    </div>
                    <div class="modal fade modal-approve-pipeline" tabindex="-1" role="dialog" aria-hidden="true">
						<div class="modal-dialog modal-lg">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
                                    <div class="row">
                                        <div class="col-xs-12 modal-divider-header"></div>
                                    </div>
								</div>
								<div class="modal-body">
									<p>Anda akan menyetujui pipeline yang dipilih. Lanjutkan?</p>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn w150 btn-default" data-dismiss="modal">Tidak</button>
									<button id="btn_confirm_approve_pipeline" type="button" class="btn w150 btn-primary modal-button-ok">Ya</button>
								</div>
							</div>
						</div>
					</div>
                    <div class="modal fade modal-reject-pipeline" tabindex="-1" role="dialog" aria-hidden="true">
						<div class="modal-dialog modal-lg">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myModalLabel">Reject Pipeline</h4>
                                    <div class="row">
                                        <div class="col-xs-12 modal-divider-header"></div>
                                    </div>
								</div>
								<div class="modal-body">
									<p>Anda akan menolak pipeline yang dipilih. Lanjutkan?</p>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn w150 btn-default" data-dismiss="modal">Tidak</button>
									<button id="btn_confirm_reject_pipeline" type="button" class="btn w150 btn-primary modal-button-ok">Ya</button>
								</div>
							</div>
						</div>
					</div>
                    <div class="modal fade modal-detail-pipeline" tabindex="-1" role="dialog" aria-hidden="true">
						<div class="modal-dialog modal-dialog-pipeline modal-lg">
							<div class="modal-content">
								<div class="modal-header-pipeline">
                                    <h4 class="modal-title-pipeline" id="myModalLabel"><i class="fa fa-file-text-o"></i> View Pipeline Detail</h4>
                                    <div class="row">
                                        <div class="col-xs-12 modal-divider-header-pipeline"></div>
                                    </div>
								</div>
								<div class="modal-body-pipeline">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="sumber_pipeline" class="control-label">Sumber Data</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="sumber_pipeline" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="cif" class="control-label">CIF</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="cif" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="nama_debitur" class="control-label">Nama Debitur</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="nama_debitur" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="npwp" class="control-label">NPWP Perusahaan</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="npwp" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="alamat" class="control-label">Alamat</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="alamat" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="contact_person" class="control-label">Contact Person</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="contact_person" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="no_telp" class="control-label">No. Telepon</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="no_telp" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="ews_status" class="control-label">EWS</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <i id="ews_red" class='fa fa-square no_display' style='color:red'></i>
                                                    <i id="ews_yellow" class='fa fa-square no_display' style='color:yellow'></i>
                                                    <i id="ews_green" class='fa fa-square no_display' style='color:green'></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="jenis_usaha" class="control-label">Jenis Usaha</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="jenis_usaha" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="sektor_usaha" class="control-label">Sektor Usaha</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="sektor_usaha" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="sektor_ekonomi" class="control-label">Sektor Ekonomi</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="sektor_ekonomi" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="warna_lpg" class="control-label">Warna LPG</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <i id="lpg_red" class='fa fa-square no_display' style='color:red'></i>
                                                    <i id="lpg_yellow" class='fa fa-square no_display' style='color:yellow'></i>
                                                    <i id="lpg_green" class='fa fa-square no_display' style='color:green'></i>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="status_debitur" class="control-label">Status Debitur</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="status_debitur" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="plafond" class="control-label">Plafon</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="plafond" class="control-label money detail_pipeline" data-a-dec="." data-a-sep=","></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="tdb" class="control-label">Sumber Debitur</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="tdb" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-4 col-xs-12">
                                                    <label for="sumber_tdb" class="control-label">Sumber TDB</label>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <label id="sumber_tdb" class="control-label detail_pipeline"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?= base_url(); ?>/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-checkbox/js/dataTables.checkboxes.min.js"></script>
<script src="<?= base_url();?>assets/auto-numeric/autoNumeric.js"></script>

<script>
    var base_url = "<?= base_url(); ?>";
    var hide = 0;
    function updateDataTableSelectAllCtrl(table){
        var $table             = table.table().node();
        var $chkbox_all        = $('tbody input[type="checkbox"]', $table);
        var $chkbox_checked    = $('tbody input[type="checkbox"]:checked', $table);
        var chkbox_select_all  = $('thead input[name="select_all"]', $table).get(0);

        if($chkbox_checked.length === 0){
            chkbox_select_all.checked = false;
            if('indeterminate' in chkbox_select_all){
                chkbox_select_all.indeterminate = false;
            }
        } else if ($chkbox_checked.length === $chkbox_all.length){
            chkbox_select_all.checked = true;
            if('indeterminate' in chkbox_select_all){
                chkbox_select_all.indeterminate = false;
            }
        } else {
            chkbox_select_all.checked = true;
            if('indeterminate' in chkbox_select_all){
                chkbox_select_all.indeterminate = true;
            }
        }
    }

    function updateDetailPipeline(pipeline_id, created_by_id){
        jQuery(".loaderImage").show();
        $.getJSON(base_url+'pipeline/serviceGetDetailPipeline/'+pipeline_id+'/'+created_by_id, function (data){
            //console.log(data);
            switch(data.SUMBER_DATA){
                case 1: var sumber_data = 'Data Baru'; break;
                case 2: var sumber_data = 'CIF'; break;
            }
            switch(data.SUMBER_DATA){
                case 1: var sumber_debitur = 'TDB'; break;
                case 2: var sumber_debitur = 'Non TDB'; break;
            }
            switch(data.STATUS_DEBITUR){
                case 1: var status_debitur = 'Baru'; break;
                case 2: var status_debitur = 'Suplesi'; break;
            }
            switch(data.SEKTOR_USAHA){
                case 1: var sektor_usaha = 'Pertanian'; break;
                case 2: var sektor_usaha = 'Non Pertanian'; break;
            }
            switch(data.WARNA_LPG){
                case 1 : 
                    $(".modal-detail-pipeline #lpg_red").show();
                    $(".modal-detail-pipeline #lpg_yellow").hide();
                    $(".modal-detail-pipeline #lpg_green").hide();
                    break;
                case 2 :
                    $(".modal-detail-pipeline #lpg_red").hide();
                    $(".modal-detail-pipeline #lpg_yellow").show();
                    $(".modal-detail-pipeline #lpg_green").hide();
                    break;
                case 3 :
                    $(".modal-detail-pipeline #lpg_red").hide();
                    $(".modal-detail-pipeline #lpg_yellow").hide();
                    $(".modal-detail-pipeline #lpg_green").show();
                    break;
                default :
                    $(".modal-detail-pipeline #lpg_red").hide();
                    $(".modal-detail-pipeline #lpg_yellow").hide();
                    $(".modal-detail-pipeline #lpg_green").hide()
                     break;
            }
            switch(data.EWS_STATUS){
                case 1 : 
                    $(".modal-detail-pipeline #ews_red").show();
                    $(".modal-detail-pipeline #ews_yellow").hide();
                    $(".modal-detail-pipeline #ews_green").hide();
                    break;
                case 2 :
                    $(".modal-detail-pipeline #ews_red").hide();
                    $(".modal-detail-pipeline #ews_yellow").show();
                    $(".modal-detail-pipeline #ews_green").hide();
                    break;
                case 3 :
                    $(".modal-detail-pipeline #ews_red").hide();
                    $(".modal-detail-pipeline #ews_yellow").hide();
                    $(".modal-detail-pipeline #ews_green").show(); 
                    break;
                default :
                    $(".modal-detail-pipeline #ews_red").hide();
                    $(".modal-detail-pipeline #ews_yellow").hide();
                    $(".modal-detail-pipeline #ews_green").hide();
                    break;
            }
            $('.modal-detail-pipeline #sumber_pipeline').html(sumber_data);
            $('.modal-detail-pipeline #cif').html(data.CIFNO);
            $('.modal-detail-pipeline #nama_debitur').html(data.NAMA_DEBITUR);
            $('.modal-detail-pipeline #npwp').html(data.NPWP);
            $('.modal-detail-pipeline #alamat').html(data.ALAMAT);
            $('.modal-detail-pipeline #contact_person').html(data.CONTACT_PERSON);
            $('.modal-detail-pipeline #no_telp').html(data.NO_TELP);
            $('.modal-detail-pipeline #jenis_usaha').html(data.JENIS_USAHA);
            $('.modal-detail-pipeline #sektor_usaha').html(sektor_usaha);
            $('.modal-detail-pipeline #sektor_ekonomi').html(data.NAMA_SEKTOR);
            $('.modal-detail-pipeline #status_debitur').html(status_debitur);
            $('.modal-detail-pipeline #plafond').autoNumeric('init');
            $('.modal-detail-pipeline #plafond').autoNumeric('set', (data.PLAFOND));
            $('.modal-detail-pipeline #tdb').html(sumber_debitur);
            $('.modal-detail-pipeline #sumber_tdb').html(data.NAMA_GROUP);

            jQuery(".loaderImage").hide();
            $('.modal-detail-pipeline').modal('show');
        })
       
    }

    function updateRMOption(uker_id){
        jQuery(".loaderImage").show();  
        var dropdownRM = $('#rm_id');
        dropdownRM.empty();
        dropdownRM.append($('<option>',
        {
            value: 0,
            text: 'Semua RM'
        },'</option>'));
        $.getJSON(base_url+'pipeline/serviceGetRM/'+uker_id, function (data){
            if(data.length > 0){
                $.each(data, function(index, item){
                    dropdownRM.append($('<option>',
                    {
                        value: item.UserId,
                        text: item.Name
                    },'</option>'));
                })
            }
            jQuery(".loaderImage").hide();
        })    
    }

    $(document).ready(function() {
        $('.money').autoNumeric('init');

        var jumlah_no_reject_pipeline = <?php echo count($pipeline2); ?>;
        $('.js-example-basic-single').select2();

        $(document).on('click','.detail_pipeline', function(){
            var pipeline_id = $(this).data('pipeline_id');
            var created_by_id = $(this).data('created_by_id');
            updateDetailPipeline(pipeline_id, created_by_id);
            
        });

        var rows_selected = [];
        var table = $('#tbl_submitted_pipeline').DataTable({
            'bLengthChange': false,
            //'dom': 'flrt<"bottom"pi><"approve_div">',
            'dom': 'rt<"bottom"pi><"approve_div">',
            'pageLength': 10,
            'columnDefs': [{
                'targets': 0,
                'searchable': false,
                'orderable': false,
                'width': '1%',
                'className': 'dt-body-center',
                'render': function (data, type, full, meta){
                    return '<input type="checkbox">';
                }
            }],
            'pageLength': 10,
            'ordering': false,
            'order': [[1, 'asc']],
            'rowCallback': function(row, data, dataIndex){
                var rowId = data[0];
                
                if($.inArray(rowId, rows_selected) !== -1){
                    $(row).find('input[type="checkbox"]').prop('checked', true);
                    $(row).addClass('selected');
                }
            }
        });

        $('div.dataTables_filter input').removeClass('input-sm');
        $('div.dataTables_filter input').css('border-radius','25px');

        $("div.approve_div").html('<button id="btn_approve_pipeline" class="btn w150 btn-sm btn-success pull-right" style="margin-right:0px;" type="button" data-toggle="modal" data-target=".modal-approve-pipeline" disabled>Setuju</button>');
        
        $('#tbl_submitted_pipeline tbody').on('click', 'input[type="checkbox"]', function(e){
            var $row = $(this).closest('tr');
            var data = table.row($row).data();
            var rowId = data[0];
            var index = $.inArray(rowId, rows_selected);

            if(this.checked && index === -1){
                rows_selected.push(rowId);

            } else if (!this.checked && index !== -1){
                rows_selected.splice(index, 1);
            }

            if(this.checked){
                $row.addClass('selected');
            } else {
                $row.removeClass('selected');
            }

            updateDataTableSelectAllCtrl(table);
            e.stopPropagation();

            if(rows_selected.length == 0){
                $('#btn_reject_pipeline').prop("disabled", true); 
            }else{
                $('#btn_reject_pipeline').prop("disabled", false); 
            }

            if(rows_selected.length != 0){
                $('#btn_approve_pipeline').prop("disabled", false); 
            }else{
                $('#btn_approve_pipeline').prop("disabled", true);
            }
        });

        $('thead input[name="select_all"]', table.table().container()).on('click', function(e){
            if(this.checked){
                $('#tbl_submitted_pipeline tbody input[type="checkbox"]:not(:checked)').trigger('click');
            } else {
                $('#tbl_submitted_pipeline tbody input[type="checkbox"]:checked').trigger('click');
            }
            e.stopPropagation();
        });

        table.on('draw', function(){
            updateDataTableSelectAllCtrl(table);
        });

        $('#btn_confirm_approve_pipeline').click(function(){
            var form = $("#approvalPipelineForm");
            $.each(rows_selected, function(index, rowId){
                $(form).append(
                    $('<input>')
                        .attr('type', 'hidden')
                        .attr('name', 'id[]')
                        .val(rowId)
                );
            });
            
            $(form).append('<input type="hidden" name="status" value="4" /> ');

            setTimeout(function(){ 
                $('#approvalPipelineForm').submit();
            }, 500);
        });

        $('#btn_confirm_reject_pipeline').click(function(){
            var form = $("#approvalPipelineForm");
            $.each(rows_selected, function(index, rowId){
                $(form).append(
                    $('<input>')
                        .attr('type', 'hidden')
                        .attr('name', 'id[]')
                        .val(rowId)
                );
            });
            
            $(form).append('<input type="hidden" name="status" value="5" /> ');

            setTimeout(function(){ 
                $('#approvalPipelineForm').submit();
            }, 500);
        });

        $('#uker_id').change(function(){
            var uker_id =  this.value;
            updateRMOption(uker_id);
        });
        
        $('.collapse-link').click(function(){
            if(hide == 0){
                $('.search-form').html('Show Filter');
                hide = 1;
            }else{
                $('.search-form').html('Hide Filter');
                hide = 0;
            }
        });
    });   
</script>