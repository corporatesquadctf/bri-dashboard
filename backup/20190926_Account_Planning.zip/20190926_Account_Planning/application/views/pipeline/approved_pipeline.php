<style type="text/css">
    .dataTables_paginate {
        float: left !important;
    }
    .dataTables_info {
        width: 40%;
        float: left;
        margin-left: 25px;
    }
    .dataTables_filter {
        width: auto;
        float: right;
        text-align: right;
    }
    .panel_toolbox>li>a {
        padding: 5px 10px;
        color: #000;
        font-size:12px;
    }
    .update_link{
        vertical-align:middle; 
        text-decoration: none; 
        color:#337ab7;
    }    
    .pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover {
        z-index: 3;
        color: #fff;
        cursor: default;
        background-color: #218FD8;
        border-color: #337ab7;
    }
    .search-form{
        margin-bottom: 0px;
        font-weight: normal;
    }
    table { 
        border-collapse: separate; 
        border-spacing: 0 10px; 
        margin-top: -10px;
    }
    tr{
        box-shadow: 0px 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
    }
    tr th{
        border: none !important;
    }
    td {
        border: 1px solid #ddd;
        border-style: solid none;
        padding: 10px;
        background: #FFF;        
    }
    td>a:hover{
        font-weight:bold;
    }
    td:first-child{
        border-left-style: solid;
        border-top-left-radius: 4px; 
        border-bottom-left-radius: 4px;
    }
    td:last-child{
        border-right-style: solid;
        border-bottom-right-radius: 4px; 
        border-top-right-radius: 4px; 
    }
    thead{
        color:#218FD8;
    }
    thead tr{
        background-color:#F7F7F7;
        box-shadow: none;
    }
    .div-action{
        display: inline-flex;
        margin: auto;
        color: #218FD8;
    }
    .div-action i{
        font-size: 14px;
        font-weight: normal;
        margin: auto;
    }
    .div-action label{
        font-size: 14px;
        font-weight: normal;
        padding-left: 5px;
        margin-bottom: 0px;
    }
    .div-action:hover i, .div-action:hover label{
        cursor: pointer;
        font-weight: bold;
    }
    .div-disabled-action{
        display: inline-flex;
        margin: auto;
        color: #000000;
        opacity: 0.38;
    }
    .div-disabled-action i{
        font-size: 14px;
        font-weight: normal;
        margin: auto;
    }
    .div-disabled-action label{
        font-size: 14px;
        font-weight: normal;
        padding-left: 5px;
        margin-bottom: 0px;
    }
</style>
<div class="right_col" role="main">    
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel container_header">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Pipeline</li>
                            <li class="breadcrumb-item active" aria-current="page">Approved</li>
                        </ol>
                    </nav>
                    <div class="x_title">
                        <div class="page_title">
                            <div class="pull-left">Approved</div>
                        </div>
                        <div class="clearfix"></div>
                        <?php if($this->session->flashdata('Success')) { ?>
                        <div class="alert alert-success alert-dismissable fade in" role="alert" style="position: absolute; top: -65px; right: 0px; width: 25%;">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <strong>Success!</strong>
                            <?php echo $this->session->flashdata('Success'); ?>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title" style="padding:1px 0px;">
                        <ul class="nav navbar-right panel_toolbox" style="min-width:0px;">
                            <li><a class="collapse-link btn btn-sm w150 btn-default" style="margin-bottom:0px;"><label class="search-form">Hide Filter</label></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                    <form id="updatePipelineForm" method="POST" class="form-horizontal form-label-left">
                        <div class="form-group">
                        <?php if($user['ROLE_ID'] != 12 && $user['ROLE_ID'] != 13 && $user['ROLE_ID'] != 14):?>
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="uker_id">Unit Kerja</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select class="form-control js-example-basic-single" id="uker_id" name="uker_id" style="width:100%;">
                                    <?php
                                    if($user['ROLE_ID'] == 15 || $user['ROLE_ID'] == 16)
                                        echo '<option value="0" >Semua Unit Kerja</option>';
                                    foreach ($uker_option as $row){
                                        $selected = '';
                                        if($uker_id == $row->UnitKerjaId) $selected = 'selected="selected"';
                                        echo '<option value="'.$row->UnitKerjaId.'" '.$selected.'>'.$row->Name.'</option>';
                                    }
                                    ?>                                       
                                </select>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if($user['ROLE_ID'] != 12){ ?>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="rm_id">Nama RM</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select class="form-control js-example-basic-single" id="rm_id" name="rm_id" style="width:100%;">
                                    <option value="0">Semua RM</option>
                                    <?php
                                    foreach ($rm_option as $row){
                                        $selected = '';
                                        if($rm_id == $row->UserId) $selected = 'selected="selected"';
                                        echo '<option value="'.$row->UserId.'" '.$selected.'>'.$row->Name.'</option>';
                                    }
                                    ?>                                       
                                </select>
                            </div>
                        </div>
                        <?php } ?>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="keyword">Pencarian</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="keyword" name="keyword" class="form-control col-md-7 col-xs-12" value="<?= $keyword; ?>" placeholder="Ketik Keyword">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-sm-offset-3">
                                <button id="btn_filter_pipeline" class="btn w150 btn-sm btn-primary pull-left" style="margin-right:0px;" type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" style="background:none; border:none; padding: 0px;">
                    <div class="x_content">
                    <form id="approvalPipelineForm" action="<?= base_url().'pipeline/multiple_comment_pipeline'; ?>" method="POST">
                        <div class="row">
                            <div class="col-xs-12">
                                <table id="tbl_approved_pipeline" class="table" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th style="width:5%; text-align:center;"><input name="select_all" value="1" type="checkbox"></th>
                                            <th style="width:3%;">No.</th>
                                            <th style="width:15%;">Nama Debitur</th>
                                            <th style="width:10%;">Nama RM</th>
                                            <th style="width:10%;">Status Permohonan</th>
                                            <th style="width:12%;">Alamat</th>
                                            <th style="width:10%;">Jenis Usaha</th>
                                            <th style="width:3%;">LPG</th>
                                            <th style="width:5%;">Sumber Debitur</th>
                                            <th style="width:9%;">Usulan Plafond</th>
                                            <th style="width:5%;">Status</th>
                                            <?php if($user['ROLE_ID'] == 12){ ?>
                                                <th style="width:10%;">Action</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $i = 1;
                                        foreach($pipeline as $row){
                                            switch($row->LPGStatus){
                                                case '1': $lpg = '<i id="lpg_red" class="fa fa-square" style="color:#E74545"></i>'; break;
                                                case '2': $lpg = '<i id="lpg_yellow" class="fa fa-square" style="color:#FFEF9D"></i>'; break;
                                                case '3': $lpg = '<i id="lpg_green" class="fa fa-square" style="color:#62D159"></i>'; break;
                                                case '4': $lpg = '<i id="lpg_blue" class="fa fa-square" style="color:#218FD8"></i>'; break;
                                                default: $ews = ''; break;
                                            }
                                            
                                            switch($row->StatusId){                                                
                                                case '6': 
                                                    $status = $row->STATUS_NAME;
                                                    $isProcess = "class='div-disabled-action'"; 
                                                    $isCancel = "class='div-action btn_batal_approved_pipeline'"; 
                                                    $isMaintain = "class='div-action btn_maintain_approved_pipeline'";
                                                    $label_status = "style='font-weight: bold; color:#198c19;'";
                                                    break;
                                                case '7': $status = $row->STATUS_NAME; 
                                                    $isProcess = "class='div-disabled-action'"; 
                                                    $isCancel = "class='div-disabled-action'"; 
                                                    $isMaintain = "class='div-disabled-action'";
                                                    $label_status = "style='font-weight: bold; color:#cc0000;'";
                                                    break;
                                                case '8': 
                                                    $status = $row->STATUS_NAME; 
                                                    $isProcess = "class='div-action btn_proses_approved_pipeline'"; 
                                                    $isCancel = "class='div-action btn_batal_approved_pipeline'"; 
                                                    $isMaintain = "class='div-disabled-action'";
                                                    $label_status = "style='font-weight: bold; color:#eaea32;'";
                                                    break;
                                                default : 
                                                    $status = "";
                                                    $isProcess = "class='div-action btn_proses_approved_pipeline'"; 
                                                    $isCancel = "class='div-action btn_batal_approved_pipeline'"; 
                                                    $isMaintain = "class='div-action btn_maintain_approved_pipeline'";
                                                    $label_status = ''; 
                                                    break;
                                            }

                                            switch($row->CustomerResouceId){
                                                case '1': $tdb_status = 'TDB'; break;
                                                case '2': $tdb_status = 'Non TDB'; break;
                                                default: $tdb_status = ''; break;
                                            }
                                    ?>
                                            <tr>
                                                <td><?= $row->PipelineId; ?></td>
                                                <td><?= $i; ?></td>
                                                <td><a style="color:#218FD8; text-decoration:underline;" href="<?= base_url().'pipeline/approved_detail/'.$row->PipelineId; ?>"><?= $row->CustomerName; ?></a></td>
                                                <td><?= $row->RM_NAME; ?></td>
                                                <td><?= $row->DataSourceName; ?></td>
                                                <td><?= $row->Address; ?></td>
                                                <td><?= $row->BusinessType; ?></td>
                                                <td><?= $lpg; ?></td>
                                                <td><?= $tdb_status; ?></td>
                                                <td><label style="font-weight:normal;" class="money" data-a-sep="," data-a-dec="."><?= $row->Plafond; ?></label></td>
                                                <td><label <?= $label_status; ?>><?= $status; ?></label></td>
                                                <?php if($user['ROLE_ID'] == 12){ ?>
                                                <td>
                                                    <div <?php echo $isProcess; ?> data-id="<?= $row->PipelineId; ?>" data-realisasi="<?= $row->BulanRealisasi; ?>">
                                                        <i class="material-icons">send</i>
                                                        <label>Proses</label>
                                                    </div><br/>
                                                    <!--
                                                    <div <?php echo $isMaintain; ?> data-id="<?= $row->PipelineId; ?>">
                                                        <i class="material-icons">pause_circle_filled</i>
                                                        <label>Tunda</label>
                                                    </div><br/>
                                                    -->
                                                    <div <?php echo $isCancel; ?> data-id="<?= $row->PipelineId; ?>">
                                                        <i class="material-icons">cancel</i>
                                                        <label>Batal</label>
                                                    </div>
                                                </td>
                                                <?php } ?>                                                
                                            </tr>
                                        <?php
                                            $i++;
                                        }
                                    ?>
                                    </tbody>
                                </table>                                
                            </div>
                        </div>
                    </form>
                    </div>
                        <div class="modal fade modal-comment-pipeline" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Komentar</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row form-group">
                                            <div class="col-xs-12">
                                                <p>Tuliskan pesan yang ingin anda berikan:</p>
                                                <textarea id="comment" name="comment" class="form-control" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn w150 btn-default" data-dismiss="modal">Batal</button>
                                        <button id="btn_confirm_comment_pipeline" type="button" class="btn w150 btn-primary modal-button-ok">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal fade modal-proses-pipeline" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?= base_url().'pipeline/proses_pipeline'; ?>" id="form_proses_pipeline" method="post">
                                            <input type="hidden" id="pipeline_id" name="pipeline_id" />
                                            <p style="font-weight: bold; color: #000;">Bulan Realisasi:</p>
                                            <select id="realisasi" name="realisasi" class="js-example-basic-single form-control" style="width:30%;">
                                            <p>
                                                
                                            </p>
                                            </select>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button id="btn_confirm_proses_pipeline" type="button" class="btn w150 btn-primary modal-button-ok">Mulai</button>
                                        <button id="btn_confirm_simpan_pipeline" type="button" class="btn w150 btn-primary modal-button-ok">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal fade modal-batal-pipeline" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Komentar</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?= base_url().'pipeline/batal_pipeline'; ?>" id="form_batal_pipeline" method="post">
                                        <div class="row form-group">
                                            <div class="col-xs-12">
                                                <input type="hidden" id="pipeline_id" name="pipeline_id" />
                                                <p>Anda akan membatalkan pipeline. Berikan alasan anda:</p>
                                                <textarea id="comment" name="comment" class="form-control" rows="5"></textarea>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn w150 btn-default" data-dismiss="modal">Batal</button>
                                        <button id="btn_confirm_batal_pipeline" type="button" class="btn w150 btn-primary modal-button-ok">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal fade modal-maintain-pipeline" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Komentar</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?= base_url().'pipeline/maintain_pipeline'; ?>" id="form_maintain_pipeline" method="post">
                                        <div class="row form-group">
                                            <div class="col-xs-12">
                                                <input type="hidden" id="pipeline_id" name="pipeline_id" />
                                                <p>Anda akan menunda proses prakarsa pipeline. Berikan alasan:</p>
                                                <textarea id="comment" name="comment" class="form-control" rows="5"></textarea>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn w150 btn-default" data-dismiss="modal">Batal</button>
                                        <button id="btn_confirm_maintain_pipeline" type="button" class="btn w150 btn-primary modal-button-ok">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?= base_url(); ?>/template/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
<script src="<?= base_url(); ?>/template/vendors/datatables.net-checkbox/js/dataTables.checkboxes.min.js"></script>
<script src="<?= base_url();?>assets/auto-numeric/autoNumeric.js"></script>

<script>
    var base_url = "<?= base_url(); ?>";
    var hide = 0;
    function updateDataTableSelectAllCtrl(table){
        var $table             = table.table().node();
        var $chkbox_all        = $('tbody input[type="checkbox"]', $table);
        var $chkbox_checked    = $('tbody input[type="checkbox"]:checked', $table);
        var chkbox_select_all  = $('thead input[name="select_all"]', $table).get(0);

        if($chkbox_checked.length === 0){
            chkbox_select_all.checked = false;
            if('indeterminate' in chkbox_select_all){
                chkbox_select_all.indeterminate = false;
            }
        } else if ($chkbox_checked.length === $chkbox_all.length){
            chkbox_select_all.checked = true;
            if('indeterminate' in chkbox_select_all){
                chkbox_select_all.indeterminate = false;
            }
        } else {
            chkbox_select_all.checked = true;
            if('indeterminate' in chkbox_select_all){
                chkbox_select_all.indeterminate = true;
            }
        }
    }

    function updateRMOption(uker_id){
        jQuery(".loaderImage").show();
        var dropdownRM = $('#rm_id');
        dropdownRM.empty();
        dropdownRM.append($('<option>',
        {
            value: 0,
            text: 'Semua RM'
        },'</option>'));
        $.getJSON(base_url+'pipeline/serviceGetRM/'+uker_id, function (data){
            if(data.length > 0){
                $.each(data, function(index, item){
                    dropdownRM.append($('<option>',
                    {
                        value: item.id,
                        text: item.name
                    },'</option>'));
                })
            }
            jQuery(".loaderImage").hide();
        })    
    }

    $(document).ready(function() {
        $('.money').autoNumeric('init');
        $('.js-example-basic-single').select2();
        var user_role = <?php echo $user['ROLE_ID']; ?>;
        if(user_role == 12){
            var visible = false;
            var display = "no_display"
        }else {
            var visible = true;
            var display = "";
        }

        var rows_selected = [];
        var table = $('#tbl_approved_pipeline').DataTable({
            'bLengthChange': false,
            'dom': 'rt<"bottom"pi><"comment_div">',
            'pageLength': 10,
            'columnDefs': [{
                'targets': 0,
                'searchable': false,
                'orderable': false,
                'width': '1%',
                'className': 'dt-body-center',
                'visible' : visible,
                'render': function (data, type, full, meta){
                    return '<input type="checkbox">';
                }
            }],
            'pageLength': 10,
            'ordering': false,
            'order': [[1, 'asc']],
            'rowCallback': function(row, data, dataIndex){
                var rowId = data[0];
                
                if($.inArray(rowId, rows_selected) !== -1){
                    $(row).find('input[type="checkbox"]').prop('checked', true);
                    $(row).addClass('selected');
                }
            }
        });

        $("div.comment_div").html('<button id="btn_comment_pipeline" class="btn w150 btn-sm btn-primary pull-right '+display+'" style="margin-right:0px;" type="button" data-toggle="modal" data-target=".modal-comment-pipeline" disabled>Komentar</button>');

        $('#tbl_approved_pipeline tbody').on('click', 'input[type="checkbox"]', function(e){
            var $row = $(this).closest('tr');
            var data = table.row($row).data();
            var rowId = data[0];
            var index = $.inArray(rowId, rows_selected);

            if(this.checked && index === -1){
                rows_selected.push(rowId);

            } else if (!this.checked && index !== -1){
                rows_selected.splice(index, 1);
            }

            if(this.checked){
                $row.addClass('selected');
            } else {
                $row.removeClass('selected');
            }

            updateDataTableSelectAllCtrl(table);
            e.stopPropagation();

            if(rows_selected.length != 0){
                $('#btn_comment_pipeline').prop("disabled", false); 
            }else{
                $('#btn_comment_pipeline').prop("disabled", true);
            }

        });

        $('thead input[name="select_all"]', table.table().container()).on('click', function(e){
            if(this.checked){
                $('#tbl_approved_pipeline tbody input[type="checkbox"]:not(:checked)').trigger('click');
            } else {
                $('#tbl_approved_pipeline tbody input[type="checkbox"]:checked').trigger('click');
            }
            e.stopPropagation();
        });

        table.on('draw', function(){
            updateDataTableSelectAllCtrl(table);
        });

        $('#uker_id').change(function(){
            var uker_id =  this.value;
            updateRMOption(uker_id);
        });

        $('#btn_confirm_comment_pipeline').click(function(){
            var form = $("#approvalPipelineForm");
            var comment = $(".modal-comment-pipeline #comment").val();
            $.each(rows_selected, function(index, rowId){
                $(form).append(
                    $('<input>')
                        .attr('type', 'hidden')
                        .attr('name', 'id[]')
                        .val(rowId)
                );
            });
            
            $(form).append('<input type="hidden" name="comment" value="'+comment+'" /> ');

            setTimeout(function(){ 
                $('#approvalPipelineForm').submit();
            }, 500);
        });
        
        $('.btn_proses_approved_pipeline').click(function(){
            var pipelineId = $(this).data('id');
            var bulanRealisasiId = $(this).data("realisasi");
            var option = "";
            $('#realisasi').empty();
            <?php 
                $currentMonth = date('n');
                foreach($month as $row):
                    if($row['value'] < $currentMonth) continue;
            ?>
                    var selected = "";
                    if(<?= $row["value"];?> == bulanRealisasiId) selected = "selected";
                    option += "<option value='<?= $row['value']; ?>' "+selected+"><?= $row['name']; ?></option>";
            <?php
                endforeach;
            ?>
            $('#realisasi').append(option);
            
            $('.modal-proses-pipeline #pipeline_id').val(pipelineId);
            $('.modal-proses-pipeline').modal('show');
        });

        $('#btn_confirm_proses_pipeline').click(function(){
            $('#modal-proses-pipeline').modal('hide');
            $('#form_proses_pipeline').append('<input type="hidden" name="isProcess" value="1" /> ');
            setTimeout(function(){ 
                $('#form_proses_pipeline').submit();
            }, 500);		
        });

        $('#btn_confirm_simpan_pipeline').click(function(){
            $('#modal-proses-pipeline').modal('hide');
            $('#form_proses_pipeline').append('<input type="hidden" name="isProcess" value="0" /> ');
            setTimeout(function(){ 
                $('#form_proses_pipeline').submit();
            }, 500);		
        });
        
        $('.btn_batal_approved_pipeline').click(function(){
            var pipelineId = $(this).data('id');
            
            $('.modal-batal-pipeline #pipeline_id').val(pipelineId);
            $('.modal-batal-pipeline').modal('show');
        });

        $('#btn_confirm_batal_pipeline').click(function(){
            $('#modal-batal-pipeline').modal('hide');
            setTimeout(function(){ 
                $('#form_batal_pipeline').submit();
            }, 500);		
        });

        $('.btn_maintain_approved_pipeline').click(function(){
            var pipelineId = $(this).data('id');
            
            $('.modal-maintain-pipeline #pipeline_id').val(pipelineId);
            $('.modal-maintain-pipeline').modal('show');
        });

        $('#btn_confirm_maintain_pipeline').click(function(){
            $('#modal-maintain-pipeline').modal('hide');
            setTimeout(function(){ 
                $('#form_maintain_pipeline').submit();
            }, 500);		
        });
        
        $('.collapse-link').click(function(){
            if(hide == 0){
                $('.search-form').html('Show Filter');
                hide = 1;
            }else{
                $('.search-form').html('Hide Filter');
                hide = 0;
            }
        });
        
    });   
</script>