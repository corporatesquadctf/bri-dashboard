<style type="text/css">
    .content-container{
        padding: 0; 
        background: #FBFBFB; 
        margin-top: 0px;
    }
    .no-margin{
        margin: 0;
    }
    .customer-header{
        margin-top: 10px;
        padding: 10px 25px;
        background: #FFF;
        box-shadow: 0px 1px 1px rgba(181, 181, 181, 0.17);
    }
    .show-more {
        margin: 0;
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
        background: #218FD8;
        box-shadow: 0px 4px 5px rgba(14, 65, 142, 0.05), 0px 2px 2px rgba(81, 118, 213, 0.05);
        cursor: pointer;
    }
    .show-more a {
        display: block;
        padding: 5px;
        color: #FFF;
        text-align: center;
    }
    .show-more label {
        cursor: pointer;
        font-size: 12px;
        font-weight: normal;
        margin-bottom:0;
    }
    table {
        width: 100%;
    }
    thead {
        background: #FFFFFF;
        box-shadow: 0px 4px 4px #EDEDED;
        border-radius: 5px 5px 0px 0px;        
    }
    th {
        height: 56px;
        color: #4BB8FF;
        font-size: 12px;
        padding: 8px;
    }
    tbody tr {
        box-shadow: 0 4px 4px #EDEDED;
    }
    td {
        background: #FFFFFF;
        min-height: 56px;
        color: #8F8F8F;
        font-size: 12px;
        padding: 8px;

        vertical-align: top;
        border-top: 1px solid #ddd;
    }
    .panel_toolbox>li>a {
        padding: 5px 10px;
        color: #000;
        font-size:12px;
    }
    .search-form{
        margin-bottom: 0px;
        font-weight: normal;
    }
</style>
<div class="right_col" role="main">    
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel container_header">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Portofolio</li>
                            <li class="breadcrumb-item active">Portofolio RM</li>
                        </ol>
                    </nav>
                    <div class="x_title">
                        <div class="page_title">
                            <div class="pull-left">Portofolio RM</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="x_panel">
                    <div class="x_title" style="padding:1px 0px;">
                        <ul class="nav navbar-right panel_toolbox" style="min-width:0px;">
                            <li>
                                <a class="collapse-link btn w150 btn-sm btn-default" style="margin-bottom:0px;"><label class="search-form">Hide Filter</label></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                    <form id="filterPortofolioRmForm" method="POST" class="form-horizontal form-label-left">
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="keyword">Pencarian</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="keyword" name="keyword" class="form-control col-md-7 col-xs-12" placeholder="Ketik Keyword" value="<?= $keyword; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-sm-offset-3">
                                <button id="btn_filter_pipeline" class="btn w150 btn-sm btn-primary pull-left" style="margin-right:0px;" type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-xs-12">
                <div class="x_panel no-padding" style="border: none;">
                    <div class="x_content content-container">
                        <?php
                            if(!empty($PortofolioRm)):
                                $iPortofolioRm = 0;
                                foreach($PortofolioRm as $row):
                                    switch($row->Lpg){
                                        case 'Merah': $lpg = '<i id="lpg_red" class="fa fa-square" style="color:#E74545"></i>'; break;
                                        case 'Kuning': $lpg = '<i id="lpg_yellow" class="fa fa-square" style="color:#FFEF9D"></i>'; break;
                                        case 'Hijau': $lpg = '<i id="lpg_green" class="fa fa-square" style="color:#62D159"></i>'; break;
                                        case 'Biru': $lpg = '<i id="lpg_blue" class="fa fa-square" style="color:#218FD8"></i>'; break;
                                        default: $ews = ''; break;
                                    }
                        ?>
                        <div class="row no-margin">
                            <div class="col-xs-12 customer-header">
                                <div class="row">
                                    <div class="col-xs-1">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">CIF</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $row->Cif; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Nama Debitur</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $row->CustomerName; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Jenis Usaha</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $row->JenisUsaha; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">Alamat</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $row->Address; ?></label>
                                        </div>
                                    </div>
                                    <div class="col-xs-2">
                                        <div class="form-group col-xs-12"><label style="color: #218FD8;">LPG</label></div>
                                        <div class="form-group col-xs-12">
                                            <label style="font-weight: normal;"><?= $lpg; ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="collapsePortofolio_<?= $iPortofolioRm; ?>" style="margin: 10px 0; display: none;">
                            <input type="hidden" id="collapsePortofolioStatus_<?= $iPortofolioRm; ?>" value="0">
                            <div class="col-xs-12" style="padding: 0 20px;">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>No. Rekening</th>
                                            <th>Fasilitas</th>
                                            <th style="text-align:right;">Plafond</th>
                                            <th style="text-align:center;">EWS</th>
                                            <th style="text-align:center;">Kolektibilitas</th>
                                            <th>Produk Pinjaman</th>
                                            <th style="text-align:center;">Restruct</th>
                                            <th style="text-align:center;">Tanggal Jatuh Tempo</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            if(!empty($row->Rekening)):
                                                $iRekening = 1;
                                                foreach($row->Rekening as $rowRekening):
                                                    switch($rowRekening->Ews){
                                                        case 'Merah': $colorCode = 'E74545'; break;
                                                        case 'Kuning': $colorCode = 'FFEF9D'; break;
                                                        case 'Hijau' : $colorCode = '62D159'; break;
                                                        default: $colorCode = ''; break;
                                                    }
                                                    switch($rowRekening->FlagRestruct){
                                                        case 0: $restruct = 'No'; break;
                                                        case 1: $restruct = 'Yes'; break;
                                                        default: $restruct = ''; break;
                                                    }
                                        ?>
                                        <tr>
                                            <td><?= $iRekening; ?></td>
                                            <td><?= $rowRekening->RekNo; ?></td>
                                            <td><?= $rowRekening->Fasilitas; ?></td>
                                            <td style="text-align: right;"><label style="font-weight:normal;" class="money" data-a-sep="," data-a-dec="."><?= $rowRekening->Plafond; ?></label></td>
                                            <td style="text-align:center;"><i class="fa fa-square" style="color:#<?= $colorCode; ?>;"></i></td>
                                            <td style="text-align:center;"><?= $rowRekening->Kolektibilitas; ?></td>
                                            <td><?= $rowRekening->ProdukPinjaman; ?></td>
                                            <td style="text-align:center;"><?= $restruct; ?></td>
                                            <td style="text-align:center;"><?= date("d F Y", strtotime($rowRekening->JatuhTempo)); ?></td>
                                            <td></td>
                                        </tr>
                                        <?php
                                                $iRekening++;
                                                endforeach;
                                            endif;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-xs-12" style="padding: 0 20px; margin-top: 10px;">
                                <div style="width:100%; background: #FFF;">
                                    <div style="width: 75%; padding: 20px; display: flex;">
                                        <div style="width: 100%;">
                                            <canvas id="canvas_<?= $iPortofolioRm; ?>"></canvas>
                                        </div>
                                        <div style="width: 25%; padding: 20px;">
                                            <table width="100%">
                                                    <tr style="box-shadow: none;">
                                                        <td style="border-top: none;"></td>
                                                        <td style="border-top: none;"><label class="label_desc" style="margin:0; color:#505D6F; font-weight:bold;">No. Rekening</label></td>
                                                    </tr>
                                                <?php foreach($row->Rekening as $rowRekening): ?>
                                                    <tr style="box-shadow: none;">
                                                        <td style="border-top: none;"><i class="fa fa-square" style="margin:0 5px 0  0; color:<?= $rowRekening->color; ?>"></i></td>
                                                        <td style="border-top: none;"><label class="label_desc" style="margin:0; color:#505D6F; font-weight:normal;"><?= $rowRekening->RekNo; ?></label></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </table>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="row show-more" id="rowShowDetailCollapsePortofolio_<?= $iPortofolioRm; ?>" data-id="<?= $iPortofolioRm; ?>">
                            <div class="col-xs-12">
                                <a>
                                    <label id="labelDetailCollapsePortofolio_<?= $iPortofolioRm; ?>">Tampilkan Lebih Banyak<i class="fa fa-chevron-down" style="margin-left:10px;"></i></label>
                                </a>
                            </div>
                        </div>
                        <?php
                                $iPortofolioRm++;
                                endforeach; 
                            endif;
                        ?>
                        <div class="pull-left">
                            <?php if (isset($links)) { ?>
                            <?php echo $links ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?= base_url();?>assets/auto-numeric/autoNumeric.js"></script>
<script>
    var hide = 1;
    $(document).ready(function() {
        $('.money').autoNumeric('init');

        $('.collapse-link').click(function(){
            if(hide == 0){
                $('.search-form').html('Show Filter');
                hide = 1;
            }else{
                $('.search-form').html('Hide Filter');
                hide = 0;
            }
        });

        $(".show-more").click(function(){
            var id = $(this).data('id');
            var collapseStatus = $("#collapsePortofolioStatus_"+id).val();
            if(collapseStatus == 0){
                $("#collapsePortofolioStatus_"+id).val(1);
                $("#labelDetailCollapsePortofolio_"+id).html("Tampilkan Lebih Sedikit <i class='fa fa-chevron-up' style='margin-left:10px;'></i>");
                $("#collapsePortofolio_"+id).fadeIn("slow");                
            }else{
                $("#collapsePortofolioStatus_"+id).val(0);
                $("#labelDetailCollapsePortofolio_"+id).html("Tampilkan Lebih Banyak <i class='fa fa-chevron-down' style='margin-left:10px;'></i>");
                $("#collapsePortofolio_"+id).fadeOut("slow");                
            }
        });

        <?php
            $iCustomer = 0;
            foreach($PortofolioRm as $row):
        ?>
                var xAxis = [];
                var datasetsConfig = [];                
        <?php
                foreach($row->labels as $rowLabel):
        ?>
                    xAxis.push('<?= $rowLabel; ?>');
        <?php
                endforeach;
                foreach($row->Rekening as $rowDatasets):
        ?>
                    var dataDetail = [];
        <?php
                    foreach($rowDatasets->datasets as $rowDetailRekening):
        ?>
                        dataDetail.push(<?= $rowDetailRekening; ?>)
        <?php
                    endforeach;
        ?>
                    datasetsConfig.push({
                        label: "<?= $rowDatasets->RekNo; ?>",
                        fill: false,
                        backgroundColor: "<?= $rowDatasets->color; ?>",
                        borderColor: "<?= $rowDatasets->color; ?>",
                        data: dataDetail
                    });
                    var config = {
                        type: 'line',
                        data: {
                            labels: xAxis,
                            datasets: datasetsConfig
                        },
                        options: {
                            responsive: true,
                            title: {
                                display: false
                            },
                            legend: {
                                display: false
                            },
                            tooltips: {
                                callbacks: {
                                label: function(tooltipItem) {
                                        return (tooltipItem.yLabel).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                                    }
                                }
                            },
                            hover: {
                                mode: 'nearest',
                                intersect: true
                            },
                            scales: {
                                xAxes: [{
                                    display: true,
                                    scaleLabel: {
                                        display: true,
                                        labelString: "Periode",
                                        fontStyle: "bold",
                                    }
                                }],
                                yAxes: [{
                                    display: true,
                                    scaleLabel: {
                                        display: true,
                                        labelString: "Outstanding",
                                        fontStyle: "bold",
                                    },
                                    ticks: {
                                        max: 250000000000,
                                        min: 0,
                                        stepSize: 25000000000,
                                        callback: function(value, index, values) {
                                            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                                        }
                                    }
                                }]
                            }
                        }
                    };                 
        <?php
                endforeach;
        ?>
                var ctx = document.getElementById('canvas_<?= $iCustomer; ?>').getContext('2d');
                window.myLine = new Chart(ctx, config);
        <?php
                $iCustomer++;
            endforeach;
        ?>
    });

    
</script>