
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12">   
                        <div class="accordion" id="accordion_GroupOverview" role="tablist" aria-multiselectable="true">
                            <div class="panel">
                              <a class="panel-heading" role="tab" id="headingGroupOverview1" data-toggle="collapse" data-parent="#accordion_GroupOverview" href="#collapseGroupOverview1" aria-expanded="true" aria-controls="collapseGroupOverview1" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Group Overview</h4>
                              </a>
                              <div id="collapseGroupOverview1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingGroupOverview1">
                                <div class="panel-body" style="padding: 0;">
                                  <?php if (isset($account_planning['GroupOverview'])) {?>
                                  <?php foreach ($account_planning['GroupOverview'] as $row => $value) : ?>
                                  <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0; border-bottom: 1px solid #ddd;">
                                    <div class="col-md-12 col-sm-12 col-xs-12 padding_con">
                                      <div class="col-md-4 col-sm-4 col-xs-12 padding_con">
                                        <span class="detail_property_title">CHILD COMPANY</span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['ChildCompanyName']?></span>
                                      </div>
                                      <div class="col-md-4 col-sm-4 col-xs-12 padding_con">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                          <span class="detail_property_title">CITY</span>
                                          <br>
                                          <span class="detail_property_text"><?=$value['Province']?></span>
                                        </div>
                                      </div>
                                      <div class="col-md-4 col-sm-4 col-xs-12 padding_con">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                          <span class="detail_property_title">LIFE CYCLE</span>
                                          <br>
                                          <span class="detail_property_text"><?=$value['LifeCycle']?></span>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="col-md-4 col-sm-4 col-xs-12 padding_con">
                                      <div class="col-md-12 col-sm-12 col-xs-12 padding_con">
                                        <span class="detail_property_title">ADDRESS</span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['Address1']?></span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['Address2']?></span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['Address3']?></span>
                                      </div>
                                    </div>
                                    <div class="col-md-8 col-sm-8 col-xs-12 padding_con">
                                      <div class="col-md-6 col-sm-6 col-xs-12 padding_con">
                                        <span class="detail_property_title">GLOBAL RATINGS</span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['GlobalRatingName']?> <?=$value['GlobalRatingDescription']?></span>
                                      </div>
                                      <div class="col-md-6 col-sm-6 col-xs-12 padding_con">
                                        <span class="detail_property_title">DOMESTIC RATINGS</span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['DomesticRating']?></span>
                                      </div>
                                      <div class="col-md-6 col-sm-6 col-xs-12 padding_con">
                                        <span class="detail_property_title">INDUSTRY</span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['IndustryName']?></span>
                                      </div>
                                      <div class="col-md-6 col-sm-6 col-xs-12 padding_con">
                                        <span class="detail_property_title">INDUSTRY TREND</span>
                                        <br>
                                        <span class="detail_property_text"><?=$value['IndustryTrend']?></span>
                                      </div>
                                    </div>
                                  </div>
                                  <?php endforeach; ?>
                                  <?php } ?>
                                </div>
                              </div>
                            </div>
                        </div>
                      </div>
                    </div>
                    <div class="row margintop_con">
                      <div class="col-md-6 col-sm-6 col-xs-12">    
                        <div class="accordion" id="accordion_KeyShareholder" role="tablist" aria-multiselectable="true">
                            <div class="panel">
                              <a class="panel-heading" role="tab" id="headingKeyShareholder1" data-toggle="collapse" data-parent="#accordion_KeyShareholder" href="#collapseKeyShareholder1" aria-expanded="true" aria-controls="collapseKeyShareholder1" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Key Shareholder</h4>
                              </a>
                              <div id="collapseKeyShareholder1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingKeyShareholder1">
                                <div class="panel-body" style="padding-top: 0;">
                                  <div class="padding_con">
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <canvas class="canvasDoughnuts" height="140" width="140"></canvas>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                      <table width="100%">
                                          <?php if (isset($account_planning['Shareholder'])) {?>
                                          <?php foreach ($account_planning['Shareholder'] as $row => $value) : ?>
                                        <tr>
                                            <!--<td width="50%" nowrap="nowrap"><?=$value['Portion']?> %</td>-->
                                            <td width="10%" nowrap="nowrap"></td>
                                            <td nowrap="nowrap"><?=$value['Name']?></td>
                                        </tr>
                                        <tr>
                                            <td nowrap="nowrap"></td>
                                            <td nowrap="nowrap"></td>
                                        </tr>
                                          <?php endforeach; ?>
                                          <?php } ?>
                                      </table>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                        </div>
                      </div>
                      <div class="col-md-6 col-sm-6 col-xs-12">                    
                        <div class="accordion" id="accordion_Business" role="tablist" aria-multiselectable="true">
                            <div class="panel">
                              <a class="panel-heading" role="tab" id="headingBusiness1" data-toggle="collapse" data-parent="#accordion_Business" href="#collapseBusiness1" aria-expanded="true" aria-controls="collapseBusiness1" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Business Process and Organization</h4>
                              </a>
                              <div id="collapseBusiness1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingBusiness1">
                                <div class="panel-body">
                                  <div class="col-md-12 col-sm-12 col-xs-12" style="border-bottom: 1px solid #ddd;">
                                    <span class="detail_property_title">Business Process</span>
                                    <div class="padding_con">
                                        <?php if (isset($account_planning['FileStructure']['1'])) {?>
                                        <?php foreach ($account_planning['FileStructure']['1'] as $row => $value) : ?>
                                          <span><a href="<?= base_url("uploads/" . $value['FilePath']) ?>"><i class="fa fa-file-pdf-o" style="color:red"></i> <?=$value['FilePath']?></a></span><br>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>
                                  </div>
                                  <div class="col-md-12 col-sm-12 col-xs-12">
                                    <span class="detail_property_title">Organization</span>
                                    <div class="padding_con">
                                      <span class="detail_property_title">Group Structure</span>
                                      <br>
                                        <?php if (isset($account_planning['FileStructure']['2'])) {?>
                                        <?php foreach ($account_planning['FileStructure']['2'] as $row => $value) : ?>
                                          <span><a href="<?= base_url("uploads/" . $value['FilePath']) ?>"><i class="fa fa-file-pdf" style="color:red"></i> <?=$value['FilePath']?></a></span><br>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>
                                    <div class="padding_con">
                                      <span class="detail_property_title">Company Structure</span>
                                      <br>
                                        <?php if (isset($account_planning['FileStructure']['3'])) {?>
                                        <?php foreach ($account_planning['FileStructure']['3'] as $row => $value) : ?>
                                          <span><a href="<?= base_url("uploads/" . $value['FilePath']) ?>"><i class="fa fa-file-pdf-o" style="color:red"></i> <?=$value['FilePath']?></a></span><br>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>
                                  </div>                                  
                                </div>
                              </div>
                            </div>
                        </div>
                      </div>
                    </div>
                    <div class="row margintop_con">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="accordion" id="accordion_StrategicPlan" role="tablist" aria-multiselectable="true">
                            <div class="panel">
                              <a class="panel-heading" role="tab" id="headingStrategicPlan1" data-toggle="collapse" data-parent="#accordion_StrategicPlan" href="#collapseStrategicPlan1" aria-expanded="true" aria-controls="collapseStrategicPlan1" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Strategic Plan</h4>
                              </a>
                              <div id="collapseStrategicPlan1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingStrategicPlan1">
                                <div class="panel-body" style="padding-top: 0;">
                                  <div class="detail_section_con">
                                    <div class="col-md-6 col-sm-6 col-xs-12 padding_con">
                                      <span class="detail_property_title">1-3 Year Strategic Plan</span>
                                      <br>
                                        <?php if (isset($account_planning['StrategicPlan']['1'])) {?>
                                        <?php $index_strategic1 = 1; ?>
                                        <?php foreach ($account_planning['StrategicPlan']['1'] as $row => $value) : ?>
                                          <table width="100%">
                                            <tr>
                                              <td width="5%" valign="top"><?=$index_strategic1;?></td>
                                              <td><?=$value['Name']?></td>
                                            </tr>
                                          </table>
                                        <?php $index_strategic1++?>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>       
                                    <div class="col-md-6 col-sm-6 col-xs-12 padding_con">
                                      <span class="detail_property_title">>3 Year Strategic Plan</span>
                                      <br>
                                        <?php if (isset($account_planning['StrategicPlan']['2'])) {?>
                                        <?php $index_strategic2 = 1; ?>
                                        <?php foreach ($account_planning['StrategicPlan']['2'] as $row => $value) : ?>
                                          <table width="100%">
                                            <tr>
                                              <td width="5%" valign="top"><?=$index_strategic2;?></td>
                                              <td><?=$value['Name']?></td>
                                            </tr>
                                          </table>
                                        <?php $index_strategic2++?>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>       
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                      </div>
                    </div>
                    <div class="row margintop_con">
                      <div class="col-md-12 col-sm-12 col-xs-12">      
                        <div class="accordion" id="accordion_CoverageMapping" role="tablist" aria-multiselectable="true">
                            <div class="panel">
                              <a class="panel-heading" role="tab" id="headingCoverageMapping1" data-toggle="collapse" data-parent="#accordion_CoverageMapping" href="#collapseCoverageMapping1" aria-expanded="true" aria-controls="collapseCoverageMapping1" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Coverage Mapping</h4>
                              </a>
                              <div id="collapseCoverageMapping1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingCoverageMapping1">
                                <div class="panel-body" style="padding: 0;">
                                  <?php if (isset($account_planning['CoverageMapping'])) {?>
                                  <?php foreach ($account_planning['CoverageMapping'] as $row => $value) : ?>
                                  <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0 0 10px 0;border-bottom: 1px solid #ddd;">
                                    <div class="col-md-9 col-sm-9 col-xs-12 margintop_con">
                                      <div class="col-md-12 col-sm-12 col-xs-12 ">
                                        <div class="col-md-4 col-sm-4 col-xs-12 ">
                                          <span class="detail_property_title">Client Name</span>
                                          <br>
                                          <span class="detail_property_text"><?=$value['ClientName']?></span>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-12 ">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                            <span class="detail_property_title">Client Contact</span>
                                            <br>
                                            <span class="detail_property_text"><?=$value['ContactNumber']?></span>
                                          </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-12 ">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                            <span class="detail_property_title">Client Position</span>
                                          <br>
                                          <span class="detail_property_text"><?=$value['ClientPosition']?></span>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="col-md-12 col-sm-12 col-xs-12 margintop_con">
                                        <div class="col-md-4 col-sm-4 col-xs-12 ">
                                            <span class="detail_property_title">Bank Person Name</span>
                                            <br>
                                            <span class="detail_property_text"><?=$value['BankPerson']?></span>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-12 ">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                            <span class="detail_property_title">Bank Contact</span>
                                            <br>
                                            <span class="detail_property_text"><?=$value['BankContact']?></span>
                                          </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-12 ">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                            <span class="detail_property_title">Bank Position</span>
                                            <br>
                                            <span class="detail_property_text"><?=$value['BankPosition']?></span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12 margintop_con">
                                      <div class="col-md-12 col-sm-12 col-xs-12 ">
                                          <span class="detail_property_title">Other Information</span>
                                          <br>
                                          <span class="detail_property_text"><?=$value['OtherInformation']?></span>
                                      </div>
                                    </div>
                                  </div>
                                  <?php endforeach; ?>
                                  <?php } ?>                                  
                                </div>
                              </div>
                            </div>
                        </div>
                      </div>
                    </div>
                    <div class="row margintop_con">
                      <div class="col-md-6 col-sm-6 col-xs-12">    
                        <div class="accordion" id="accordion_RecentActivities" role="tablist" aria-multiselectable="true">
                            <div class="panel">
                              <a class="panel-heading" role="tab" id="headingRecentActivities1" data-toggle="collapse" data-parent="#accordion_RecentActivities" href="#collapseRecentActivities1" aria-expanded="true" aria-controls="collapseRecentActivities1" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Recent Activities</h4>
                              </a>
                              <div id="collapseRecentActivities1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingRecentActivities1">
                                <div class="panel-body" style="padding-top: 0;">
                                  <div class="col-md-12 col-sm-12 col-xs-12 marginsbottom_con" style="padding: 0;border-bottom: 1px solid #ddd;">
                                  </div>                                  
                                </div>
                              </div>
                            </div>
                        </div>
                      </div>
                      <div class="col-md-6 col-sm-6 col-xs-12">                    
                        <div class="accordion" id="accordion_CSTMembers" role="tablist" aria-multiselectable="true">
                            <div class="panel">
                              <a class="panel-heading" role="tab" id="headingCSTMembers1" data-toggle="collapse" data-parent="#accordion_CSTMembers" href="#collapseCSTMembers1" aria-expanded="true" aria-controls="collapseCSTMembers1" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> CST Members</h4>
                              </a>
                              <div id="collapseCSTMembers1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingCSTMembers1">
                                <div class="panel-body" style="padding: 0;">
                              <?php if (isset($account_planning['MemberCST'])) {?>
                                <?php $index_member = 1; ?>
                                <?php foreach ($account_planning['MemberCST'] as $row => $value) : ?>
                                  <div class="x_content detail_section_con padding_con">
                                            <span><?= $index_member ?>. <?=$value['Name']?></span><br>
                                  </div>
                                <?php $index_member++?>
                                <?php endforeach; ?>
                              <?php } ?>
                                </div>
                              </div>
                            </div>
                        </div>
                      </div>
                    </div>
                    <div class="row margintop_con">
                    </div>

