			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion" id="accordion_Initiatives" role="tablist" aria-multiselectable="true">
                        <div class="panel">
                          <a class="panel-heading" role="tab" id="headingInitiatives1" data-toggle="collapse" data-parent="#accordion_Initiatives" href="#collapseInitiatives1" aria-expanded="true" aria-controls="collapseInitiatives1" style="border-bottom: 1px solid #ddd;">
                            <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Fundings</h4>
                          </a>
                          <div id="collapseInitiatives1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingInitiatives1">
                            <div class="panel-body" style="padding-top: 0;">
                              <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con" style="padding-top: 0;">
                                <div class="detail_property_title col-md-1 col-sm-1 col-xs-12">
                                    No
                                </div>
                                <div class="detail_property_title col-md-5 col-sm-5 col-xs-12">
                                    Kebutuhan Pendanaan
                                </div>
                                <div class="detail_property_title col-md-3 col-sm-3 col-xs-12">
                                    Jangka Waktu
                                </div>
                                <div class="detail_property_title col-md-3 col-sm-3 col-xs-12">
                                    Nominal
                                </div>
                              </div>
                                <?php if (isset($account_planning['Funding'])) {?>
                                <?php $index_funding = 1; ?>
                                <?php foreach ($account_planning['Funding'] as $row => $value) : ?>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="detail_property_text col-md-1 col-sm-1 col-xs-12">
                                        <?= $index_funding ?>
                                    </div>
                                    <div class="detail_property_text col-md-5 col-sm-5 col-xs-12">
                                        <?=$value['FundingNeed']?>
                                    </div>
                                    <div class="detail_property_text col-md-3 col-sm-3 col-xs-12">
                                        <?=$value['TimePeriod']?>
                                    </div>
                                    <div class="detail_property_text col-md-3 col-sm-3 col-xs-12">
                                        Rp. <?=number_format($value['Amount'], 2)?>
                                    </div>
                                </div>
                                <?php $index_funding++?>
                                <?php endforeach; ?>
                                <?php } ?>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row margintop_con">
				<div class="col-md-12 col-sm-12 col-xs-12">    
                  <div class="accordion" id="accordion_Services" role="tablist" aria-multiselectable="true">
                    <div class="panel">
                      <a class="panel-heading" role="tab" id="headingServices1" data-toggle="collapse" data-parent="#accordion_Services" href="#collapseServices1" aria-expanded="true" aria-controls="collapseServices1" style="border-bottom: 1px solid #ddd;">
                        <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Services</h4>
                      </a>
                      <div id="collapseServices1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingServices1">
                        <div class="panel-body" style="padding-top: 0;">
                            <?php if (isset($account_planning['Service'])) {?>
                            <?php $index_service = 1; ?>
                            <?php foreach ($account_planning['Service'] as $row => $value) : ?>
                            <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con">
                                <div class="detail_property_text col-md-1 col-sm-1 col-xs-12 ">
                                    <?= $index_service ?>
                                </div>
                                <div class="detail_property_text col-md-11 col-sm-11 col-xs-12 ">
                                    <?=$value['ServiceName']?>
                                </div>
                                <div class="detail_property_text col-md-1 col-sm-1 col-xs-12 ">
                                </div>
                                <div class="detail_property_text col-md-11 col-sm-11 col-xs-12 ">
                                    <?php if (isset($value['TagServiceUnitKerja'])) {?>
                                    <?php foreach ($value['TagServiceUnitKerja'] as $rows => $values) : ?>
                                    <label class="label label-info">    # <?=$values['TagServiceUnitKerja']?></label>
                                    <?php endforeach; ?>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php $index_service++?>
                            <?php endforeach; ?>
                            <?php } ?>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <div class="row margintop_con">
            </div>
