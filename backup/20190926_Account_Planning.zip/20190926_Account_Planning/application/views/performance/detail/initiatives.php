                          <div class="row" style="padding-top: 3px; border-radius: 4px;">
                            <div class="col-md-12 col-sm-12 col-xs-12">    
                              <div class="accordion" id="accordion_Initiatives" role="tablist" aria-multiselectable="true">
                                <div class="panel">
                                  <a class="panel-heading" role="tab" id="headingEstimatedFinancialInitiatives1" data-toggle="collapse" data-parent="#accordion_EstimatedFinancial" href="#collapseEstimatedFinancialInitiatives1" aria-expanded="true" aria-controls="collapseEstimatedFinancialInitiatives1" style="border-bottom: 1px solid #ddd;">
                                    <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> Initiatives and Action Plan</h4>
                                  </a>
                                  <div id="collapseEstimatedFinancialInitiatives1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingEstimatedFinancialInitiatives1">
                                    <div class="panel-body" style="padding-top: 0;">
                                      <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con" style="padding-top: 0;">
                                        <div class="detail_property_title col-md-1 col-sm-1 col-xs-12">
                                          No
                                        </div>
                                        <div class="detail_property_title col-md-4 col-sm-4 col-xs-12">
                                          Initiatives
                                        </div>
                                        <div class="detail_property_title col-md-3 col-sm-3 col-xs-12">
                                          Action Plan
                                        </div>
                                        <div class="detail_property_title col-md-4 col-sm-4 col-xs-12">
                                          Description
                                        </div>
                                      </div>
                                      <?php if (isset($account_planning['InitiativeAction'])) {?>
                                      <?php $index1 = 1; ?>
                                      <?php foreach ($account_planning['InitiativeAction'] as $row => $value) : ?>
                                        <div class="col-md-12 col-sm-12 col-xs-12 marginstop_con" style="padding-top: 0;">
                                          <div class="detail_property_text col-md-1 col-sm-1 col-xs-12">
                                            <?= $index1 ?>
                                          </div>
                                          <div class="detail_property_text col-md-4 col-sm-4 col-xs-12">
                                            <?=$value['Name']?>
                                          </div>
                                          <div class="detail_property_text col-md-3 col-sm-3 col-xs-12">
                                            <?=$value['Period']?>
                                          </div>
                                          <div class="detail_property_text col-md-4 col-sm-4 col-xs-12">
                                            Rp. <?=$value['Description']?>
                                          </div>
                                        </div>
                                        <?php $index1++?>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>

                            </div>
                          </div>