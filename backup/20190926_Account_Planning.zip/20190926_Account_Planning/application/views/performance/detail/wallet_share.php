<style type="text/css">
.detail_title {
  font-weight: 600;
  font-size: 14px;
  line-height: 136.89%;
  display: flex;
  align-items: center;
  letter-spacing: 0.25px;
  color: #707070;
}
.detail_property_titles {
  font-weight: 600;
  font-size: 12px;
  line-height: 24px;
  letter-spacing: 0.5px;
  color: #218FD8;
}
.detail_property_titles2 {
  font-weight: 600;
  font-size: 12px;
  line-height: 24px;
  letter-spacing: 0.5px;
  color: #F58C38;
}
</style>

                    <!-- <div class="x_title detail_section_header_con">
                      <h5 class="detail_section_title">Action Plans</h5>
                    </div> -->
                    <div class="row" style="padding-top: 3px; border-radius: 4px;">
	                    <div class="col-md-12 col-sm-12 col-xs-12">
		                    <div class="accordion" id="accordion_WalletShare" role="tablist" aria-multiselectable="true">
                            <?php foreach ($account_planning['WalletShare'] as $row => $value) : ?>
                            <div class="panel">
                              <a class="panel-heading<?=$value[0]['heading_panel']?>" role="tab" id="headingWalletShare<?=$value[0]['BankFacilityGroupId']?>" data-toggle="collapse" data-parent="#accordion_WalletShare" href="#collapseWalletShare<?=$value[0]['BankFacilityGroupId']?>" aria-expanded="<?=$value[0]['expanded_panel']?>" aria-controls="collapseWalletShare<?=$value[0]['BankFacilityGroupId']?>" style="border-bottom: 1px solid #ddd;">
                                <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> <?=$value[0]['BankFacilityGroupName']?></h4>
                              </a>
                              <div id="collapseWalletShare<?=$value[0]['BankFacilityGroupId']?>" class="panel-collapse<?=$value[0]['tab_panel']?>" role="tabpanel" aria-labelledby="headingWalletShare<?=$value[0]['BankFacilityGroupId']?>">
			                          <div class="panel-body" style="padding-top: 0;">
                                  <?php if (isset($value['WalletShare_details'])) {?>
                                  <?php foreach ($value['WalletShare_details'] as $rows => $values) : ?>
                                  <div class="col-md-12 col-sm-12 col-xs-12 margintop_con" style="border-bottom: 1px solid #ddd;">
                                        <p class="detail_property_titles"><?=$values['BankFacilityItemName']?></p>
                                  </div>
                                  <div class="col-md-4 col-sm-4 col-xs-12 margintop_con">
                                    <p>
                                      Total : <b>RP. <?=$values['TotalAmount']?>,-</b>
                                    </p>
                                  </div>
                                  <div class="col-md-8 col-sm-8 col-xs-12 margintop_con">
                                    <p>
                                      Notes : <span class="detail_property_titles2">#In Million</span>
                                    </p>
                                  </div>
                                  <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0; border-bottom: 1px solid #ddd;">
                                    <div class="col-md-6 col-sm-6 col-xs-12" style="padding: 0; border-right: 1px solid #ddd;">
                                      <div class="col-md-6 col-sm-6 col-xs-12">
                                        <span class="detail_property_title">Nominal BRI</span>
                                        <br>
                                            <?=$values['BRINominal']?>
                                      </div>
                                      <div class="col-md-6 col-sm-6 col-xs-12">
                                        <span class="detail_property_title">Portion</span>
                                        <br>
                                        <?= $values['BRIPortion']; ?>%
                                        <!-- <div class="progress" style="height: 20px; width: 100%">
                                          <div class="progress-bar progress-bar-info" data-transitiongoal="<?= $values['BRIPortion']; ?>"> <?= $values['BRIPortion']; ?>%</div>
                                        </div> -->
                                      </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-12" style="padding: 0;">
                                      <div class="col-md-6 col-sm-6 col-xs-12">
                                        <span class="detail_property_titles2">Nominal Other Bank</span>
                                        <br>
                                            <?=$values['OtherNominal']?>
                                      </div>
                                      <div class="col-md-6 col-sm-6 col-xs-12">
                                        <span class="detail_property_titles2">Portion</span>
                                        <br>
                                        <?= $values['OtherPortion']; ?>%
                                        <!-- <div class="progress" style="height: 20px; width: 100%;">
                                          <div class="progress-bar" data-transitiongoal="<?= $values['OtherPortion']; ?>" style="background-color: #e6531b;"> <?= $values['OtherPortion']; ?>%</div>
                                        </div> -->
                                      </div>
                                    </div>
                                  </div>
                                  <?php endforeach; ?>
                                  <?php } ?>
			                          </div>
			                        </div>
			                      </div>
                            <?php endforeach; ?>
		                    </div>
	                    </div>
                    </div>


