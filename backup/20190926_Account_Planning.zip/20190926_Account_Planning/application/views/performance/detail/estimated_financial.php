                    <div class="row" style="padding-top: 3px; border-radius: 4px;">
                      <div class="col-md-12 col-sm-12 col-xs-12">
				                    <div class="accordion" id="accordion_EstimatedFinancial" role="tablist" aria-multiselectable="true">
                              <?php foreach ($account_planning['EstimatedFinancial'] as $row => $value) : ?>
                            	  <div class="panel">
                                  <a class="panel-heading<?=$value[0]['heading_panel']?>" role="tab" id="headingEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" data-toggle="collapse" data-parent="#accordion_EstimatedFinancial" href="#collapseEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" aria-expanded="<?=$value[0]['expanded_panel']?>" aria-controls="collapseEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" style="border-bottom: 1px solid #ddd;">
                                    <h4 class="panel-title detail_title"><i class="fa fa-chevron-down" style="font-size: 8px; padding-right: 10px; color: #218FD8;"></i> <?=$value[0]['BankFacilityGroupName']?></h4>
                                  </a>
                                  <div id="collapseEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>" class="panel-collapse<?=$value[0]['tab_panel']?>" role="tabpanel" aria-labelledby="headingEstimatedFinancial<?=$value[0]['BankFacilityGroupId']?>">
                                    <div class="panel-body" style="padding-top: 0;">
                                      <?php if (isset($value['EstimatedFinancial_detail'])) {?>
                                      <?php foreach ($value['EstimatedFinancial_detail'] as $rows => $values) : ?>
  					                            <div class="col-md-12 col-sm-12 col-xs-12 margintop_con" style="border-bottom: 1px solid #ddd;">
                                          <p class="detail_property_titles"><?=$values['BankFacilityItemName']?></p>
                                          <p>
                                            Notes : <span class="detail_property_titles2">#In Million</span>
                                          </p>
                                          <div class="col-md-6 col-sm-6 col-xs-12" style="border-top: 1px solid #ddd; border-right: 1px solid #ddd;">
                                            <p class="detail_property_titles"><?=$values['IDR']?></p>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                              <canvas class="<?=$values['LabelsName_idr']?>" height="140" width="140" style="margin: 15px 10px 10px 0; z-index: 10;"></canvas>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12 margintop_con">
                                              <div class="col-md-12 col-sm-12 col-xs-12">
                                                Projection Cost
                                                <br>
                                                Rp. <?=$values['IDRProjection']?>
                                              </div>
                                              <div class="col-md-12 col-sm-12 col-xs-12">
                                                BRI's Target
                                                <br>
                                                Rp. <?=$values['IDRTarget']?>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="col-md-6 col-sm-6 col-xs-12" style="border-top: 1px solid #ddd;">
                                            <p class="detail_property_titles"><?=$values['Valas']?></p>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                              <canvas class="<?=$values['LabelsName_valas']?>" height="140" width="140" style="margin: 15px 10px 10px 0; z-index: 10;"></canvas>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12 margintop_con">
                                              <div class="col-md-12 col-sm-12 col-xs-12">
                                                Projection Cost
                                                <br>
                                                Rp. <?=$values['ValasProjection']?>
                                              </div>
                                              <div class="col-md-12 col-sm-12 col-xs-12">
                                                BRI's Target
                                                <br>
                                                Rp. <?=$values['ValasTarget']?>
                                              </div>
                                            </div>
                                          </div>
    						                        </div>
                                      <?php endforeach; ?>
                                      <?php } ?>
					                          </div>
					                        </div>
					                      </div>
                              <?php endforeach; ?>
				                    </div>
                      </div>
                    </div>
