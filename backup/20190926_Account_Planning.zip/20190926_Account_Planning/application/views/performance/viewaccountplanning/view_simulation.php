<br/>
<b>Direct Loan</b>
<div id="table-input_simulasi_dirloan" class="table-editable table-account-planning">
    <table class="table">
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
            <th rowspan="2" width="15%" style="text-align: center;">Facilities</th>
            <th colspan="2">Plafond</th>
            <th colspan="2">Outstanding </th>
            <th colspan="2">Ratas Harian</th>
            <th colspan="2">Tenor</th>
            <th colspan="2">Indicative Rate</th>
            <th colspan="2">Income / Expense</th>
            <th colspan="2">Provision Rate</th>
            <th colspan="2">Provision</th>
            <th colspan="2">Fee</th>

        </tr>
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
        </tr>
        <tr align="center">
            <td class="txt" contenteditable="false" style="text-align: left;">KMK</td>
            <td class="txt" contenteditable="false" style="text-align: right;">500,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">350,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">300,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">24</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">6<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0.5<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">100</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>

        </tr>
        <!-- This is our clonable table line -->

    </table>
</div>

<br />
<b>inDirect Loan</b>
<div id="table-input_simulasi_indirloan" class="table-editable table-account-planning">
  <!-- <span class="table-input_form-add glyphicon glyphicon-plus"></span> -->
    <table class="table">
      <!-- <tr>
        <th rowspan="2"><span style="margin: 0 auto;">Facilities</span></th>
        <th colspan="4">Amount Rate</th>
      </tr> -->
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
          <!-- <th>No.</th> -->
            <th rowspan="2" width="15%" style="text-align: center;">Facilities</th>
            <th colspan="2">Plafond</th>
            <th colspan="2">Outstanding </th>
            <th colspan="2">Ratas Harian</th>
            <th colspan="2">Tenor</th>
            <th colspan="2">Indicative Rate</th>
            <th colspan="2">Income / Expense</th>
            <th colspan="2">Provision Rate</th>
            <th colspan="2">Provision</th>
            <th colspan="2">Fee</th>

        </tr>
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
        </tr>
        <tr align="center">
            <td class="txt" contenteditable="false" style="text-align: left;">KMK</td>
            <td class="txt" contenteditable="false" style="text-align: right;">500,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">350,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">300,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">24</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">6<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0.5<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">100</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>

        </tr>
    </table>		  
</div>
<br />
<b>Cash</b>
<div id="table-input_simulasi_indirloan" class="table-editable table-account-planning">
    <table class="table">
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
            <th rowspan="2" width="15%" style="text-align: center;">Facilities</th>
            <th colspan="2">Plafond</th>
            <th colspan="2">Outstanding </th>
            <th colspan="2">Ratas Harian</th>
            <th colspan="2">Tenor</th>
            <th colspan="2">Indicative Rate</th>
            <th colspan="2">Income / Expense</th>
            <th colspan="2">Provision Rate</th>
            <th colspan="2">Provision</th>
            <th colspan="2">Fee</th>

        </tr>
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
        </tr>
        <tr align="center">
            <td class="txt" contenteditable="false" style="text-align: left;">KMK</td>
            <td class="txt" contenteditable="false" style="text-align: right;">500,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">350,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">300,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">24</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">6<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0.5<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">100</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>

        </tr>
    </table>

</div>
<br />
<b>Transaction Banking</b>
<div id="table-input_simulasi_indirloan" class="table-editable table-account-planning">
    <table class="table">
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
            <th rowspan="2" width="15%" style="text-align: center;">Facilities</th>
            <th colspan="2">Plafond</th>
            <th colspan="2">Outstanding </th>
            <th colspan="2">Ratas Harian</th>
            <th colspan="2">Tenor</th>
            <th colspan="2">Indicative Rate</th>
            <th colspan="2">Income / Expense</th>
            <th colspan="2">Provision Rate</th>
            <th colspan="2">Provision</th>
            <th colspan="2">Fee</th>

        </tr>
        <tr class="input_form" style="background: #012D5A; color: #FFF;">
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
            <th>IDR</th>
            <th>Valas</th>
        </tr>
        <tr align="center">
            <td class="txt" contenteditable="false" style="text-align: left;">KMK</td>
            <td class="txt" contenteditable="false" style="text-align: right;">500,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">350,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">300,000</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">24</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">6<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0.5<span> %</span></td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">50</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>
            <td class="txt" contenteditable="false" style="text-align: right;">100</td>
            <td class="txt" contenteditable="false" style="text-align: right;">0</td>

        </tr>
    </table>
    <div class="btn-annual">
        <a target="blank" href="<?= base_url(); ?>perform/companyinformations/summary_cpa" class="btn btn-info">
            View CPA
        </a>		    
    </div>
</div>