		</br>
		<div class="form-group" style="margin-bottom: 20px;">
	        <label class="control-label col-sm-2" for="pwd">Kurs USD:</label>
	        <div class="col-sm-2">          
	        <input type="number" class="form-control" id="lurs" name="lurs" disabled>
	      </div>
	    </div>
		<br/>
		<br/>
		<div id="table-input_simulasi_dirloan" class="col-md-12 col-sm-12 col-xs-12">
		  <!-- <span class="table-input_form-add glyphicon glyphicon-plus"></span> -->
		  <table class="table">
		    <!-- <tr>
		      <th rowspan="2"><span style="margin: 0 auto;">Facilities</span></th>
		      <th colspan="4">Amount Rate</th>
		    </tr> -->
		    <tr class="input_form" style="background: #012D5A; color: #FFF;">
		      <!-- <th>No.</th> -->
		      <th></th>
		      <th>IDR</th>
		      <th>Valas </th>
		     
		    </tr>
		   
		    <tr align="center">
		      <td class="txt" contenteditable="false" style="text-align: left;">FTP Simpanan</td>
		      <td class="txt" contenteditable="false" style="text-align: right;">10%</td>
		      <td class="txt" contenteditable="false" style="text-align: right;">0</td>		     		     
		    </tr>
		     <tr align="center">
		      <td class="txt" contenteditable="false" style="text-align: left;">FTP Pimjanan</td>
		      <td class="txt" contenteditable="false" style="text-align: right;">7%</td>
		      <td class="txt" contenteditable="false" style="text-align: right;">0</td>		     		     
		    </tr>
		    <!-- This is our clonable table line -->
		  </table>
		</div>