<div class="right_col" role="main">
    <div class="container">
    	<!-- isi konten ditaro disini -->
    	<div class="row">
    		<div class="col-md-12 col-sm-12 col-xs-12">
	    		<div class="x_panel">
    				<div class="x_content">
    					<?php $this->load->view('performance/company/table/annual_status.php'); ?>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
</div>