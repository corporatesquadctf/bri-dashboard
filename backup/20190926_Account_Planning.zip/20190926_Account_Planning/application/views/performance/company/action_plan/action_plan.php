<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
        <div class="x_title">
            <h2><small>ESTIMATED FINANCIAL (END OF YEAR)</small></h2>
            <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>

                <li class="dropdown">
            </ul>
            <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <?php $this->load->view('performance/company/action_plan/estimated_financial.php'); ?>
        </div>
    </div>
</div>

<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
        <div class="x_title">
            <h2><small>INITIATIVES & ACTION PLAN</small></h2>
            <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div class="x_content">
            <?php $this->load->view('performance/company/action_plan/initiative_action.php'); ?>
        </div>
    </div>
</div>