<table class="table table-striped">
    <!-- <thead>
      <tr>
        <th>Log</th>
        <th>Activity</th>
      </tr>
    </thead> -->
    <tbody>
    	<tr>
    		<td>
        	2018-09-22 21:10:44
	        </td>
	        <td>
	        	Approved by bos algifari
	        </td>
    	</tr>
    	<tr>
    		<td>
        	2018-09-12 21:10:44
	        </td>
	        <td>
	        	Submited by algifari
	        </td>
    	</tr>
    	<tr>
    		<td>
        	2018-09-12 21:10:44
	        </td>
	        <td>
	        	Rejected by bos algifari
	        </td>
    	</tr>
    	<tr>
    		<td>
        	2018-07-18 21:10:44
	        </td>
	        <td>
	        	checked by kakak algifari
	        </td>
    	</tr>
    	<tr>
    		<td>
        	2018-07-12 21:10:44
	        </td>
	        <td>
	        	Submited by algifari
	        </td>
    	</tr>
	    <tr>
	        <td>
	        	2018-07-09 20:10:44
	        </td>
	        <td>
	        	changed by algifari (key shareholder)
	        </td>
	    </tr>
    </tbody>
  </table>