<br />
<b>Direct Loan</b>
<div id="table-dirloan" class="table-editable table-account-planning">
  <!-- <span class="table-dirloan-add glyphicon glyphicon-plus"></span> -->
  <table class="table">
    <!-- <tr>
      <th rowspan="2"><span style="margin: 0 auto;">Facilities</span></th>
      <th colspan="4">Amount Rate</th>
    </tr> -->
    <tr class="dirloan" style="background: #012D5A; color: #FFF;">
      <!-- <th>No.</th> -->
      <th>Kategori</th>
      <th>IDR</th>
      <th>%</th>
      <th>Valas</th>
      <th>%</th>
      <th></th>
    </tr>
    <tr align="center">
      <!-- <td class="txt" contenteditable="true">1</td> -->
      <td class="txt dis-none" contenteditable="true">nama kategori</td>
      <td class="txt" contenteditable="true">KI </td>
      <td class="txt" contenteditable="true"></td>
      <td class="txt" contenteditable="true"></td>
      <td class="txt" contenteditable="true"> </td>
      <td></td>
      <td>
        <!-- <span class="table-dirloan-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-dirloan-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
    <tr align="center">
      <!-- <td class="txt" contenteditable="true">1</td> -->
      <td class="txt dis-none" contenteditable="true">nama kategori</td>
      <td class="txt" contenteditable="true">KMK </td>
      <td class="txt" contenteditable="true"></td>
      <td class="txt" contenteditable="true">50000</td>
      <td class="txt" contenteditable="true"> Libor 1 Mo + 2.85%  </td>
      <td></td>
      <td>
        <!-- <span class="table-dirloan-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-dirloan-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
    <!-- This is our clonable table line -->
    <tr class="hide" align="center">
      <!-- <td class="txt" contenteditable="true">Untitled</td> -->
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td>
        <!-- <span class="table-dirloan-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-dirloan-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
  </table>
  <div class="btn-annual">
    <button id="export-dirloan-btn" class="btn btn-primary">
      <span class="glyphicon glyphicon-floppy-disk"></span>
    </button>
    <button id="export-dirloan-btn" class="btn btn-warning table-dirloan-add">
      <span class="glyphicon glyphicon-plus"></span> Row
    </button>
  </div>
  <p id="export-dirloan"></p>
</div>
<br>       
<b>InDirect Loan</b>
<div id="table-indirloan" class="table-editable table-account-planning">
  <!-- <span class="table-indirloan-add glyphicon glyphicon-plus"></span> -->
  <table class="table">
    <!-- <tr>
      <th rowspan="2"><span style="margin: 0 auto;">Facilities</span></th>
      <th colspan="4">Amount Rate</th>
    </tr> -->
    <tr class="indirloan" style="background: #012D5A; color: #FFF;">
      <!-- <th>No.</th> -->
      <th>Kategori</th>
      <th>IDR</th>
      <th>%</th>
      <th>Valas</th>
      <th>%</th>
      <th></th>
    </tr>
    <tr align="center">
      <!-- <td class="txt" contenteditable="true">1</td> -->
      <td class="txt" contenteditable="true">nama kategori</td>
      <td class="txt" contenteditable="true">Bank Guarantee </td>
      <td class="txt" contenteditable="true">100%</td>
      <td class="txt" contenteditable="true">20020 </td>
      <td class="txt" contenteditable="true">30% </td>
      <td>
        <!-- <span class="table-indirloan-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-indirloan-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
    <tr align="center">
      <!-- <td class="txt" contenteditable="true">1</td> -->
      <td class="txt" contenteditable="true">nama kategori</td>
      <td class="txt" contenteditable="true">Bank Guarantee </td>
      <td class="txt" contenteditable="true">100%</td>
      <td class="txt" contenteditable="true">20020 </td>
      <td class="txt" contenteditable="true">30% </td>
      <td>
        <!-- <span class="table-indirloan-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-indirloan-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
    <!-- This is our clonable table line -->
    <tr class="hide" align="center">
      <!-- <td class="txt" contenteditable="true">Untitled</td> -->
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td>
        <!-- <span class="table-indirloan-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-indirloan-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
  </table>
  <div class="btn-annual">
    <button id="export-indirloan-btn" class="btn btn-primary">
      <span class="glyphicon glyphicon-floppy-disk"></span>
    </button>
    <button id="export-indirloan-btn" class="btn btn-warning table-indirloan-add">
      <span class="glyphicon glyphicon-plus"></span> Row
    </button>
  </div>
  <p id="export-indirloan"></p>
</div>
<br>
<b>Cash</b>
<div id="table-cash" class="table-editable table-account-planning">
  <!-- <span class="table-cash-add glyphicon glyphicon-plus"></span> -->
  <table class="table">
    <!-- <tr>
      <th rowspan="2"><span style="margin: 0 auto;">Facilities</span></th>
      <th colspan="4">Amount Rate</th>
    </tr> -->
    <tr class="cash" style="background: #012D5A; color: #FFF;">
      <!-- <th>No.</th> -->
      <th>Kategori</th>
      <th>IDR</th>
      <th>%</th>
      <th>Valas</th>
      <th>%</th>
      <th></th>
    </tr>
    <tr align="center">
      <!-- <td class="txt" contenteditable="true">1</td> -->
      <td class="txt" contenteditable="true">nama kategori</td>
      <td class="txt" contenteditable="true">100 </td>
      <td class="txt" contenteditable="true">100%</td>
      <td class="txt" contenteditable="true">20020 </td>
      <td class="txt" contenteditable="true">30% </td>
      <td>
        <!-- <span class="table-cash-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-cash-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
    <!-- This is our clonable table line -->
    <tr class="hide" align="center">
      <!-- <td class="txt" contenteditable="true">Untitled</td> -->
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td>
        <!-- <span class="table-cash-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-cash-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
  </table>
  <div class="btn-annual">
    <button id="export-cash-btn" class="btn btn-primary">
      <span class="glyphicon glyphicon-floppy-disk"></span>
    </button>
    <button id="export-cash-btn" class="btn btn-warning table-cash-add">
      <span class="glyphicon glyphicon-plus"></span> Row
    </button>
  </div>
  <p id="export-cash"></p>
</div>
<br>
<b>Transaction Banking</b>
<div id="table-transc_banking" class="table-editable table-account-planning">
  <!-- <span class="table-transc_banking-add glyphicon glyphicon-plus"></span> -->
  <table class="table">
    <tr class="transc_banking" style="background: #012D5A; color: #FFF;">
      <!-- <th>No.</th> -->
      <th>Kategori</th>
      <th>IDR</th>
      <th>%</th>
      <th>Valas</th>
      <th>%</th>
      <th></th>
    </tr>
    <tr align="center">
      <!-- <td class="txt" contenteditable="true">1</td> -->
      <td class="txt" contenteditable="true">nama kategori</td>
      <td class="txt" contenteditable="true">100 </td>
      <td class="txt" contenteditable="true">100%</td>
      <td class="txt" contenteditable="true">20020 </td>
      <td class="txt" contenteditable="true">30% </td>
      <td>
        <!-- <span class="table-transc_banking-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-transc_banking-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
    <!-- This is our clonable table line -->
    <tr class="hide" align="center">
      <!-- <td class="txt" contenteditable="true">Untitled</td> -->
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td class="txt" contenteditable="true">...</td>
      <td>
        <!-- <span class="table-transc_banking-up glyphicon glyphicon-arrow-up"></span>
        <span class="table-transc_banking-down glyphicon glyphicon-arrow-down"></span> -->
        <span class="table-remove glyphicon glyphicon-remove"></span>
      </td>
    </tr>
  </table>
  <div class="btn-annual">
    <button id="export-transc_banking-btn" class="btn btn-primary">
      <span class="glyphicon glyphicon-floppy-disk"></span>
    </button>
    <button id="export-transc_banking-btn" class="btn btn-warning table-transc_banking-add">
      <span class="glyphicon glyphicon-plus"></span> Row
    </button>
  </div>
  <p id="export-transc_banking"></p>
</div>
<p id="export-dirloan"></p>