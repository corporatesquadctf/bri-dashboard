<table data-toggle="table" data-pagination="true" class="table table-striped table-hover">
	<thead style="background-color: #012D5A; color: #FFF;">
		<tr class="headings">
			<th class="" data-sortable="true">#</th>
			<th class="" data-sortable="true" data-field="name">Customer Name</th>
			<th class="" data-sortable="true">Status</th>
			<!-- <th class="">Submited Date</th>
			<th class="">Last Modified Date</th> -->
			<th class="" align="center" style="text-align: center;">Action</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>1</td>
			<td>PT Astragraphia</td>
			<td>
				<!-- if else -->
				<span class=" label label-lg label-warning full-width">Checked</span> 
				<span class=" label label-lg label-danger full-width">Rejected</span>
				<span class=" label label-lg label-success full-width">Approved</span>
			</td>
			<!-- <td>
				01-01-2017 19:00
			</td>
			<td align="center">
				01-01-2018 19:00
			</td> -->
			<td class="last" align="center" style="text-align: center;">
				<a href="#" class="btn btn-xs btn-info">
					<i class="fa fa-edit"></i>&nbsp;<b>View Report</b>
				</a>
				<a href="#" class="btn btn-xs btn-info">
					<i class="fa fa-eye"></i>
				</a>
			</td>
		</tr>
	</tbody>
</table>

	