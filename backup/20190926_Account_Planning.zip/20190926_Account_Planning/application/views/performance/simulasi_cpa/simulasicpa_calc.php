<div class="right_col" role="main">
    <div class="container">
    	
		<h2>Result CPA</h2>
        	<?php $this->load->view('performance/simulasi_cpa/modal_calculate.php'); ?>
    </div>
    
</div>