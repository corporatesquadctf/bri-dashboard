<?php
    class ProsesKredit extends MY_Controller {
        function __construct() {
            parent::__construct();
            $user = $this->session->all_userdata();
            if(!$user =$this->session->userdata('USER_ID'))
            {
                redirect('logins');
            }else{
                $this->load->helper(array(
                    'form',
                    'url',
                    'security'
                ));
                $this->load->library(array(
                    'session',
                    'form_validation',
                    'pagination'
                ));
                $this->load->model('ProsesKredit_model');
                $this->load->model('Pipeline_model');            
            }
        }

        public function index() {
            $this->checkModule();
            $user = $this->session->all_userdata();
            $data['user'] = $user;
            $userId = $user['USER_ID'];
            $roleId = $user['ROLE_ID'];

            $rsUsulanPlafond = array();
            $data1 = array('id' => 1, 'name' => 'Kurang dari 50M');
            $rsUsulanPlafond[] = (object)$data1;
            $data2 = array('id' => 2, 'name' => '50M atau lebih');
            $rsUsulanPlafond[] = (object)$data2;
            $data['rsUsulanPlafond'] = $rsUsulanPlafond;
            
            if($this->input->post()){
                switch($user['ROLE_ID']){
                    case 12:
                        $createdBy = $userId;
                        $usulanPlafond = 0;
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                    case 14:
                        $createdBy = $this->input->post('rm_id');
                        $usulanPlafond = $this->input->post('usulanPlafond');
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                    case 16:
                        $createdBy = $this->input->post('rm_id');
                        $usulanPlafond = 0;
                        $divisionId = $this->input->post('ukerId');
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah();
                        $rsRM = $this->Pipeline_model->getUserByRole(12,$divisionId);
                        break;
                    case 17:
                        $createdBy = $this->input->post('rm_id');
                        $usulanPlafond = 0;
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                    case 18:
                        $createdBy = $this->input->post('rm_id');
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                }
                $data['rsUker'] = $rsUker;
                $data['rsRM'] = $rsRM;

                $data['uker_id'] = $this->input->post('ukerId');
                $data['rm_id'] = $this->input->post('rm_id');
                $data['usulanPlafond'] = $this->input->post('usulanPlafond');
                $data['keyword'] = $this->input->post('keyword');
            }else{
                switch($user['ROLE_ID']){
                    case 12:
                        $createdBy = $userId;
                        $usulanPlafond = 0;
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                    case 14:
                        $createdBy = 0;
                        $usulanPlafond = 0;
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                    case 16:
                        $createdBy = 0;
                        $usulanPlafond = 0;
                        $divisionId = 0;
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah();
                        $rsRM = $this->Pipeline_model->getUserByRole(12);
                        break;
                    case 17:
                        $createdBy = 0;
                        $usulanPlafond = 0;
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                    case 18:
                        $createdBy = 0;
                        $usulanPlafond = 0;
                        $divisionId = $user['DIVISION'];
                        $rsUker = $this->Pipeline_model->getUnitKerjaMenengah($divisionId);
                        $rsRM = $this->Pipeline_model->getUserByRole(12, $divisionId);
                        break;
                }
                $data['rsUker'] = $rsUker;
                $data['rsRM'] = $rsRM;

                $data['uker_id'] = 0;
                $data['rm_id'] = 0;
                $data['usulanPlafond'] = 0;
                $data['keyword'] = '';                
                
            }

            $filter = array(
                'Keyword' => $data['keyword'],
                'UsulanPlafond' => $usulanPlafond,
                'DivisionId' => $divisionId,
                'CreatedBy' => $createdBy
            );

            $rsProsesKredit = $this->ProsesKredit_model->getProsesKredit($filter);
            $data['prosesKredit'] = $rsProsesKredit; 

            //echo json_encode($data); die;

            $this->load->view('layout/header.php');
            $this->load->view('layout/side-nav.php');
            $this->load->view('layout/top-nav.php');
            $this->load->view('monitoring/proses_kredit/ProsesKredit.php', $data);
            $this->load->view('layout/footer.php');        
        }

        public function detail(){
            $this->checkModule();
            $user = $this->session->all_userdata();
            $data['user'] = $user;

            $role = $user['ROLE_ID'];
            switch($role){
                case 12:
                    $arrTujuanDiteruskan = array(17,18);
                    $rsTujuanDiteruskan = $this->ProsesKredit_model->getTujuanProsesKreditOption($arrTujuanDiteruskan);
                    //echo json_encode($rsTujuanDiteruskan); die;

                    $rsTujuanDikembalikan = array();
                    //echo json_encode($rsTujuanDikembalikan); die;
                    break;
                case 14:
                    $arrTujuanDiteruskan = array(17);
                    $rsTujuanDiteruskan = $this->ProsesKredit_model->getTujuanProsesKreditOption($arrTujuanDiteruskan);
                    //echo json_encode($rsTujuanDiteruskan); die;

                    $arrTujuanDikembalikan = array(17);
                    $rsTujuanDikembalikan = $this->ProsesKredit_model->getTujuanProsesKreditOption($arrTujuanDikembalikan);                  
                    break;
                case 16:
                    $rsTujuanDiteruskan = array();
                    $rsTujuanDikembalikan = array();
                    break;
                case 17:
                    $arrTujuanDiteruskan = array(14,18);
                    $rsTujuanDiteruskan = $this->ProsesKredit_model->getTujuanProsesKreditOption($arrTujuanDiteruskan);
                    //echo json_encode($rsTujuanDiteruskan); die;
                    
                    $arrTujuanDikembalikan = array(12, 18);
                    $rsTujuanDikembalikan = $this->ProsesKredit_model->getTujuanProsesKreditOption($arrTujuanDikembalikan);                  
                    break;
                case 18:
                    $arrTujuanDiteruskan = array(17);
                    $rsTujuanDiteruskan = $this->ProsesKredit_model->getTujuanProsesKreditOption($arrTujuanDiteruskan);
                    //echo json_encode($rsTujuanDiteruskan); die;
                    
                    $arrTujuanDikembalikan = array(12,17);
                    $rsTujuanDikembalikan = $this->ProsesKredit_model->getTujuanProsesKreditOption($arrTujuanDikembalikan);                  
                    break;
                default:
                    break;
            }
            $data['tujuanDiteruskanOption'] = $rsTujuanDiteruskan;
            $data['tujuanDikembalikanOption'] = $rsTujuanDikembalikan;

            $prosesKreditId = $this->uri->segment(4);
            $rsProsesKredit = $this->ProsesKredit_model->getDetailProsesKredit($prosesKreditId);
            $data['prosesKredit'] = $rsProsesKredit;
            //echo json_encode($rsProsesKredit); die;

            $rsHistoryProsesKreditRM = $this->ProsesKredit_model->getHistoryProsesKredit($prosesKreditId, 12);
            $data['historyProsesKreditRM'] = $rsHistoryProsesKreditRM;
            //echo json_encode($rsHistoryProsesKreditRM); die;

            //$rsADK = $this->ProsesKredit_model->getUserInformation(17, $rsProsesKredit->DivisionId);
            $rsHistoryProsesKreditADK = $this->ProsesKredit_model->getHistoryProsesKredit($prosesKreditId, 17);
            //$data['adk'] = $rsADK;
            $data['historyProsesKreditADK'] = $rsHistoryProsesKreditADK;

            //$rsARK = $this->ProsesKredit_model->getUserInformation(18, $rsProsesKredit->DivisionId);
            $rsHistoryProsesKreditARK = $this->ProsesKredit_model->getHistoryProsesKredit($prosesKreditId, 18);
            //$data['ark'] = $rsARK;
            $data['historyProsesKreditARK'] = $rsHistoryProsesKreditARK;

            //$rsKomite = $this->ProsesKredit_model->getUserInformation(14, $rsProsesKredit->DivisionId);
            $rsHistoryProsesKreditKomite = $this->ProsesKredit_model->getHistoryProsesKredit($prosesKreditId, 14);
            //$data['komite'] = $rsKomite;
            $data['historyProsesKreditKomite'] = $rsHistoryProsesKreditKomite;

            $rsHistoryProsesKreditKadiv = $this->ProsesKredit_model->getHistoryProsesKredit($prosesKreditId, 16);
            $data['historyProsesKreditKadiv'] = $rsHistoryProsesKreditKadiv;

            //echo json_encode($rsHistoryProsesKreditKomite); die;

            $historyProsesKredit = $this->ProsesKredit_model->getHistoryProsesKredit($prosesKreditId);
            
            $pipelineId = $rsProsesKredit->PipelineId;
            $rsPipeline = $this->Pipeline_model->getDetailPipeline($pipelineId);
            $data['pipeline'] = $rsPipeline;

            $this->load->view('layout/header.php');
            $this->load->view('layout/side-nav.php');
            $this->load->view('layout/top-nav.php');
            $this->load->view('monitoring/proses_kredit/DetailProsesKredit.php', $data);
            $this->load->view('layout/footer.php');
        }

        public function teruskan_proses_kredit(){
            $user = $this->session->all_userdata();
            $userId = $user['USER_ID'];
            $divisionId = $user['DIVISION'];
            $roleId = $user['ROLE_ID'];
            $prosesKreditId = $this->input->post('prosesKreditId');
            $isApproved = 1;
            $tujuanDiteruskanId = $this->input->post('tujuanDiteruskanId');
            $comment = $this->input->post('comment');
            // Putusan Hasil Komite
            if($roleId == 14){
                $putusanId = $this->input->post('putusanId');
            }else $putusanId = NULL;
            $data = array(
                'prosesKreditId' => $prosesKreditId,
                'isApproved' => $isApproved,
                'tujuanId' => $tujuanDiteruskanId,
                'comment' => $comment,
                'putusanId' => $putusanId,
                'userId' => $userId,
                'roleId' => $roleId,
                'divisionId' => $divisionId
            );
            //echo json_encode($data); die;
            $flashmsg = '<br>Paket berhasil dikirim';
            if($this->ProsesKredit_model->updateStatusProsesKredit($data)){
                $this->session->set_flashdata('Success', $flashmsg);
                redirect('monitoring/proseskredit');
            }
        }

        public function akad_kredit(){
            $user = $this->session->all_userdata();
            $userId = $user['USER_ID'];
            $divisionId = $user['DIVISION'];
            $roleId = $user['ROLE_ID'];
            $prosesKreditId = $this->input->post('prosesKreditId');
            $tanggalAkad = date('Y-m-d', strtotime(str_replace('/','-', $this->input->post('tanggalAkad'))));
            $notarisName = $this->input->post('notarisName');
            $desc = $this->input->post('desc');

            $data = array(
                'prosesKreditId' => $prosesKreditId,
                'tanggalAkad' => $tanggalAkad,
                'notarisName' => $notarisName,
                'desc' => $desc,
                'userId' => $userId,
                'roleId' => $roleId,
                'divisionId' => $divisionId
            );
            
            //echo json_encode($data); die;
            $this->ProsesKredit_model->prosesAkadKredit($data);
            redirect('monitoring/proseskredit');

            /*
            $flashmsg = '<br>Paket berhasil diteruskan';
            if($this->ProsesKredit_model->updateStatusProsesKredit($data)){
                $this->session->set_flashdata('Success', $flashmsg);
                redirect('monitoring/proseskredit');
            }
            */
        }
    
        public function kembalikan_proses_kredit(){
            $user = $this->session->all_userdata();
            $userId = $user['USER_ID'];
            $divisionId = $user['DIVISION'];
            $roleId = $user['ROLE_ID'];
            $prosesKreditId = $this->input->post('prosesKreditId');
            $isApproved = 0;
            $tujuanDikembalikanId = $this->input->post('tujuanDikembalikanId');
            $comment = $this->input->post('comment');
            $data = array(
                'prosesKreditId' => $prosesKreditId,
                'isApproved' => $isApproved,
                'tujuanId' => $tujuanDikembalikanId,
                'comment' => $comment,
                'userId' => $userId,
                'roleId' => $roleId,
                'divisionId' => $divisionId
            );
            
            $flashmsg = '<br>Paket berhasil dikembalikan';
            if($this->ProsesKredit_model->updateStatusProsesKredit($data)){
                $this->session->set_flashdata('Success', $flashmsg);
                redirect('monitoring/proseskredit');
            }
        }

        public function multiple_comment(){
            $user = $this->session->all_userdata();
            $userId = $user['USER_ID'];
            $arrProsesKreditId = $this->input->post('id');
            if($this->input->post('comment') != NULL){
                $comment = $this->input->post('comment');
            }else $comment = NULL;
            $data = array(
                'arrProsesKreditId' => $arrProsesKreditId,
                'comment' => $comment,
                'userId' => $userId
            );
            $flashmsg = '<br>Comment has been successfully added!';
            if($this->ProsesKredit_model->multipleCommentProsesKredit($data)){
                $this->session->set_flashdata('Success', $flashmsg);
                redirect('monitoring/proseskredit');
            }
        }
        
    }    
?>