<?php 

class AccountPlanning extends MY_Controller {

  function __construct() {
      parent::__construct();
      $this->load->helper(array(
          'form',
          'url',
          'security'
      ));
      $this->load->library(array(
          'session',
          'form_validation',
          'pagination'
      ));
      $this->load->model('PerformanceAccountPlanning_model');

      $current_datetime = new DateTime(date('Y-m-d H:i:s'));
      $this->current_year = $current_datetime->format('Y');
      $this->current_date = $current_datetime->format('Y-m-d');
      $this->current_datetime = $current_datetime->format('Y-m-d H:i:s');
  }

  public function index($rowno=0) {
    $this->checkModule();

    $data = array();
    $limit_per_page = 5;
    $start_index = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

    $total_records = $this->PerformanceAccountPlanning_model->getTotalViewPerformanceAccountPlanning('', '', $this->current_year, '');
    if ($total_records > 0) {   
      $ap_performance = $this->PerformanceAccountPlanning_model->getViewPerformanceAccountPlanning($limit_per_page, $rowno, '', '', $this->current_year, '');

      foreach ($ap_performance as $ap_row) {
        $AccountPlanningId = $ap_row['AccountPlanningId'];
        $account_planning_status = $this->PerformanceAccountPlanning_model->getDocumentStatus($AccountPlanningId);
        $account_planning_vcif_list = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);
        $params['results'][$AccountPlanningId] = array(
          'AccountPlanningId'               => $AccountPlanningId,
          'Currency'                        => $ap_row['Currency'],
          'CreatedDate'                     => $ap_row['CreatedDate'],
          'Year'                            => $ap_row['Year'],
          'CustomerGroupId'                 => $ap_row['CustomerGroupId'],
          'CustomerName'                    => $ap_row['CustomerName'],
          'CustomerGroupName'               => $ap_row['CustomerGroupName'],
          'RMName'                          => $ap_row['RMName'],
          'Status'                          => $account_planning_status['Status'],
          'PinjamanTotalGroup'              => number_format($ap_row['PinjamanTotalGroup']),
          'PinjamanRatasGroup'              => number_format($ap_row['PinjamanRatasGroup']),
          'SimpananTotalGroup'              => number_format($ap_row['SimpananTotalGroup']),
          'SimpananRatasGroup'              => number_format($ap_row['SimpananRatasGroup']),
          'CurrentCPAGroup'                 => number_format($ap_row['CurrentCPAGroup']),
          'ValueChainGroup'                 => number_format($ap_row['ValueChainGroup']),
          'PinjamanTotalAP'                 => number_format($ap_row['PinjamanTotalAP']),
          'PinjamanRatasAP'                 => number_format($ap_row['PinjamanRatasAP']),
          'SimpananTotalAP'                 => number_format($ap_row['SimpananTotalAP']),
          'SimpananRatasAP'                 => number_format($ap_row['SimpananRatasAP']),
          'CurrentCPAAP'                    => number_format($ap_row['CurrentCPAAP']),
          'ValueChainAP'                    => number_format($ap_row['ValueChainAP']),
          'account_planning_vcif_list'      => $account_planning_vcif_list
        );
      }
      $params['row'] = $rowno;

      $config['base_url'] = base_url() . 'performance/AccountPlanning/page';
      $config['use_page_numbers'] = TRUE;
      $config['total_rows'] = $total_records;
      $config['per_page'] = $limit_per_page;
      $config["uri_segment"] = 3;
      $config['full_tag_open'] = '<ul class="pagination">';
      $config['full_tag_close'] = '</ul>';
      $config['num_tag_open'] = '<li class="page-item">';
      $config['num_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
      $config['cur_tag_close'] = '</a></li>';
      $config['next_tag_open'] = '<li class="page-item">';
      $config['next_tagl_close'] = '</a></li>';
      $config['prev_tag_open'] = '<li class="page-item">';
      $config['prev_tagl_close'] = '</li>';
      $config['first_tag_open'] = '<li class="page-item ">';
      $config['first_tagl_close'] = '</li>';
      $config['last_tag_open'] = '<li class="page-item">';
      $config['last_tagl_close'] = '</a></li>';
      $config['attributes'] = array('class' => 'page-link');

      $this->pagination->initialize($config);

      $params["links"] = $this->pagination->create_links();
    }
    // echo "<pre>";
    // print_r($params['results']); die();

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('performance/performance_account_planning.php', $params);
    $this->load->view('layout/footer.php');
  }

  public function page($rowno=0) {
    $this->checkModule();

    $data = array();
    $limit_per_page = 5;
    if($rowno != 0){
      $rowno = ($rowno-1) * $limit_per_page;
    }
    $start_index = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;

    $total_records = $this->PerformanceAccountPlanning_model->getTotalViewPerformanceAccountPlanning('', '', $this->current_year, '');
    if ($total_records > 0) {   
      $ap_performance = $this->PerformanceAccountPlanning_model->getViewPerformanceAccountPlanning($limit_per_page, $rowno, '', '', $this->current_year, '');

      foreach ($ap_performance as $ap_row) {
        $AccountPlanningId = $ap_row['AccountPlanningId'];
        $account_planning_status = $this->PerformanceAccountPlanning_model->getDocumentStatus($AccountPlanningId);
        $account_planning_member_list = $this->PerformanceAccountPlanning_model->getAccountPlanningMember($AccountPlanningId);
        $account_planning_vcif_list = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);
        $params['results'][$AccountPlanningId] = array(
          'AccountPlanningId'               => $AccountPlanningId,
          'Currency'                        => $ap_row['Currency'],
          'CreatedDate'                     => $ap_row['CreatedDate'],
          'Year'                            => $ap_row['Year'],
          'CustomerGroupId'                 => $ap_row['CustomerGroupId'],
          'CustomerName'                    => $ap_row['CustomerName'],
          'CustomerGroupName'               => $ap_row['CustomerGroupName'],
          'RMName'                          => $ap_row['RMName'],
          'Status'                          => $account_planning_status['Status'],
          'PinjamanTotalGroup'              => number_format($ap_row['PinjamanTotalGroup']),
          'PinjamanRatasGroup'              => number_format($ap_row['PinjamanRatasGroup']),
          'SimpananTotalGroup'              => number_format($ap_row['SimpananTotalGroup']),
          'SimpananRatasGroup'              => number_format($ap_row['SimpananRatasGroup']),
          'CurrentCPAGroup'                 => number_format($ap_row['CurrentCPAGroup']),
          'ValueChainGroup'                 => number_format($ap_row['ValueChainGroup']),
          'PinjamanTotalAP'                 => number_format($ap_row['PinjamanTotalAP']),
          'PinjamanRatasAP'                 => number_format($ap_row['PinjamanRatasAP']),
          'SimpananTotalAP'                 => number_format($ap_row['SimpananTotalAP']),
          'SimpananRatasAP'                 => number_format($ap_row['SimpananRatasAP']),
          'CurrentCPAAP'                    => number_format($ap_row['CurrentCPAAP']),
          'ValueChainAP'                    => number_format($ap_row['ValueChainAP']),
          'account_planning_member_list'    => $account_planning_member_list,
          'account_planning_vcif_list'      => $account_planning_vcif_list
        );
      }
      $params['row'] = $rowno;

      $config['base_url'] = base_url() . 'performance/AccountPlanning/page';
      $config['use_page_numbers'] = TRUE;
      $config['total_rows'] = $total_records;
      $config['per_page'] = $limit_per_page;
      $config["uri_segment"] = 4;
      $config['full_tag_open'] = '<ul class="pagination">';
      $config['full_tag_close'] = '</ul>';
      $config['num_tag_open'] = '<li class="page-item">';
      $config['num_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
      $config['cur_tag_close'] = '</a></li>';
      $config['next_tag_open'] = '<li class="page-item">';
      $config['next_tagl_close'] = '</a></li>';
      $config['prev_tag_open'] = '<li class="page-item">';
      $config['prev_tagl_close'] = '</li>';
      $config['first_tag_open'] = '<li class="page-item ">';
      $config['first_tagl_close'] = '</li>';
      $config['last_tag_open'] = '<li class="page-item">';
      $config['last_tagl_close'] = '</a></li>';
      $config['attributes'] = array('class' => 'page-link');

      $this->pagination->initialize($config);

      $params["links"] = $this->pagination->create_links();
    }

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('performance/performance_account_planning.php', $params);
    $this->load->view('layout/footer.php');
  }

  public function detail($AccountPlanningId) {
    $this->checkModule();
    $data['account_planning'] = $this->PerformanceAccountPlanning_model->getDetailPerformanceAccountPlanning($AccountPlanningId);
    $data['account_planning']['Clasifications'] = 'Gold';

    // Company Information
    $data['account_planning']['GroupOverview'] = $this->PerformanceAccountPlanning_model->getAccountPlanningGroupOverview($AccountPlanningId);

    $data['account_planning']['StrategicPlan']['1'] = $this->PerformanceAccountPlanning_model->getAccountPlanningStrategicPlan($AccountPlanningId, 1);
    $data['account_planning']['StrategicPlan']['2'] = $this->PerformanceAccountPlanning_model->getAccountPlanningStrategicPlan($AccountPlanningId, 2);

    $data['account_planning']['FileStructure']['1'] = $this->PerformanceAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1);
    $data['account_planning']['FileStructure']['2'] = $this->PerformanceAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 2);
    $data['account_planning']['FileStructure']['3'] = $this->PerformanceAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3);

    $data['account_planning']['MemberCST'] = $this->PerformanceAccountPlanning_model->getAccountPlanningMember($AccountPlanningId);
    $data['account_planning']['CoverageMapping'] = $this->PerformanceAccountPlanning_model->getAccountPlanningCoverageMapping($AccountPlanningId);

    $dataShareholder = $this->PerformanceAccountPlanning_model->getAccountPlanningShareholder($AccountPlanningId);
    $data['account_planning']['Shareholder'] = $dataShareholder;
    foreach ($dataShareholder as $key => $value) {
      $data['account_planning']['Shareholder2']['labels'][] = $value['Name'];
      //$data['account_planning']['Shareholder2']['portion'][] = $value['Portion'];
      $data['account_planning']['Shareholder2']['values'][] = $value['Value'];
    }

    // Client Needs
    $data['account_planning']['Funding'] = $this->PerformanceAccountPlanning_model->getAccountPlanningFunding($AccountPlanningId);
    $dataService = $this->PerformanceAccountPlanning_model->getAccountPlanningService($AccountPlanningId);
    foreach ($dataService as $key => $value) {
      $TagServiceUnitKerja = $this->PerformanceAccountPlanning_model->getAccountPlanningServiceTag($value['ServiceId']);
      $data['account_planning']['Service'][] = array(
          'ServiceId'               => $value['ServiceId'],
          'ServiceName'             => $value['ServiceName'],
          'TagServiceUnitKerja'     => $TagServiceUnitKerja
          );
    }

    $dataBankFacilityItem = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItem();
    foreach ($dataBankFacilityItem as $key => $value) {
      $heading_panel = ' collapse';
      if ($value['BankFacilityGroupId'] == 1) {
        $heading_panel = '';
      }
      $tab_panel = ' collapse';
      if ($value['BankFacilityGroupId'] == 1) {
        $tab_panel = ' collapse in';
      }
      $expanded_panel = 'false';
      if ($value['BankFacilityGroupId'] == 1) {
        $expanded_panel = 'true';
      }
     
    // Estimated Financial
      $dataEstimatedFinancial[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningEstimatedFinancial($AccountPlanningId, $value['BankFacilityItemId']);

      $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$value['BankFacilityItemId']] = array(
        'EstimatedFinancialId'        => 0
        , 'BankFacilityItemName'      => $value['BankFacilityItemName']
        , 'LabelsName_idr'            => "direct_loan_idr".$value['BankFacilityItemId']
        , 'IDR'                       => "IDR"
        , 'labels_idr'                => Array(  
                                              "Projection Cost",
                                              "BRI's Target"
                                      )
        , 'LabelsName_valas'          => "direct_loan_valas".$value['BankFacilityItemId']
        , 'Valas'                     => "Valas"
        , 'labels_valas'              => Array(  
                                              "Projection Cost",
                                              "BRI's Target"
                                      )
        , 'IDRProjection'             => 0
        , 'IDRTarget'                 => 0
        , 'values_idr'                => Array(0, 0)
        , 'ValasProjection'           => 0
        , 'ValasTarget'               => 0
        , 'values_valas'              => Array(0, 0)
        );

      if (isset($dataEstimatedFinancial[$value['BankFacilityGroupId']][0])) {
        foreach ($dataEstimatedFinancial[$value['BankFacilityGroupId']] as $keys => $values) {
          $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$value['BankFacilityItemId']] = array(
            'EstimatedFinancialId'          => $values['EstimatedFinancialId']
            , 'BankFacilityItemName'        => $value['BankFacilityItemName']
            , 'LabelsName_idr'              => "direct_loan_idr".$value['BankFacilityItemId']
            , 'IDR'                         => "IDR"
            , 'labels_idr'                  => Array(  
                                                  "Projection Cost",
                                                  "BRI's Target"
                                          )
            , 'LabelsName_valas'            => "direct_loan_valas".$value['BankFacilityItemId']
            , 'Valas'                       => "Valas"
            , 'labels_valas'                => Array(  
                                                  "Projection Cost",
                                                  "BRI's Target"
                                          )
            , 'IDRProjection'               => number_format($dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['IDRProjection']/1000000)
            , 'IDRTarget'                   => number_format($dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['IDRTarget']/1000000)
            , 'values_idr'                  => Array(
                                                $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['IDRProjection']/1000000,
                                                $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['IDRTarget']/1000000
                                        )
            , 'ValasProjection'             => number_format($dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['ValasProjection']/1000000)
            , 'ValasTarget'                 => number_format($dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['ValasTarget']/1000000)
            , 'values_valas'                => Array(
                                                $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['ValasProjection']/1000000,
                                                $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['ValasTarget']/1000000
                                        )
            );
        }
      }

    // Wallet Share
      $dataWalletShare[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningWalletShare($AccountPlanningId, $value['BankFacilityItemId']);

      $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShare_details'][$value['BankFacilityItemId']] = array(
        'WalletShareId'           => 0
        , 'BankFacilityItemName'  => $value['BankFacilityItemName']
        , 'BRINominal'            => 0
        , 'BRIPortion'            => 0
        , 'OtherNominal'          => 0
        , 'OtherPortion'          => 0
        , 'TotalAmount'           => 0
        );

      if (is_array($dataWalletShare[$value['BankFacilityGroupId']])) {
        foreach ($dataWalletShare[$value['BankFacilityGroupId']] as $keys => $values) {
          $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShare_details'][$value['BankFacilityItemId']] = array(
            'WalletShareId'           => $values['WalletShareId']
            , 'BankFacilityItemName'  => $value['BankFacilityItemName']
            , 'BRINominal'            => number_format($values['BRINominal']/1000000)
            , 'BRIPortion'            => $values['BRIPortion']
            , 'OtherNominal'          => number_format($values['OtherNominal']/1000000)
            , 'OtherPortion'          => $values['OtherPortion']
            , 'TotalAmount'           => number_format($values['TotalAmount']/1000000)
            );
        }
      }

    // competitionAnalys
      $dataCompetitionAnalysis[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountCompetitions($AccountPlanningId, $value['BankFacilityItemId']);
      $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']]['CompetitionAnalysis_detail'][$value['BankFacilityItemId']] = array(
        'CompetitionAnalysisId'        => 0
        , 'BankFacilityItemName'      => $value['BankFacilityItemName']
        , 'BankName1'                 => ''
        , 'BankName2'                 => ''
        , 'BankName3'                 => ''
        );
        
      if (is_array($dataCompetitionAnalysis[$value['BankFacilityGroupId']])) {
          
        foreach ($dataCompetitionAnalysis as $keys => $values) {
          $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']]['CompetitionAnalysis_detail'][$value['BankFacilityItemId']] = array(
            'CompetitionAnalysisId'       => $values['CompetitionAnalysisId']
            , 'BankFacilityItemName'      => $value['BankFacilityItemName']
            , 'BankName1'                 => $values['BankName1']
            , 'BankName2'                 => $values['BankName2']
            , 'BankName3'                 => $values['BankName3']
            );
        }
      }

    // Facilities Banking
      $dataBankFacility[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacility($AccountPlanningId, $value['BankFacilityItemId']);

      $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$value['BankFacilityItemId']] = array(
        'BankFacilityId'          => 0
        , 'BankFacilityItemName'  => $value['BankFacilityItemName']
        , 'IDRNominal'            => 0
        , 'IDRRate'               => 0
        , 'ValasNominal'          => 0
        , 'ValasRate'             => 0
        );

      if (is_array($dataBankFacility[$value['BankFacilityGroupId']])) {
        foreach ($dataBankFacility[$value['BankFacilityGroupId']] as $keys => $values) {
          $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$value['BankFacilityItemId']] = array(
            'BankFacilityId'          => $values['BankFacilityId']
            , 'BankFacilityItemName'  => $values['BankFacilityItemName']
            , 'IDRNominal'            => number_format($values['IDRNominal']/1000000)
            , 'IDRRate'               => $values['IDRRate']
            , 'ValasNominal'          => number_format($values['ValasNominal']/1000000)
            , 'ValasRate'             => $values['ValasRate']
            );
          }
        }
    }

    // Initiative Action
    $data['account_planning']['InitiativeAction'] = $this->PerformanceAccountPlanning_model->getAccountPlanningInitiativeAction($AccountPlanningId);

    $data['account_planning']['KursUSD'] = $this->getKursUSD();
    $data['account_planning']['Years'] = Array(  
                                                date('Y') - 3,
                                                date('Y') - 2,
                                                date('Y') - 1
                                        );

    $data['account_planning']['backgroundColors'] = Array(
            // "",
            "#EBD618", 
            "#46CEB6", 
            "#9522F0", 
            "#1998DF", 
            "#F86D43", 
            "#FF62EF", 
            "#455C73", 
            "#9B59B6", 
            "#BDC3C7", 
            "#26B99A", 
            "#3498DB"
      );
    $data['account_planning']['hoverBackgroundColors'] = Array(
            // "",
            "#f3e672", 
            "#86dfcf", 
            "#b970f5", 
            "#75c3f0", 
            "#fa8d6b", 
            "#ff99f5", 
            "#34495E", 
            "#B370CF", 
            "#CFD4D8", 
            "#36CAAB", 
            "#49A9EA"
      );

    // FinancialHighlight
    $FinancialHighlightItem = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlightItem();
    foreach ($FinancialHighlightItem as $key => $value) {
      $heading_panel = ' collapse';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $heading_panel = '';
      }
      $tab_panel = ' collapse';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $tab_panel = ' collapse in';
      }
      $expanded_panel = 'false';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $expanded_panel = 'true';
      }

      $dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlight($AccountPlanningId, $value['FinancialHighlightItemId']);

      $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']][0] = array(
        'FinancialHighlightGroupId'       => $value['FinancialHighlightGroupId']
        , 'FinancialHighlightGroupName'   => $value['FinancialHighlightGroupName']
        , 'heading_panel'                 => $heading_panel
        , 'tab_panel'                     => $tab_panel
        , 'expanded_panel'                => $expanded_panel
        );

      foreach ($data['account_planning']['Years'] as $keyss => $valuess) {
        if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
          $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][$valuess] = array(
              'FinancialHighlightId'            => 0
              , 'Amount'                        => 0
              , 'ChartAmount'                   => 0
              , 'Year'                          => $valuess
            );
        }
        else {
          $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$valuess] = array(
              'FinancialHighlightId'            => 0
              , 'Amount'                        => 0
              , 'ChartAmount'                   => 0
              , 'Year'                          => $valuess
            );
        }
      }
      if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {

        $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][0] = array(
            'FinancialHighlightItemId'              => 0
            , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
          );
      }
      else {

        $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
            'FinancialHighlightItemId'              => 0
            , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
          );
      }

      if ($value['FinancialHighlightGroupId'] == 3 || $value['FinancialHighlightGroupId'] == 4 || $value['FinancialHighlightGroupId'] == 5 || $value['FinancialHighlightGroupId'] == 6) {
        if (is_array($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']])) {
          foreach ($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] as $keysss => $values) {
              if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][0] = array(
                  'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
                  , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
                  );
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][$values['Year']] = array(
                  'FinancialHighlightId'            => $values['FinancialHighlightId']
                  , 'Amount'                        => number_format($values['Amount']/1000000)
                  , 'ChartAmount'                   => $values['Amount']
                  , 'Year'                          => $values['Year']
                  );
              }
              else {
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
                  'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
                  , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
                  );
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$values['Year']] = array(
                  'FinancialHighlightId'            => $values['FinancialHighlightId']
                  , 'Amount'                        => $values['Amount']
                  , 'ChartAmount'                   => $values['Amount']
                  , 'Year'                          => $values['Year']
                  );
            }
          }
        }        
      }
      else {
        if (is_array($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']])) {
          foreach ($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] as $keysss => $values) {
            $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
              'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
              , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
              );
            $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$values['Year']] = array(
              'FinancialHighlightId'            => $values['FinancialHighlightId']
              , 'Amount'                        => number_format($values['Amount']/1000000)
              , 'ChartAmount'                   => $values['Amount']/1000000
              , 'Year'                          => $values['Year']
              );
          }
        }        
      }
    }

    // echo "<pre>";
    // // print_r($backgroundColor); die();
    // print_r($data['account_planning']['FinancialHighlight']); die();
    //echo json_encode($data); die;

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('performance/performance_detail_account_planning.php', $data);
    $this->load->view('layout/footer.php');
  }

  public function getKursUSD() {
    $url = "http://kurs.web.id/api/v1/bri";
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
    curl_setopt($ch, CURLOPT_HEADER, TRUE); 
    curl_setopt($ch, CURLOPT_NOBODY, TRUE); // remove body 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 

    $head = curl_exec($ch); 
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); 

    curl_error($ch);
    curl_close($ch); 


  }


}

?>
