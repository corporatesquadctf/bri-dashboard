<?php 

class AccountPlanning extends MY_Controller {

  function __construct() {
      parent::__construct();
      $this->load->helper(array(
          'form',
          'url',
          'security'
      ));
      $this->load->library(array(
          'session',
          'form_validation',
          'pagination'
      ));
      $this->load->model('TasklistDisposisi_model');
      $this->load->model('TasklistAccountPlanning_model');
      $this->load->model('PerformanceAccountPlanning_model');
      $this->load->model('MonitoringAccountPlanning_model');
      $this->load->model('DataTransaction_model');

      $current_datetime = new DateTime(date('Y-m-d H:i:s'));
      $this->current_year = $current_datetime->format('Y');
      $this->current_date = $current_datetime->format('Y-m-d');
      $this->current_datetime = $current_datetime->format('Y-m-d H:i:s');
  }

  public function index($rowno=0) {
    $this->checkModule();

    $params = array();
    $limit_per_page = 5;
    $start_index = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

    $pinjamanLastUpdateDate = $this->DataTransaction_model->getPinjamanLastUpdateDate();
    $params['pinjamanLastUpdateDate'] = $pinjamanLastUpdateDate['LastUpdateDate'];
    $simpananLastUpdateDate = $this->DataTransaction_model->getSimpananLastUpdateDate();
    $params['simpananLastUpdateDate'] = $simpananLastUpdateDate['LastUpdateDate'];
    $cpaLastUpdateDate = $this->DataTransaction_model->getCpaLastUpdateDate();
    $params['cpaLastUpdateDate'] = $cpaLastUpdateDate['LastUpdateDate'];

    $doc_statuses = $this->MonitoringAccountPlanning_model->get_doc_status();
    $status_search_box['all'] = '--- All ---';
    foreach ($doc_statuses as $doc_status) {
      $status_search_box[$doc_status['DocumentStatusId']] = $doc_status['Name'];
    }
    $params['status_search_box'] = form_dropdown('status_search_box', $status_search_box, '', ' class="form-control col-md-7 col-xs-12" style="width: 50%; min-width:200px"');
    
    $search_year = array('all' => '--- All ---'
                        , $this->current_year-2 => $this->current_year-2
                        , $this->current_year-1 => $this->current_year-1
                        , $this->current_year => $this->current_year);
    $params['tahun_search_box'] = form_dropdown('tahun_search_box', $search_year, $this->current_year, ' class="form-control col-md-7 col-xs-12" style="width: 25%;min-width: 80px"');
    $params['keyword_search_box'] = '';
    $total_records = $this->TasklistAccountPlanning_model->getTotalMyAccountPlanning($this->session->PERSONAL_NUMBER, $this->current_year);
    //$params['keyword_search_box'] = $keyword_search;
    if ($total_records > 0) {   
      // $ap_Tasklist = $this->TasklistAccountPlanning_model->getViewTasklistAccountPlanning($this->session->PERSONAL_NUMBER, $limit_per_page, $rowno, '', '', $this->current_year, '');

      $ap_Tasklist = $this->TasklistAccountPlanning_model->getMyAccountPlanning($this->session->PERSONAL_NUMBER, $limit_per_page, $rowno, $this->current_year);

      foreach ($ap_Tasklist as $ap_row) {
        $CustomerGroupId = $ap_row['CustomerGroupId'];
        $AccountPlanningId = $ap_row['AccountPlanningId'];

        $account_planning_status = $this->PerformanceAccountPlanning_model->getDocumentStatus($AccountPlanningId);
        $account_planning_member = $this->TasklistDisposisi_model->getAccountPlanningMember($AccountPlanningId);
        $rm_selected = $this->TasklistDisposisi_model->getRMSelected($this->session->DIVISION, $CustomerGroupId);
        $account_planning_vcif_list = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);

        $pinjamanGroup = $this->DataTransaction_model->getDataPinjamanGroup($CustomerGroupId);
        $simpananGroup = $this->DataTransaction_model->getDataSimpananGroup($CustomerGroupId);
        $cpaGroup = $this->DataTransaction_model->getDataCpaGroup($CustomerGroupId);

        $pinjamanAp = $this->DataTransaction_model->getDataPinjamanAccountPlanning($AccountPlanningId);
        $simpananAp = $this->DataTransaction_model->getDataSimpananAccountPlanning($AccountPlanningId);
        $cpaAp = $this->DataTransaction_model->getDataCpaAccountPlanning($AccountPlanningId);

        $ap_year_color = '#218FD8';
        if ($ap_row['Year'] != $this->current_year) {
          $ap_year_color = '#F58C38';
        }

        $params['results'][$AccountPlanningId] = array(
          'AccountPlanningId'               => $AccountPlanningId,
          //'Currency'                        => $ap_row['Currency'],
          'CreatedDate'                     => $ap_row['CreatedDate'],
          'Year'                            => $ap_row['Year'],
          'ap_year_color'                   => $ap_year_color,
          'CustomerGroupId'                 => $CustomerGroupId,
          'CustomerName'                    => $ap_row['CustomerName'],
          'Logo'                            => $ap_row['Logo'],
          //'CustomerGroupName'               => $ap_row['CustomerGroupName'],
          'RMName'                          => $ap_row['RMName'],
          'DocumentStatusId'                => $account_planning_status['DocumentStatusId'],
          'Status'                          => $account_planning_status['Status'],

          'PinjamanTotalGroup'              => number_format($pinjamanGroup['TotalPinjaman']/VALUE_PER, 0),
          'PinjamanRatasGroup'              => number_format($pinjamanGroup['RatasPinjaman']/VALUE_PER, 0),
          'SimpananTotalGroup'              => number_format($simpananGroup['TotalSimpanan']/VALUE_PER, 0),
          'SimpananRatasGroup'              => number_format($simpananGroup['RatasSimpanan']/VALUE_PER, 0),
          'CurrentCPAGroup'                 => number_format($cpaGroup['Cpa']/VALUE_PER, 0),

          'PinjamanTotalAP'                 => number_format($pinjamanAp['TotalPinjaman']/VALUE_PER, 0),
          'PinjamanRatasAP'                 => number_format($pinjamanAp['RatasPinjaman']/VALUE_PER, 0),
          'SimpananTotalAP'                 => number_format($simpananAp['TotalSimpanan']/VALUE_PER, 0),
          'SimpananRatasAP'                 => number_format($simpananAp['RatasSimpanan']/VALUE_PER, 0),
          'CurrentCPAAP'                    => number_format($cpaAp['Cpa']/VALUE_PER, 0),

          'account_planning_member'         => $account_planning_member,
          'rm_selected'                     => $rm_selected,
          'account_planning_vcif_list'      => $account_planning_vcif_list
        );
      }
      $params['row'] = $rowno;

      $config['base_url'] = base_url() . 'tasklist/AccountPlanning/page';
      $config['use_page_numbers'] = TRUE;
      $config['total_rows'] = $total_records;
      $config['per_page'] = $limit_per_page;
      $config["uri_segment"] = 3;
      $config['full_tag_open'] = '<ul class="pagination">';
      $config['full_tag_close'] = '</ul>';
      $config['num_tag_open'] = '<li class="page-item">';
      $config['num_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
      $config['cur_tag_close'] = '</a></li>';
      $config['next_tag_open'] = '<li class="page-item">';
      $config['next_tagl_close'] = '</a></li>';
      $config['prev_tag_open'] = '<li class="page-item">';
      $config['prev_tagl_close'] = '</li>';
      $config['first_tag_open'] = '<li class="page-item ">';
      $config['first_tagl_close'] = '</li>';
      $config['last_tag_open'] = '<li class="page-item">';
      $config['last_tagl_close'] = '</a></li>';
      $config['attributes'] = array('class' => 'page-link');

      $this->pagination->initialize($config);

      $params["links"] = $this->pagination->create_links();
    }
    $params['search_box'] = ' style="display: none;"';

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/account_planning_list.php', $params);
    $this->load->view('layout/footer.php');
  }

  public function search($fYear='',$fDocStatus='',$fSearchTxt='',$rowno=0) {
    $this->checkModule();

    $params = array();
    

    if (empty($fYear)) {
      $fYear = ($this->input->post('tahun_search_box')) ? $this->input->post('tahun_search_box') : "";
    }
    else {
      $fYear = str_replace('_', ' ', $fYear);
    }
// echo empty($fDocStatus).'| '.$fDocStatus.'-->';
    if (empty($fDocStatus) && $fDocStatus<>'0') {
      $fDocStatus = ($this->input->post('status_search_box'));
    }
    else {
      $fDocStatus = str_replace('_', ' ', $fDocStatus);
    }
// echo empty($fDocStatus).' | '.$fDocStatus;die();
    if (empty($fSearchTxt)) {
      $fSearchTxt = ($this->input->post('keyword_search_box')) ? $this->input->post('keyword_search_box') : "";
    }
    else {
      $fSearchTxt = trim(str_replace('_', ' ', $fSearchTxt));
    }

    $limit_per_page = 5;
    if($rowno != 0){
      $rowno = ($rowno-1) * $limit_per_page;
    }
    $start_index = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0;

    $pinjamanLastUpdateDate = $this->DataTransaction_model->getPinjamanLastUpdateDate();
    $params['pinjamanLastUpdateDate'] = $pinjamanLastUpdateDate['LastUpdateDate'];
    $simpananLastUpdateDate = $this->DataTransaction_model->getSimpananLastUpdateDate();
    $params['simpananLastUpdateDate'] = $simpananLastUpdateDate['LastUpdateDate'];
    $cpaLastUpdateDate = $this->DataTransaction_model->getCpaLastUpdateDate();
    $params['cpaLastUpdateDate'] = $cpaLastUpdateDate['LastUpdateDate'];

    //$keyword_search = ($this->input->get('keyword_search_box')) ? $this->input->get('keyword_search_box') : "";
    //$status_search = ($this->input->get('status_search_box')) ? $this->input->get('status_search_box') : "all";

    $doc_statuses = $this->MonitoringAccountPlanning_model->get_doc_status();
    $status_search_box['all'] = '--- All ---';
    foreach ($doc_statuses as $doc_status) {
      $status_search_box[$doc_status['DocumentStatusId']] = $doc_status['Name'];
    }
    $params['status_search_box'] = form_dropdown('status_search_box', $status_search_box, $fDocStatus, ' class="form-control col-md-7 col-xs-12" style="width: 50%; min-width:200px"');
    
    $search_year = array('all' => '--- All ---'
                        , $this->current_year-2 => $this->current_year-2
                        , $this->current_year-1 => $this->current_year-1
                        , $this->current_year => $this->current_year);
    $params['tahun_search_box'] = form_dropdown('tahun_search_box', $search_year, $fYear, ' class="form-control col-md-7 col-xs-12" style="width: 25%;min-width: 80px"');

    $total_records = $this->TasklistAccountPlanning_model->getTotalMyAccountPlanning($this->session->PERSONAL_NUMBER, $fYear, $fDocStatus, $fSearchTxt);
    $params['keyword_search_box'] = $fSearchTxt;
    if ($total_records > 0) {   
      // $ap_Tasklist = $this->TasklistAccountPlanning_model->getViewTasklistAccountPlanning($this->session->PERSONAL_NUMBER, $limit_per_page, $rowno, '', '', $this->current_year, '');

      $ap_Tasklist = $this->TasklistAccountPlanning_model->getMyAccountPlanning($this->session->PERSONAL_NUMBER, $limit_per_page, $rowno, $fYear, $fDocStatus, $fSearchTxt);

      foreach ($ap_Tasklist as $ap_row) {
        $CustomerGroupId = $ap_row['CustomerGroupId'];
        $AccountPlanningId = $ap_row['AccountPlanningId'];

        $account_planning_status = $this->PerformanceAccountPlanning_model->getDocumentStatus($AccountPlanningId);
        $account_planning_member = $this->TasklistDisposisi_model->getAccountPlanningMember($AccountPlanningId);
        $rm_selected = $this->TasklistDisposisi_model->getRMSelected($this->session->DIVISION, $CustomerGroupId);
        $account_planning_vcif_list = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);

        $pinjamanGroup = $this->DataTransaction_model->getDataPinjamanGroup($CustomerGroupId);
        $simpananGroup = $this->DataTransaction_model->getDataSimpananGroup($CustomerGroupId);
        $cpaGroup = $this->DataTransaction_model->getDataCpaGroup($CustomerGroupId);

        $pinjamanAp = $this->DataTransaction_model->getDataPinjamanAccountPlanning($AccountPlanningId);
        $simpananAp = $this->DataTransaction_model->getDataSimpananAccountPlanning($AccountPlanningId);
        $cpaAp = $this->DataTransaction_model->getDataCpaAccountPlanning($AccountPlanningId);

        $ap_year_color = '#218FD8';
        if ($ap_row['Year'] != $this->current_year) {
          $ap_year_color = '#F58C38';
        }

        $params['results'][$AccountPlanningId] = array(
          'AccountPlanningId'               => $AccountPlanningId,
          //'Currency'                        => $ap_row['Currency'],
          'CreatedDate'                     => $ap_row['CreatedDate'],
          'Year'                            => $ap_row['Year'],
          'ap_year_color'                   => $ap_year_color,
          'CustomerGroupId'                 => $CustomerGroupId,
          'CustomerName'                    => $ap_row['CustomerName'],
          'Logo'                            => $ap_row['Logo'],
          //'CustomerGroupName'               => $ap_row['CustomerGroupName'],
          'RMName'                          => $ap_row['RMName'],
          'DocumentStatusId'                => $account_planning_status['DocumentStatusId'],
          'Status'                          => $account_planning_status['Status'],

          'PinjamanTotalGroup'              => number_format($pinjamanGroup['TotalPinjaman']/VALUE_PER, 0),
          'PinjamanRatasGroup'              => number_format($pinjamanGroup['RatasPinjaman']/VALUE_PER, 0),
          'SimpananTotalGroup'              => number_format($simpananGroup['TotalSimpanan']/VALUE_PER, 0),
          'SimpananRatasGroup'              => number_format($simpananGroup['RatasSimpanan']/VALUE_PER, 0),
          'CurrentCPAGroup'                 => number_format($cpaGroup['Cpa']/VALUE_PER, 0),

          'PinjamanTotalAP'                 => number_format($pinjamanAp['TotalPinjaman']/VALUE_PER, 0),
          'PinjamanRatasAP'                 => number_format($pinjamanAp['RatasPinjaman']/VALUE_PER, 0),
          'SimpananTotalAP'                 => number_format($simpananAp['TotalSimpanan']/VALUE_PER, 0),
          'SimpananRatasAP'                 => number_format($simpananAp['RatasSimpanan']/VALUE_PER, 0),
          'CurrentCPAAP'                    => number_format($cpaAp['Cpa']/VALUE_PER, 0),

          'account_planning_member'         => $account_planning_member,
          'rm_selected'                     => $rm_selected,
          'account_planning_vcif_list'      => $account_planning_vcif_list
        );
      }
      $params['row'] = $rowno;

      if(empty($fSearchTxt))
          $searchUrl = '_';
      else 
          $searchUrl = $fSearchTxt;

      $config['base_url'] = base_url() . 'tasklist/AccountPlanning/search/'.$fYear.'/'.$fDocStatus.'/'.$searchUrl;
      $config['use_page_numbers'] = TRUE;
      $config['total_rows'] = $total_records;
      $config['per_page'] = $limit_per_page;
      $config["uri_segment"] = 7;
      $config['full_tag_open'] = '<ul class="pagination">';
      $config['full_tag_close'] = '</ul>';
      $config['num_tag_open'] = '<li class="page-item">';
      $config['num_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
      $config['cur_tag_close'] = '</a></li>';
      $config['next_tag_open'] = '<li class="page-item">';
      $config['next_tagl_close'] = '</a></li>';
      $config['prev_tag_open'] = '<li class="page-item">';
      $config['prev_tagl_close'] = '</li>';
      $config['first_tag_open'] = '<li class="page-item ">';
      $config['first_tagl_close'] = '</li>';
      $config['last_tag_open'] = '<li class="page-item">';
      $config['last_tagl_close'] = '</a></li>';
      $config['attributes'] = array('class' => 'page-link');

      $this->pagination->initialize($config);

      $params["links"] = $this->pagination->create_links();
    }
    $params['search_box'] = ' style="display: none;"';

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/account_planning_list.php', $params);
    $this->load->view('layout/footer.php');
  }

  public function page($rowno=0) {
    $this->checkModule();

    $params = array();
    $limit_per_page = 5;
    if($rowno != 0){
      $rowno = ($rowno-1) * $limit_per_page;
    }
    $start_index = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;

    $pinjamanLastUpdateDate = $this->DataTransaction_model->getPinjamanLastUpdateDate();
    $params['pinjamanLastUpdateDate'] = $pinjamanLastUpdateDate['LastUpdateDate'];
    $simpananLastUpdateDate = $this->DataTransaction_model->getSimpananLastUpdateDate();
    $params['simpananLastUpdateDate'] = $simpananLastUpdateDate['LastUpdateDate'];
    $cpaLastUpdateDate = $this->DataTransaction_model->getCpaLastUpdateDate();
    $params['cpaLastUpdateDate'] = $cpaLastUpdateDate['LastUpdateDate'];

    $doc_statuses = $this->MonitoringAccountPlanning_model->get_doc_status();
    $status_search_box['all'] = '--- All ---';
    foreach ($doc_statuses as $doc_status) {
      $status_search_box[$doc_status['DocumentStatusId']] = $doc_status['Name'];
    }
    $params['status_search_box'] = form_dropdown('status_search_box', $status_search_box, '', ' class="form-control col-md-7 col-xs-12" style="width: 50%; min-width:200px"');
    
    $search_year = array('all' => '--- All ---'
                        , $this->current_year-2 => $this->current_year-2
                        , $this->current_year-1 => $this->current_year-1
                        , $this->current_year => $this->current_year);
    $params['tahun_search_box'] = form_dropdown('tahun_search_box', $search_year, $this->current_year, ' class="form-control col-md-7 col-xs-12" style="width: 25%;min-width: 80px"');

    $total_records = $this->TasklistAccountPlanning_model->getTotalMyAccountPlanning($this->session->PERSONAL_NUMBER, $this->current_year);
     $params['keyword_search_box'] = '';
    if ($total_records > 0) {   

      $ap_Tasklist = $this->TasklistAccountPlanning_model->getMyAccountPlanning($this->session->PERSONAL_NUMBER, $limit_per_page, $rowno, $this->current_year);

      foreach ($ap_Tasklist as $ap_row) {
        $CustomerGroupId = $ap_row['CustomerGroupId'];
        $AccountPlanningId = $ap_row['AccountPlanningId'];

        $account_planning_status = $this->PerformanceAccountPlanning_model->getDocumentStatus($AccountPlanningId);
        $account_planning_member = $this->TasklistDisposisi_model->getAccountPlanningMember($AccountPlanningId);
        $rm_selected = $this->TasklistDisposisi_model->getRMSelected($this->session->DIVISION, $CustomerGroupId);
        $account_planning_vcif_list = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);

        $pinjamanGroup = $this->DataTransaction_model->getDataPinjamanGroup($CustomerGroupId);
        $simpananGroup = $this->DataTransaction_model->getDataSimpananGroup($CustomerGroupId);
        $cpaGroup = $this->DataTransaction_model->getDataCpaGroup($CustomerGroupId);

        $pinjamanAp = $this->DataTransaction_model->getDataPinjamanAccountPlanning($AccountPlanningId);
        $simpananAp = $this->DataTransaction_model->getDataSimpananAccountPlanning($AccountPlanningId);
        $cpaAp = $this->DataTransaction_model->getDataCpaAccountPlanning($AccountPlanningId);

        $ap_year_color = '#218FD8';
        if ($ap_row['Year'] != $this->current_year) {
          $ap_year_color = '#F58C38';
        }

        $params['results'][$AccountPlanningId] = array(
          'AccountPlanningId'               => $AccountPlanningId,
          //'Currency'                        => $ap_row['Currency'],
          'CreatedDate'                     => $ap_row['CreatedDate'],
          'Year'                            => $ap_row['Year'],
          'ap_year_color'                   => $ap_year_color,
          'CustomerGroupId'                 => $CustomerGroupId,
          'CustomerName'                    => $ap_row['CustomerName'],
          'Logo'                            => $ap_row['Logo'],
          //'CustomerGroupName'               => $ap_row['CustomerGroupName'],
          'RMName'                          => $ap_row['RMName'],
          'DocumentStatusId'                => $account_planning_status['DocumentStatusId'],
          'Status'                          => $account_planning_status['Status'],

          'PinjamanTotalGroup'              => number_format($pinjamanGroup['TotalPinjaman']/VALUE_PER, 0),
          'PinjamanRatasGroup'              => number_format($pinjamanGroup['RatasPinjaman']/VALUE_PER, 0),
          'SimpananTotalGroup'              => number_format($simpananGroup['TotalSimpanan']/VALUE_PER, 0),
          'SimpananRatasGroup'              => number_format($simpananGroup['RatasSimpanan']/VALUE_PER, 0),
          'CurrentCPAGroup'                 => number_format($cpaGroup['Cpa']/VALUE_PER, 0),

          'PinjamanTotalAP'                 => number_format($pinjamanAp['TotalPinjaman']/VALUE_PER, 0),
          'PinjamanRatasAP'                 => number_format($pinjamanAp['RatasPinjaman']/VALUE_PER, 0),
          'SimpananTotalAP'                 => number_format($simpananAp['TotalSimpanan']/VALUE_PER, 0),
          'SimpananRatasAP'                 => number_format($simpananAp['RatasSimpanan']/VALUE_PER, 0),
          'CurrentCPAAP'                    => number_format($cpaAp['Cpa']/VALUE_PER, 0),

          'account_planning_member'         => $account_planning_member,
          'rm_selected'                     => $rm_selected,
          'account_planning_vcif_list'      => $account_planning_vcif_list
        );
      }
      $params['row'] = $rowno;

      $config['base_url'] = base_url() . 'tasklist/AccountPlanning/page';
      $config['use_page_numbers'] = TRUE;
      $config['total_rows'] = $total_records;
      $config['per_page'] = $limit_per_page;
      $config["uri_segment"] = 4;
      $config['full_tag_open'] = '<ul class="pagination">';
      $config['full_tag_close'] = '</ul>';
      $config['num_tag_open'] = '<li class="page-item">';
      $config['num_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
      $config['cur_tag_close'] = '</a></li>';
      $config['next_tag_open'] = '<li class="page-item">';
      $config['next_tagl_close'] = '</a></li>';
      $config['prev_tag_open'] = '<li class="page-item">';
      $config['prev_tagl_close'] = '</li>';
      $config['first_tag_open'] = '<li class="page-item ">';
      $config['first_tagl_close'] = '</li>';
      $config['last_tag_open'] = '<li class="page-item">';
      $config['last_tagl_close'] = '</a></li>';
      $config['attributes'] = array('class' => 'page-link');

      $this->pagination->initialize($config);

      $params["links"] = $this->pagination->create_links();
    }
    $params['search_box'] = ' style="display: none;"';

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/account_planning_list.php', $params);
    $this->load->view('layout/footer.php');
  }

  public function update_currency($AccountPlanningId, $FinancialHighlightCurrency) {
    $updateData = $this->TasklistAccountPlanning_model->updateData('AccountPlanning', array('FinancialHighlightCurrency' => $FinancialHighlightCurrency), 'AccountPlanningId', $AccountPlanningId);

  }

  public function input_proc() {
    $this->checkModule();

    $Years = Array(  
                    date('Y') - 3,
                    date('Y') - 2,
                    date('Y') - 1
            );
    // Delete data
    if (!empty($this->input->post('RemoveId'))) {
      foreach ($this->input->post('RemoveId') as $key => $value) {
          $data_delete[$key] = array (
            $this->input->post('IdName')[$key]  => $value
          );

          $deleteData = $this->TasklistAccountPlanning_model->deleteData($this->input->post('InputTable'), $data_delete[$key]);
      }
    }

    // Service
    if ($this->input->post('InputTable') == 'Service') {
      if (!empty($this->input->post('Name'))) {
        foreach ($this->input->post('Name') as $key => $value) {
          if (!empty($value)) {
            $data_input[$key] = array (
              'AccountPlanningId'     => $this->input->post('AccountPlanningId')
              , 'VCIF'                => $this->input->post('VCIF')
              , 'Name'                => $value
              , 'Target'              => $this->input->post('Target')[$key]
              , 'Description'         => $this->input->post('Description')[$key]
              , 'CreatedDate'         => $this->current_datetime
              , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
            $data_form[$key]['Id_name']                 = 'ServiceId';
            $data_form[$key]['InputTable']              = $this->input->post('InputTable');
            $data_form[$key]['ServiceSubmit']           = $this->input->post('ServiceSubmit')[$key];
            if (!empty($this->input->post('ServiceId')[$key])) {
              $data_form[$key]['ServiceId']   = $this->input->post('ServiceId')[$key];
            }

            if ($data_form[$key]['ServiceSubmit'] == 'edit') {
              $updateData = $this->TasklistAccountPlanning_model->updateData($data_form[$key]['InputTable'], $data_input[$key], $data_form[$key]['Id_name'], $data_form[$key]['ServiceId']);
              $deleteTagService[$key] = $this->TasklistAccountPlanning_model->deleteData('TagServiceUnitKerja', array($data_form[$key]['Id_name'] => $data_form[$key]['ServiceId']));
            }
            else if ($data_form[$key]['ServiceSubmit'] == 'add') {
              $data_form[$key]['ServiceId'] = $this->TasklistAccountPlanning_model->insertDataGetInputedId($data_form[$key]['InputTable'], $data_input[$key]);
            } 

            if (!empty($this->input->post('ServiceTag')[$key]['ServiceTags'])) {
              foreach ($this->input->post('ServiceTag')[$key]['ServiceTags'] as $keys => $values) {
                if (!empty($values)) {
                  $data_input_tag[$key] = array (
                    'ServiceId'                => $data_form[$key]['ServiceId']
                    , 'UnitKerjaId'            => $values
                  );
                  $insertServiceTag[$key] = $this->TasklistAccountPlanning_model->insertData('TagServiceUnitKerja', $data_input_tag[$key]);
                }
              }
            }

          }
        }
      }
    }
    // Funding
    else if ($this->input->post('InputTable') == 'Funding') {
      if (!empty($this->input->post('FundingNeed'))) {
        foreach ($this->input->post('FundingNeed') as $key => $value) {

          if (!empty($value)) {
            $Amount[$key] = NULL;
            if (!empty($this->input->post('Amount')[$key])) {
              $Amount[$key] = str_replace(',', '', $this->input->post('Amount')[$key]);
            }
            $data_input[$key] = array (
              'AccountPlanningId'     => $this->input->post('AccountPlanningId')
              , 'VCIF'                => $this->input->post('VCIF')
              , 'FundingNeed'         => $value
              , 'TimePeriod'          => $this->input->post('TimePeriod')[$key]
              , 'Amount'              => $Amount[$key]
              , 'Description'         => $this->input->post('Description')[$key]
              , 'CreatedDate'         => $this->current_datetime
              , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
            $data_form[$key]['Id_name']               = 'FundingId';
            $data_form[$key]['InputTable']            = $this->input->post('InputTable');
            $data_form[$key]['ActionSubmit']          = $this->input->post('FundingSubmit')[$key];
            if (!empty($this->input->post('FundingId')[$key])) {
              $data_form[$key]['FundingId']   = $this->input->post('FundingId')[$key];
            }

            if ($data_form[$key]['ActionSubmit'] == 'edit') {
              $updateData = $this->TasklistAccountPlanning_model->updateData($data_form[$key]['InputTable'], $data_input[$key], $data_form[$key]['Id_name'], $data_form[$key]['FundingId']);
            }
            else if ($data_form[$key]['ActionSubmit'] == 'add') {
              $insertData = $this->TasklistAccountPlanning_model->insertData($data_form[$key]['InputTable'], $data_input[$key]);
            } 
          }
        }
      }
    }
    // InitiativeAction
    else if ($this->input->post('InputTable') == 'InitiativeAction') {
      if (!empty($this->input->post('Name'))) {
        foreach ($this->input->post('Name') as $key => $value) {

          if (!empty($value)) {
            $data_input[$key] = array (
              'AccountPlanningId'     => $this->input->post('AccountPlanningId')
              , 'VCIF'                => $this->input->post('VCIF')
              , 'Name'                => $value
              , 'Period'              => $this->input->post('Period')[$key]
              , 'Description'         => $this->input->post('Description')[$key]
              , 'CreatedDate'         => $this->current_datetime
              , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
            $data_form[$key]['Id_name']               = 'InitiativeActionId';
            $data_form[$key]['InputTable']            = $this->input->post('InputTable');
            $data_form[$key]['ActionSubmit']          = $this->input->post('InitiativeActionSubmit')[$key];
            if (!empty($this->input->post('InitiativeActionId')[$key])) {
              $data_form[$key]['InitiativeActionId']   = $this->input->post('InitiativeActionId')[$key];
              $data_form[$data_form[$key]['InitiativeActionId']]['RemoveId']              = $this->input->post('InitiativeActionId')[$data_form[$key]['InitiativeActionId']];
            }

            if ($data_form[$key]['ActionSubmit'] == 'edit') {
              $updateData = $this->TasklistAccountPlanning_model->updateData($data_form[$key]['InputTable'], $data_input[$key], $data_form[$key]['Id_name'], $data_form[$key]['InitiativeActionId']);
            }
            else if ($data_form[$key]['ActionSubmit'] == 'add') {
              $insertData = $this->TasklistAccountPlanning_model->insertData($data_form[$key]['InputTable'], $data_input[$key]);
            } 
          }
        }
      }

    }

    // New BankFacilityItemAddition
    if (!empty($this->input->post('NewAddition')['BankFacilityItemAdditionName'])) {
      foreach ($this->input->post('NewAddition')['BankFacilityItemAdditionName'] as $key => $value) {
        $IDRAmountAddition[$key] = 0;
        if (!empty($this->input->post('NewAddition')['IDRAmountAddition'][$key])) {
          $IDRAmountAddition[$key] = str_replace(',', '', $this->input->post('NewAddition')['IDRAmountAddition'][$key]);
        }
        
        $ValasAmountAddition[$key] = 0;
        if (!empty($this->input->post('NewAddition')['ValasAmountAddition'][$key])) {
          $ValasAmountAddition[$key] = str_replace(',', '', $this->input->post('NewAddition')['ValasAmountAddition'][$key]);
        }
        
        $IDRRateAddition[$key] = ($this->input->post('NewAddition')['IDRRateAddition'][$key]) ? $this->input->post('NewAddition')['IDRRateAddition'][$key] : 0;
        $ValasRateAddition[$key] = ($this->input->post('NewAddition')['ValasRateAddition'][$key]) ? $this->input->post('NewAddition')['ValasRateAddition'][$key] : 0;

        $data_formNewAddition = array (
          'InputTableItemAddition'          => 'BankFacilityItemAddition'
          , 'InputTableAddition'              => $this->input->post('NewAddition')['InputTableAddition']
          , 'InputTableSubmitAddition'      => $this->input->post('NewAddition')['BankFacilityAdditionSubmit']
        );

        $data_inputNewAdditionItem[$key] = array (
          'Name'                          => $value
          , 'BankFacilityGroupId'         => $this->input->post('BankFacilityGroupId')
          , 'AccountPlanningId'           => $this->input->post('AccountPlanningId')
          , 'VCIF'                        => $this->input->post('VCIF')
          , 'CreatedDate'                 => $this->current_datetime
          , 'CreatedBy'                   => $this->session->PERSONAL_NUMBER
          );

        if ($data_formNewAddition['InputTableSubmitAddition'][$key] == 'add') {
          $insertDataNewAdditionItem = $this->TasklistAccountPlanning_model->insertDataGetInputedId($data_formNewAddition['InputTableItemAddition'], $data_inputNewAdditionItem[$key]);

          $data_inputNewAddition[$key] = array (
            'BankFacilityItemAdditionId'    => $insertDataNewAdditionItem
            , 'AccountPlanningId'           => $this->input->post('AccountPlanningId')
            , 'VCIF'                        => $this->input->post('VCIF')
            , 'IDRAmountAddition'           => $IDRAmountAddition[$key]
            , 'IDRRateAddition'             => $IDRRateAddition[$key]
            , 'ValasAmountAddition'         => $ValasAmountAddition[$key]
            , 'ValasRateAddition'           => $ValasRateAddition[$key]
            , 'CreatedDate'                 => $this->current_datetime
            , 'CreatedBy'                   => $this->session->PERSONAL_NUMBER
            );

          $insertDataNewAddition = $this->TasklistAccountPlanning_model->insertData($data_formNewAddition['InputTableAddition'], $data_inputNewAddition[$key]);

        }

      }

    }

    // BankFacilityItemAddition
    if (!empty($this->input->post('BankFacilityItemAdditionId'))) {
      foreach ($this->input->post('BankFacilityItemAdditionId') as $key => $value) {

        // EstimatedFinancialAddition
        if ($this->input->post('InputTableAddition') == 'EstimatedFinancialAddition') {
          
          $IDRProjectionAddition[$key] = NULL;
          if (!empty($this->input->post('IDRProjectionAddition')[$key])) {
            $IDRProjectionAddition[$key] = str_replace(',', '', $this->input->post('IDRProjectionAddition')[$key]);
          }

          $ValasProjectionAddition[$key] = NULL;
          if (!empty($this->input->post('ValasProjectionAddition')[$key])) {
            $ValasProjectionAddition[$key] = str_replace(',', '', $this->input->post('ValasProjectionAddition')[$key]);
          }

          $IDRTargetAddition[$key] = NULL;
          if (!empty($this->input->post('IDRTargetAddition')[$key])) {
            $IDRTargetAddition[$key] = str_replace(',', '', $this->input->post('IDRTargetAddition')[$key]);
          }
          
          $ValasTargetAddition[$key] = NULL;
          if (!empty($this->input->post('ValasTargetAddition')[$key])) {
            $ValasTargetAddition[$key] = str_replace(',', '', $this->input->post('ValasTargetAddition')[$key]);
          }

          $data_formAddition = array (
            'InputTableAddition'              => $this->input->post('InputTableAddition')
            , 'InputTableSubmitAddition'      => $this->input->post('EstimatedFinancialAdditionSubmit')
            , 'InputTableIdFieldAddition'     => 'EstimatedFinancialAdditionId'
            , 'InputTableIdValueAddition'     => $this->input->post('EstimatedFinancialAdditionId')
          );

          $data_inputAddition[$key] = array (
            'BankFacilityItemAdditionId'    => $value
            , 'AccountPlanningId'           => $this->input->post('AccountPlanningId')
            , 'VCIF'                        => $this->input->post('VCIF')
            , 'IDRProjectionAddition'       => $IDRProjectionAddition[$key]
            , 'IDRTargetAddition'           => $IDRTargetAddition[$key]
            , 'ValasProjectionAddition'     => $ValasProjectionAddition[$key]
            , 'ValasTargetAddition'         => $ValasTargetAddition[$key]
            , 'CreatedDate'                 => $this->current_datetime
            , 'CreatedBy'                   => $this->session->PERSONAL_NUMBER
          );
        }
        // BankFacilityAddition
        else if ($this->input->post('InputTableAddition') == 'BankFacilityAddition') {
          
          $IDRAmountAddition[$key] = 0;
          if (!empty($this->input->post('IDRAmountAddition')[$key])) {
            $IDRAmountAddition[$key] = str_replace(',', '', $this->input->post('IDRAmountAddition')[$key]);
          }
          
          $ValasAmountAddition[$key] = 0;
          if (!empty($this->input->post('ValasAmountAddition')[$key])) {
            $ValasAmountAddition[$key] = str_replace(',', '', $this->input->post('ValasAmountAddition')[$key]);
          }
          
          $IDRRateAddition[$key] = ($this->input->post('IDRRateAddition')[$key]) ? $this->input->post('IDRRateAddition')[$key] : 0;
          $ValasRateAddition[$key] = ($this->input->post('ValasRateAddition')[$key]) ? $this->input->post('ValasRateAddition')[$key] : 0;

          $data_formAddition = array (
            'InputTableAddition'              => $this->input->post('InputTableAddition')
            , 'InputTableSubmitAddition'      => $this->input->post('BankFacilityAdditionSubmit')
            , 'InputTableIdFieldAddition'     => 'BankFacilityItemAdditionId'
            , 'InputTableIdValueAddition'     => $this->input->post('BankFacilityItemAdditionId')
          );

          $data_inputAddition[$key] = array (
            'BankFacilityItemAdditionId'    => $value
            , 'AccountPlanningId'           => $this->input->post('AccountPlanningId')
            , 'VCIF'                        => $this->input->post('VCIF')
            , 'IDRAmountAddition'           => $IDRAmountAddition[$key]
            , 'IDRRateAddition'             => $IDRRateAddition[$key]
            , 'ValasAmountAddition'         => $ValasAmountAddition[$key]
            , 'ValasRateAddition'           => $ValasRateAddition[$key]
            , 'CreatedDate'                 => $this->current_datetime
            , 'CreatedBy'                   => $this->session->PERSONAL_NUMBER
            );
        }
        
        // WalletShareAddition
        else if ($this->input->post('InputTableAddition') == 'WalletShareAddition') {
          /*
          $BRINominalAddition[$key] = NULL;
          if (!empty($this->input->post('BRINominalAddition')[$key])) {
            $BRINominalAddition[$key] = str_replace(',', '', $this->input->post('BRINominalAddition')[$key]);
          }
          
          $OtherNominalAddition[$key] = NULL;
          if (!empty($this->input->post('OtherNominalAddition')[$key])) {
            $OtherNominalAddition[$key] = str_replace(',', '', $this->input->post('OtherNominalAddition')[$key]);
          }
          */
          $TotalAmountAddition[$key] = 0;
          if (!empty($this->input->post('TotalAmountAddition')[$key])) {
            $TotalAmountAddition[$key] = str_replace(',', '', $this->input->post('TotalAmountAddition')[$key]);
          }
          
          /*
          $BRIPortionAddition[$key] = ($this->input->post('BRIPortionAddition')[$key]) ? $this->input->post('BRIPortionAddition')[$key] : NULL;
          $OtherPortionAddition[$key] = ($this->input->post('OtherPortionAddition')[$key]) ? $this->input->post('OtherPortionAddition')[$key] : NULL;

          $data_inputAddition[$key] = array (
            'BankFacilityItemAdditionId'  => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')[$key]
            , 'BRINominalAddition'          => $BRINominalAddition[$key]
            , 'BRIPortionAddition'          => $BRIPortionAddition[$key]
            , 'OtherNominalAddition'        => $OtherNominalAddition[$key]
            , 'OtherPortionAddition'        => $OtherPortionAddition[$key]
            , 'TotalAmountAddition'         => $TotalAmountAddition[$key]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
          */

          $data_formAddition = array (
            'InputTableAddition'              => $this->input->post('InputTableAddition')
            , 'InputTableSubmitAddition'      => $this->input->post('WalletShareAdditionSubmit')
            , 'InputTableIdFieldAddition'     => 'WalletShareAdditionId'
            , 'InputTableIdValueAddition'     => $this->input->post('WalletShareAdditionId')
          );
          $data_inputAddition[$key] = array (
            'BankFacilityItemAdditionId'  => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')
            , 'VCIF'                => $this->input->post('VCIF')
            , 'TotalAmountAddition' => $TotalAmountAddition[$key]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
        }

        /*
        // CompetitionAnalysisAddition
        else if ($this->input->post('InputTableAddition') == 'CompetitionAnalysisAddition') {
          $BankIdAddition[$value][1] = ($this->input->post('BankIdAddition')[$value][1]) ? $this->input->post('BankIdAddition')[$value][1] : NULL;
          $BankIdAddition[$value][2] = ($this->input->post('BankIdAddition')[$value][2]) ? $this->input->post('BankIdAddition')[$value][2] : NULL;
          $BankIdAddition[$value][3] = ($this->input->post('BankIdAddition')[$value][3]) ? $this->input->post('BankIdAddition')[$value][3] : NULL;

          $data_input[$key] = array (
            'BankFacilityItemAdditionId'    => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')[$key]
            , 'BankId1Addition'             => $BankIdAddition[$value][1]
            , 'BankId2Addition'             => $BankIdAddition[$value][2]
            , 'BankId3Addition'             => $BankIdAddition[$value][3]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
        }
        */
        if ($data_formAddition['InputTableSubmitAddition'][$key] == 'edit') {
          $updateData = $this->TasklistAccountPlanning_model->updateData($data_formAddition['InputTableAddition'], $data_inputAddition[$key], $data_formAddition['InputTableIdFieldAddition'], $data_formAddition['InputTableIdValueAddition'][$key]);
        }
        else {
          $insertData = $this->TasklistAccountPlanning_model->insertData($data_formAddition['InputTableAddition'], $data_inputAddition[$key]);
        } 
      }
    }

    // BankFacilityItem
    if (!empty($this->input->post('BankFacilityItemId'))) {
      foreach ($this->input->post('BankFacilityItemId') as $key => $value) {

        // EstimatedFinancial
        if ($this->input->post('InputTable') == 'EstimatedFinancial') {
          
          $IDRProjection[$key] = NULL;
          if (!empty($this->input->post('IDRProjection')[$key])) {
            $IDRProjection[$key] = str_replace(',', '', $this->input->post('IDRProjection')[$key]);
          }

          $ValasProjection[$key] = NULL;
          if (!empty($this->input->post('ValasProjection')[$key])) {
            $ValasProjection[$key] = str_replace(',', '', $this->input->post('ValasProjection')[$key]);
          }

          $IDRTarget[$key] = NULL;
          if (!empty($this->input->post('IDRTarget')[$key])) {
            $IDRTarget[$key] = str_replace(',', '', $this->input->post('IDRTarget')[$key]);
          }
          
          $ValasTarget[$key] = NULL;
          if (!empty($this->input->post('ValasTarget')[$key])) {
            $ValasTarget[$key] = str_replace(',', '', $this->input->post('ValasTarget')[$key]);
          }

          $data_form[$key] = array (
            'InputTable'              => $this->input->post('InputTable')
            , 'InputTableSubmit'      => $this->input->post('EstimatedFinancialSubmit')
            , 'InputTableIdField'     => 'EstimatedFinancialId'
            , 'InputTableIdValue'     => $this->input->post('EstimatedFinancialId')
          );

          $data_input[$key] = array (
            'BankFacilityItemId'    => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')
            , 'VCIF'                => $this->input->post('VCIF')
            , 'IDRProjection'       => $IDRProjection[$key]
            , 'IDRTarget'           => $IDRTarget[$key]
            , 'ValasProjection'     => $ValasProjection[$key]
            , 'ValasTarget'         => $ValasTarget[$key]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
          );
        }
        // BankFacility
        else if ($this->input->post('InputTable') == 'BankFacility') {
          
          $IDRAmount[$key] = 0;
          if (!empty($this->input->post('IDRAmount')[$key])) {
            $IDRAmount[$key] = str_replace(',', '', $this->input->post('IDRAmount')[$key]);
          }
          
          $ValasAmount[$key] = 0;
          if (!empty($this->input->post('ValasAmount')[$key])) {
            $ValasAmount[$key] = str_replace(',', '', $this->input->post('ValasAmount')[$key]);
          }
          
          $IDRRate[$key] = ($this->input->post('IDRRate')[$key]) ? $this->input->post('IDRRate')[$key] : 0;
          $ValasRate[$key] = ($this->input->post('ValasRate')[$key]) ? $this->input->post('ValasRate')[$key] : 0;

          $data_form[$key] = array (
            'InputTable'              => $this->input->post('InputTable')
            , 'InputTableSubmit'      => $this->input->post('BankFacilitySubmit')
            , 'InputTableIdField'     => 'BankFacilityId'
            , 'InputTableIdValue'     => $this->input->post('BankFacilityId')
          );

          $data_input[$key] = array (
            'BankFacilityItemId'  => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')
            , 'VCIF'                => $this->input->post('VCIF')
            , 'IDRAmount'           => $IDRAmount[$key]
            , 'IDRRate'             => $IDRRate[$key]
            , 'ValasAmount'         => $ValasAmount[$key]
            , 'ValasRate'           => $ValasRate[$key]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
        }
        // WalletShare
        else if ($this->input->post('InputTable') == 'WalletShare') {
          /*
          $BRINominal[$key] = NULL;
          if (!empty($this->input->post('BRINominal')[$key])) {
            $BRINominal[$key] = str_replace(',', '', $this->input->post('BRINominal')[$key]);
          }
          
          $OtherNominal[$key] = NULL;
          if (!empty($this->input->post('OtherNominal')[$key])) {
            $OtherNominal[$key] = str_replace(',', '', $this->input->post('OtherNominal')[$key]);
          }
          */
          $TotalAmount[$key] = 0;
          if (!empty($this->input->post('TotalAmount')[$key])) {
            $TotalAmount[$key] = str_replace(',', '', $this->input->post('TotalAmount')[$key]);
          }
          //echo $TotalAmount[$key]; die;
          
          /*
          $BRIPortion[$key] = ($this->input->post('BRIPortion')[$key]) ? $this->input->post('BRIPortion')[$key] : NULL;
          $OtherPortion[$key] = ($this->input->post('OtherPortion')[$key]) ? $this->input->post('OtherPortion')[$key] : NULL;
          
          $data_input[$key] = array (
            'BankFacilityItemId'  => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')[$key]
            , 'BRINominal'          => $BRINominal[$key]
            , 'BRIPortion'          => $BRIPortion[$key]
            , 'OtherNominal'        => $OtherNominal[$key]
            , 'OtherPortion'        => $OtherPortion[$key]
            , 'TotalAmount'         => $TotalAmount[$key]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
          */

          $data_form[$key] = array (
            'InputTable'              => $this->input->post('InputTable')
            , 'InputTableSubmit'      => $this->input->post('WalletShareSubmit')
            , 'InputTableIdField'     => 'WalletShareId'
            , 'InputTableIdValue'     => $this->input->post('WalletShareId')
          );
          $data_input[$key] = array (
            'BankFacilityItemId'  => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')
            , 'VCIF'                => $this->input->post('VCIF')
            , 'TotalAmount'         => $TotalAmount[$key]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
            //echo json_encode($data_input); die;
        }        
        
        // CompetitionAnalysis
        else if ($this->input->post('InputTable') == 'CompetitionAnalysis') {
          $BankId[$value][1] = ($this->input->post('BankId')[$value][1]) ? $this->input->post('BankId')[$value][1] : NULL;
          $BankId[$value][2] = ($this->input->post('BankId')[$value][2]) ? $this->input->post('BankId')[$value][2] : NULL;
          $BankId[$value][3] = ($this->input->post('BankId')[$value][3]) ? $this->input->post('BankId')[$value][3] : NULL;

          $data_form[$key] = array (
            'InputTable'              => $this->input->post('InputTable')
            , 'InputTableSubmit'      => $this->input->post('CompetitionAnalysisSubmit')
            , 'InputTableIdField'     => 'CompetitionAnalysisId'
            , 'InputTableIdValue'     => $this->input->post('CompetitionAnalysisId')[$key]
          );

          $data_input[$key] = array (
            'BankFacilityItemId'    => $value
            , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')
            , 'BankId1'             => $BankId[$value][1]
            , 'BankId2'             => $BankId[$value][2]
            , 'BankId3'             => $BankId[$value][3]
            , 'CreatedDate'         => $this->current_datetime
            , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
            );
        }

        //echo json_encode($data_form); die;
        if ($data_form[$key]['InputTableSubmit'] == 'edit') {
          $updateData = $this->TasklistAccountPlanning_model->updateData($data_form[$key]['InputTable'], $data_input[$key], $data_form[$key]['InputTableIdField'], $data_form[$key]['InputTableIdValue']);
        }
        else {
          $insertData = $this->TasklistAccountPlanning_model->insertData($data_form[$key]['InputTable'], $data_input[$key]);
        } 

      }
    }

    // FinancialHighlight
    if (!empty($this->input->post('FinancialHighlightItemId'))) {
      foreach ($this->input->post('FinancialHighlightItemId') as $key => $value) {
        $FinancialHighlightItemId =  $value;
        $AccountPlanningId = $this->input->post('AccountPlanningId')[$key];
        foreach ($Years as $keys => $values) {
          // $Amount = ($this->input->post('Amount')[$values][$key]) ? $this->input->post('Amount')[$values][$key] : 0;
          $Amount = NULL;
          if (!empty($this->input->post('Amount')[$values][$key])) {
            $Amount = str_replace(',', '', $this->input->post('Amount')[$values][$key]);
          }
          $data_input[$FinancialHighlightItemId][$values] = array (
            'FinancialHighlightItemId'  => $FinancialHighlightItemId
            , 'AccountPlanningId'         => $AccountPlanningId
            , 'Year'                      => $values
            , 'Amount'                    => $Amount
            , 'CreatedDate'               => $this->current_datetime
            , 'CreatedBy'                 => $this->session->PERSONAL_NUMBER
          );
          if ($this->input->post('FinancialHighlightSubmit') == 'add') {
            $insertData = $this->TasklistAccountPlanning_model->insertData($this->input->post('InputTable'), $data_input[$FinancialHighlightItemId][$values]);
          }
          else {
            $updateData = $this->TasklistAccountPlanning_model->updateData($this->input->post('InputTable'), $data_input[$FinancialHighlightItemId][$values], 'FinancialHighlightId', $this->input->post('FinancialHighlightId')[$values][$key]);
          }
        }
      }
    }

  }

  public function inputform($AccountPlanningId, $AccountPlanningTab, $BankFacilityGroupType, $BankFacilityGroupId, $VCIF='' ) {
    $this->checkModule();

    $data['AccountPlanningId']        = $AccountPlanningId;
    $data['AccountPlanningTab']       = $AccountPlanningTab;
    $data['account_planning']['Years'] = Array(  
                                                date('Y') - 3,
                                                date('Y') - 2,
                                                date('Y') - 1
                                        );
    $data['FinancialHighlight']['Currency'] = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlightCurrency($AccountPlanningId);
    $data['FinancialHighlight']['class_usd1'] = 'primary';
    $data['FinancialHighlight']['class_idr1'] = 'default';
    if ($data['FinancialHighlight']['Currency'] == 'IDR') {
      $data['FinancialHighlight']['class_usd1'] = 'default';
      $data['FinancialHighlight']['class_idr1'] = 'primary';
    }
    // print_r($data['FinancialHighlight']);

    $data['account_planning_vcif_list'] = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);

    if ($BankFacilityGroupType == 'financial_highlights') {
      $data['FinancialHighlightGroupType']    = $BankFacilityGroupType;
      $data['FinancialHighlightGroupId']      = $BankFacilityGroupId;
      $data['FinancialHighlightSubmit']       = 'add';

      // FinancialHighlight
      $FinancialHighlightItem = $this->TasklistAccountPlanning_model->getAccountPlanningFinancialHighlightItem($BankFacilityGroupId);
      $data['FinancialHighlightGroupName']    = $FinancialHighlightItem[0]['FinancialHighlightGroupName'];
      foreach ($FinancialHighlightItem as $key => $value) {
        $inputform_type = 'money';
        if ($value['FinancialHighlightItemId'] == 12 || $value['FinancialHighlightItemId'] == 13 || $value['FinancialHighlightItemId'] == 12 || $value['FinancialHighlightItemId'] == 18 || $value['FinancialHighlightItemId'] == 19 || $value['FinancialHighlightItemId'] == 20 || $value['FinancialHighlightItemId'] == 21 || $value['FinancialHighlightItemId'] == 22 || $value['FinancialHighlightItemId'] == 23) {
          $inputform_type = 'portion';
        }
        $data['inputform'][$BankFacilityGroupType][$value['FinancialHighlightItemId']]= array(
          'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
          , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
          , 'FinancialHighlight_inputform_type'   => $inputform_type
          );
        foreach ($data['account_planning']['Years'] as $keyss => $valuess) {
          $data['inputform'][$BankFacilityGroupType][$value['FinancialHighlightItemId']][$valuess] = array(
              'Amount'                        => ''
              , 'FinancialHighlightId'        => 0
            );
        }

        $dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlight($AccountPlanningId, $value['FinancialHighlightItemId']);
        if (!empty($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']])) {
          foreach ($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] as $keys => $values) {
            $data['FinancialHighlightSubmit'] = 'edit';
            $data['inputform'][$BankFacilityGroupType][$value['FinancialHighlightItemId']][$values['Year']] = array(
              'Amount'                        => $values['Amount']
              , 'FinancialHighlightId'        => $values['FinancialHighlightId']
              );
          }
        }
      }

    }
    else if ($BankFacilityGroupType == 'facilities_banking') {
      $data['BankFacilityGroupType']                    = $BankFacilityGroupType;
      $data['BankFacilityGroupId']                      = $BankFacilityGroupId;
      $data['VCIF']                                     = $VCIF;
      $data['BankFacilitySubmit']                       = 'add';
      $dataBankFacilityItem = $this->TasklistAccountPlanning_model->getAccountPlanningBankFacilityItem($BankFacilityGroupId);
      $data['BankFacilityGroupName']    = $dataBankFacilityItem[0]['BankFacilityGroupName'];

      foreach ($dataBankFacilityItem as $key => $value) {

      // facilities banking
        $dataBankFacility[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacility($AccountPlanningId, $value['BankFacilityItemId'], $VCIF);

        $data['CompanyName']               = '';
          $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['BankFacility_detail'][$value['BankFacilityItemId']] = array(
            'BankFacilityId'              => 0
            , 'BankFacilityItemId'        => $value['BankFacilityItemId']
            , 'BankFacilityItemName'      => $value['BankFacilityItemName']
            , 'IDRAmount'                 => 0
            , 'IDRRate'                   => 0
            , 'ValasAmount'               => 0
            , 'ValasRate'                 => 0
            , 'BankFacilitySubmit'        => 'add'
          );

        if (isset($dataBankFacility[$value['BankFacilityGroupId']][0])) {
          $data['CompanyName']                = $dataBankFacility[$value['BankFacilityGroupId']][0]['CompanyName'];
            $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['BankFacility_detail'][$value['BankFacilityItemId']] = array(
              'BankFacilityId'                => $dataBankFacility[$value['BankFacilityGroupId']][0]['BankFacilityId']
              , 'BankFacilityItemId'          => $value['BankFacilityItemId']
              , 'BankFacilityItemName'        => $value['BankFacilityItemName']
              , 'IDRAmount'                   => $dataBankFacility[$value['BankFacilityGroupId']][0]['IDRAmount']
              , 'IDRRate'                     => $dataBankFacility[$value['BankFacilityGroupId']][0]['IDRRate']
              , 'ValasAmount'                 => $dataBankFacility[$value['BankFacilityGroupId']][0]['ValasAmount']
              , 'ValasRate'                   => $dataBankFacility[$value['BankFacilityGroupId']][0]['ValasRate']
              , 'BankFacilitySubmit'          => 'edit'
            );
        }

      // facilities banking Addition
        $dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$VCIF] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $VCIF, $value['BankFacilityGroupId']);


        if (isset($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$VCIF])) {
          foreach ($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$VCIF] as $keyssss => $BankFacilityItemAddition) {
            $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                'BankFacilityAdditionId'              => 0
                , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
                , 'IDRAmountAddition'                 => 0
                , 'IDRRateAddition'                   => 0
                , 'ValasAmountAddition'               => 0
                , 'ValasRateAddition'                 => 0
                , 'BankFacilityAdditionSubmit'        => 'add'
              );

            $dataBankFacilityAddition[$value['BankFacilityGroupId']][$VCIF][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $VCIF);

            foreach ($dataBankFacilityAddition[$value['BankFacilityGroupId']][$VCIF][$BankFacilityItemAddition['BankFacilityItemAdditionId']] as $keysssss => $BankFacilityAddition) {
              $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                  'BankFacilityAdditionId'              => $BankFacilityAddition['BankFacilityAdditionId']
                  , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                  , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
                  , 'IDRAmountAddition'                 => $BankFacilityAddition['IDRAmountAddition']
                  , 'IDRRateAddition'                   => $BankFacilityAddition['IDRRateAddition']
                  , 'ValasAmountAddition'               => $BankFacilityAddition['ValasAmountAddition']
                  , 'ValasRateAddition'                 => $BankFacilityAddition['ValasRateAddition']
                  , 'BankFacilityAdditionSubmit'        => 'edit'
                );

            }

          }
        }

      }
    }
    else if ($BankFacilityGroupType == 'estimated_financial') {
      $data['BankFacilityGroupType']                    = $BankFacilityGroupType;
      $data['BankFacilityGroupId']                      = $BankFacilityGroupId;
      $data['VCIF']                                     = $VCIF;
      $data['EstimatedFinancialSubmit']                 = 'add';
      $dataBankFacilityItem = $this->TasklistAccountPlanning_model->getAccountPlanningBankFacilityItem($BankFacilityGroupId);
      $data['BankFacilityGroupName']    = $dataBankFacilityItem[0]['BankFacilityGroupName'];

      foreach ($dataBankFacilityItem as $key => $value) {

      // Estimated Financial
        $dataEstimatedFinancial[$value['BankFacilityGroupId']] = $this->TasklistAccountPlanning_model->getAccountPlanningEstimatedFinancial($AccountPlanningId, $value['BankFacilityItemId'], $VCIF);

        $data['CompanyName']                = '';
          $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$value['BankFacilityItemId']] = array(
            'EstimatedFinancialId'        => 0
            , 'BankFacilityItemId'        => $value['BankFacilityItemId']
            , 'BankFacilityItemName'      => $value['BankFacilityItemName']
            , 'IDRProjection'             => ''
            , 'IDRTarget'                 => ''
            , 'ValasProjection'           => ''
            , 'ValasTarget'               => ''
            , 'EstimatedFinancialSubmit'  => 'add'
          );

        if (isset($dataEstimatedFinancial[$value['BankFacilityGroupId']][0])) {
          $data['CompanyName']                = $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['CompanyName'];
            $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$value['BankFacilityItemId']] = array(
              'EstimatedFinancialId'          => $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['EstimatedFinancialId']
              , 'BankFacilityItemId'          => $value['BankFacilityItemId']
              , 'BankFacilityItemName'        => $value['BankFacilityItemName']
              , 'IDRProjection'               => $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['IDRProjection']
              , 'IDRTarget'                   => $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['IDRTarget']
              , 'ValasProjection'             => $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['ValasProjection']
              , 'ValasTarget'                 => $dataEstimatedFinancial[$value['BankFacilityGroupId']][0]['ValasTarget']
              , 'EstimatedFinancialSubmit'    => 'edit'
            );
        }

      // Estimated Financial Addition
        $dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$VCIF] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $VCIF, $value['BankFacilityGroupId']);


        if (isset($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$VCIF])) {
          foreach ($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$VCIF] as $keyssss => $BankFacilityItemAddition) {

            $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['EstimatedFinancialAddition_detail'][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
              'EstimatedFinancialAdditionId'        => 0
              , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
              , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
              , 'IDRProjectionAddition'             => ''
              , 'IDRTargetAddition'                 => ''
              , 'ValasProjectionAddition'           => ''
              , 'ValasTargetAddition'               => ''
              , 'EstimatedFinancialAdditionSubmit'  => 'add'
              );

            $dataEstimatedFinancialAddition[$value['BankFacilityGroupId']][$VCIF][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningEstimatedFinancialAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $VCIF);

            foreach ($dataEstimatedFinancialAddition[$value['BankFacilityGroupId']][$VCIF][$BankFacilityItemAddition['BankFacilityItemAdditionId']] as $keysssss => $EstimatedFinancialAddition) {

              $data['EstimatedFinancialAdditionSubmit']       = 'edit';
              $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['EstimatedFinancialAddition_detail'][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                'EstimatedFinancialAdditionId'           => $EstimatedFinancialAddition['EstimatedFinancialAdditionId']
                , 'BankFacilityItemAdditionName'         => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                , 'BankFacilityItemAdditionId'           => $BankFacilityItemAddition['BankFacilityItemAdditionId']
                , 'IDRProjectionAddition'                => $EstimatedFinancialAddition['IDRProjectionAddition']
                , 'IDRTargetAddition'                    => $EstimatedFinancialAddition['IDRTargetAddition']
                , 'ValasProjectionAddition'              => $EstimatedFinancialAddition['ValasProjectionAddition']
                , 'ValasTargetAddition'                  => $EstimatedFinancialAddition['ValasTargetAddition']
                , 'EstimatedFinancialAdditionSubmit'     => 'edit'
              );
            }
          }
        }


      }

    }
    else if ($BankFacilityGroupType == 'initiatives_action') {
      $data['AccountPlanningSubTab']        = $BankFacilityGroupType;
      $data['CustomerKorporasi']            = $this->PerformanceAccountPlanning_model->getCustomerByVCIF($VCIF);
      $data['CustomerName']                 = $data['CustomerKorporasi']['Name'];
      $data['VCIF']                         = $VCIF;
      $data['InitiativeActionSubmit']       = 'add';

      // Initiative Action
      $data['inputform']['InitiativeAction'][$VCIF] = $this->PerformanceAccountPlanning_model->getAccountPlanningInitiativeAction($AccountPlanningId, $VCIF);
      if (!empty($data['inputform']['InitiativeAction'][$VCIF])) {
        $data['InitiativeActionSubmit']       = 'edit';
      }

    }
    else if ($BankFacilityGroupType == 'fundings') {
      $data['AccountPlanningSubTab']        = $BankFacilityGroupType;
      $data['CustomerKorporasi']            = $this->PerformanceAccountPlanning_model->getCustomerByVCIF($VCIF);
      $data['CustomerName']                 = $data['CustomerKorporasi']['Name'];
      $data['VCIF']                         = $VCIF;
      $data['FundingSubmit']                = 'add';
      // Fundings
      $data['inputform']['Funding'][$VCIF] = $this->PerformanceAccountPlanning_model->getAccountPlanningFunding($AccountPlanningId, $VCIF);
      if (!empty($data['inputform']['Funding'][$VCIF])) {
        $data['FundingSubmit']       = 'edit';
      }
    }
    else if ($BankFacilityGroupType == 'services') {
      $data['AccountPlanningSubTab']        = $BankFacilityGroupType;
      $data['CustomerKorporasi']            = $this->PerformanceAccountPlanning_model->getCustomerByVCIF($VCIF);
      $data['CustomerName']                 = $data['CustomerKorporasi']['Name'];
      $data['VCIF']                         = $VCIF;
      $data['FundingSubmit']                = 'add';
      $data_uker_list = $this->MonitoringAccountPlanning_model->get_ukers();
      $data['inputform']['Service']['uker_list'][''] = '';
      foreach ($data_uker_list as $uker) {
        $data['inputform']['Service']['uker_list'][$uker['UnitKerjaId']] = $uker['Name'];
      }
      // services
      $dataService = $this->PerformanceAccountPlanning_model->getAccountPlanningService($AccountPlanningId, $VCIF);
      foreach ($dataService as $key => $value) {
        $TagServiceUnitKerja = $this->PerformanceAccountPlanning_model->getAccountPlanningServiceTag($value['ServiceId']);
        $TagServiceUnitKerjaId = array();
        foreach ($TagServiceUnitKerja as $keys => $values) {
          $TagServiceUnitKerjaId[$keys] = $values['UnitKerjaId'];
        }

        $data['inputform']['Service']['dataService'][] = array(
            'ServiceId'               => $value['ServiceId'],
            'ServiceName'             => $value['ServiceName'],
            'ServiceTarget'           => $value['Target'],
            'ServiceDescription'      => $value['Description'],
            'data_uker_list'          => $data_uker_list,
            'TagServiceUnitKerja'     => $TagServiceUnitKerja,
            'TagServiceUnitKerjaId'   => $TagServiceUnitKerjaId
            );
      }
    }
    else if($BankFacilityGroupType == "wallet_share"){
      $data['BankFacilityGroupType']                    = $BankFacilityGroupType;
      $data['BankFacilityGroupId']                      = $BankFacilityGroupId;
      $data['VCIF']                                     = $VCIF;
      $data['WalletSharesSubmit']                       = 'add';
      $dataBankFacilityItem = $this->TasklistAccountPlanning_model->getAccountPlanningBankFacilityItem($BankFacilityGroupId);      
      $data['BankFacilityGroupName']    = $dataBankFacilityItem[0]['BankFacilityGroupName'];

      foreach ($dataBankFacilityItem as $key => $value) {
        /* Wallet Share */
        /* Get Total Amount */
        $rsWalletShare = $this->PerformanceAccountPlanning_model->getAccountPlanningWalletShare($AccountPlanningId, $value['BankFacilityItemId'], $VCIF);
        if(!empty($rsWalletShare)){
          $totalAmount = $rsWalletShare[0]["TotalAmount"];
          $walletShareId = $rsWalletShare[0]["WalletShareId"];
          $walletShareSubmit = "edit";
        }else {
          $totalAmount = 0;
          $walletShareId = 0;
          $walletShareSubmit = "add";
        }
        /* Get IDR and Valas Amount From Facilities With Banking */
        $rsBankFacility = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacility($AccountPlanningId, $value['BankFacilityItemId'], $VCIF);
        if(!empty($rsBankFacility)){
          $IDRAmount = $rsBankFacility[0]["IDRAmount"];
          $ValasAmount = $rsBankFacility[0]["ValasAmount"];
          $BRINominal = $IDRAmount + $ValasAmount;
        }else {
          $BRINominal = 0;
        }
        /* Calculate Portion and Other Nominal */
        if($totalAmount == 0){
          $BRIPortion = 0;
          $OtherNominal = 0;
          $OtherPortion = 0;
        }else{
          if($BRINominal > $totalAmount){
            $OtherNominal = 0;
            $BRIPortion = 100;
            $OtherPortion = 0;
          }else{
            $OtherNominal = $totalAmount - $BRINominal;
            $BRIPortion = ($BRINominal/$totalAmount)*100;
            $OtherPortion = ($OtherNominal/$totalAmount)*100;
          }
        }
        
        //echo json_encode($rsBankFacility); die;
        $data['CompanyName'] = '';
        $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['WalletShares_detail'][$value['BankFacilityItemId']] = array(
          'WalletShareId'              => $walletShareId
          , 'BankFacilityItemId'        => $value['BankFacilityItemId']
          , 'BankFacilityItemName'      => $value['BankFacilityItemName']
          , 'BRINominal'                => number_format($BRINominal, 0)
          , 'BRIPortion'                => $BRIPortion
          , 'OtherNominal'              => number_format($OtherNominal, 0)
          , 'OtherPortion'              => $OtherPortion
          , 'TotalAmount'               => number_format($totalAmount, 0)
          , 'WalletShareSubmit'         => $walletShareSubmit
        );
      }

      //echo json_encode($data); die;

      /* Wallet Share Addition */
      $rsBankFacilityAddition = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $VCIF, $value['BankFacilityGroupId']);
      //echo json_encode($rsBankFacilityAddition); die;
      if (!empty($rsBankFacilityAddition)) {
        foreach ($rsBankFacilityAddition as $keyssss => $BankFacilityItemAddition) {
          $rsWalletShareAddition = $this->PerformanceAccountPlanning_model->getAccountPlanningWalletShareAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $VCIF);
          //echo json_encode($rsWalletShareAddition); die;
          if(!empty($rsWalletShareAddition)){
            $totalAmount = str_replace(',', '', $rsWalletShareAddition[0]["TotalAmountAddition"]);
            $walletShareId = str_replace(',', '', $rsWalletShareAddition[0]["WalletShareAdditionId"]);
            $walletShareSubmit = "edit";
          }else {
            $totalAmount = 0;
            $walletShareId = 0;
            $walletShareSubmit = "add";
          }
          $rsBankFacilityAddition = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $VCIF);
          if(!empty($rsBankFacilityAddition)){
            $IDRAmount = str_replace(',', '', $rsBankFacilityAddition[0]["IDRAmountAddition"]);
            $ValasAmount = str_replace(',', '', $rsBankFacilityAddition[0]["ValasAmountAddition"]);
            $BRINominal = $IDRAmount + $ValasAmount;
          }else {
            $BRINominal = 0;
          }
          if($totalAmount == 0){
            $BRIPortion = 0;
            $OtherNominal = 0;
            $OtherPortion = 0;
          }else{
            if($BRINominal > $totalAmount){
              $OtherNominal = 0;
              $BRIPortion = 100;
              $OtherPortion = 0;
            }else{
              $OtherNominal = $totalAmount - $BRINominal;
              $BRIPortion = ($BRINominal/$totalAmount)*100;
              $OtherPortion = ($OtherNominal/$totalAmount)*100;
            }
          }
          $data['inputform'][$BankFacilityGroupType][$value['BankFacilityGroupId']]['WalletSharesAddition_detail'][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
            'WalletShareAdditionId'              => $walletShareId
            , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
            , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
            , 'BRINominalAddition'                => number_format($BRINominal, 0)
            , 'BRIPortionAddition'                => $BRIPortion
            , 'OtherNominalAddition'              => number_format($OtherNominal, 0)
            , 'OtherPortionAddition'              => $OtherPortion
            , 'TotalAmountAddition'               => number_format($totalAmount, 0)
            , 'WalletShareSubmitAddition'         => $walletShareSubmit
          );
        }
      }
      //echo json_encode($rBankFacilityAddition); die;

      //echo json_encode($data); die;
    }

    else {
      $data['BankFacilityGroupType']    = $BankFacilityGroupType;
      $data['BankFacilityGroupId']      = $BankFacilityGroupId;
      $data['CompetitionAnalysisSubmit']                = 'add';

      $dataBankFacilityItem = $this->TasklistAccountPlanning_model->getAccountPlanningBankFacilityItem($BankFacilityGroupId);
      $dataBankList = $this->TasklistAccountPlanning_model->getBankList();
      foreach ($dataBankList as $keys => $values) {
        $dataBankLists[0] = 'Please Choose';
        $dataBankLists[$values['BankId']] = $values['Name'];
      }

      $data['BankFacilityGroupName']    = $dataBankFacilityItem[0]['BankFacilityGroupName'];

      foreach ($dataBankFacilityItem as $key => $value) {

        $dataCompetitionAnalysis[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountCompetitions($AccountPlanningId, $value['BankFacilityItemId']);

        $data['inputform'][$BankFacilityGroupType][$value['BankFacilityItemId']] = array(
          'BankFacilityItemId'          => $value['BankFacilityItemId']
          , 'CompetitionAnalysisId'     => 0
          , 'BankFacilityItemName'      => $value['BankFacilityItemName']
          , 'BankId1'                   => ''
          , 'BankId2'                   => ''
          , 'BankId3'                   => ''
          );

        if (is_array($dataCompetitionAnalysis[$value['BankFacilityGroupId']])) {
          $data['CompetitionAnalysisSubmit']                = 'edit';
          foreach ($dataCompetitionAnalysis as $keys => $values) {
            $data['inputform'][$BankFacilityGroupType][$value['BankFacilityItemId']] = array(
              'BankFacilityItemId'          => $value['BankFacilityItemId']
              , 'CompetitionAnalysisId'     => $values['CompetitionAnalysisId']
              , 'BankFacilityItemName'      => $value['BankFacilityItemName']
              , 'BankId1'                   => $values['BankId1']
              , 'BankId2'                   => $values['BankId2']
              , 'BankId3'                   => $values['BankId3']
              );
          }
        }

        $data['dataBankLists'][$value['BankFacilityItemId']][1] = form_dropdown('BankId['.$value['BankFacilityItemId'].'][1]', $dataBankLists,   $data['inputform'][$BankFacilityGroupType][$value['BankFacilityItemId']]['BankId1'], ' class="form-control col-md-7 col-xs-12"');
        $data['dataBankLists'][$value['BankFacilityItemId']][2] = form_dropdown('BankId['.$value['BankFacilityItemId'].'][2]', $dataBankLists,   $data['inputform'][$BankFacilityGroupType][$value['BankFacilityItemId']]['BankId2'], ' class="form-control col-md-7 col-xs-12"');
        $data['dataBankLists'][$value['BankFacilityItemId']][3] = form_dropdown('BankId['.$value['BankFacilityItemId'].'][3]', $dataBankLists,   $data['inputform'][$BankFacilityGroupType][$value['BankFacilityItemId']]['BankId3'], ' class="form-control col-md-7 col-xs-12"');

      }
    }

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/inputform/'.$BankFacilityGroupType.'.php', $data); 
    $this->load->view('layout/footer.php');
  }

  public function input($AccountPlanningId) {
    $this->checkModule();
    // $this->checkAPInputStatus($AccountPlanningId);
    // $this->checkOwner($AccountPlanningId);

    $ap_tab_get = ($this->uri->segment(5)) ? $this->uri->segment(5) : 'company_information';
    $ap_tab_subcontent_get = ($this->uri->segment(6)) ? $this->uri->segment(6) : '';

    $data['account_planning'] = $this->PerformanceAccountPlanning_model->getDetailPerformanceAccountPlanning($AccountPlanningId);
    $data['account_planning_vcif_list'] = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);

    $data['account_planning']['Clasifications'] = 'Gold';
    $data['account_planning']['AccountPlanningId'] = $AccountPlanningId;
    $data['account_planning']['KursUSD'] = $this->getKursUSD();
    $data['account_planning']['Years'] = Array(  
                                                date('Y') - 3,
                                                date('Y') - 2,
                                                date('Y') - 1
                                        );

    $data['account_planning']['backgroundColors'] = Array(
            // "",
            "#EBD618", 
            "#46CEB6", 
            "#9522F0", 
            "#1998DF", 
            "#F86D43", 
            "#FF62EF", 
            "#455C73", 
            "#9B59B6", 
            "#BDC3C7", 
            "#26B99A", 
            "#3498DB"
      );
    $data['account_planning']['hoverBackgroundColors'] = Array(
            // "",
            "#f3e672", 
            "#86dfcf", 
            "#b970f5", 
            "#75c3f0", 
            "#fa8d6b", 
            "#ff99f5", 
            "#34495E", 
            "#B370CF", 
            "#CFD4D8", 
            "#36CAAB", 
            "#49A9EA"
      );
    $ap_tabs = array (
        'company_information'
        , 'bri_starting_position'
        , 'client_needs'
        , 'action_plans'
        , 'cpa'
      );

    $ap_tab_contents = array (
        'financial_highlights'
        , 'facilities_banking'
        , 'wallet_share'
        , 'competition_analysis'
        , 'estimated_financial'
        , 'initiatives_action'
      );

    foreach ($ap_tabs as $ap_tabs_key => $ap_tabs_value) {
      $data['account_planning']['ap_tab'][$ap_tabs_value] = '';
      $data['account_planning']['ap_tab_content'][$ap_tabs_value] = '';
      if ($ap_tab_get == $ap_tabs_value) {
        $data['account_planning']['ap_tab'][$ap_tabs_value] = 'active';
        $data['account_planning']['ap_tab_content'][$ap_tabs_value] = ' active in';
      }
    }

    foreach ($ap_tab_contents as $ap_tab_contents_key => $ap_tab_contents_value) {
      $data['account_planning']['ap_tab_sub'][$ap_tab_contents_value] = '';
      $data['account_planning']['ap_tab_sub_content'][$ap_tab_contents_value] = '';
      if ($ap_tab_subcontent_get == $ap_tab_contents_value) {
        $data['account_planning']['ap_tab_sub'][$ap_tab_contents_value] = 'active';
        $data['account_planning']['ap_tab_sub_content'][$ap_tab_contents_value] = ' active in';
      }
      if (empty($ap_tab_subcontent_get)) {
        if ($ap_tab_contents_value == 'financial_highlights' || $ap_tab_contents_value == 'estimated_financial') {
          $data['account_planning']['ap_tab_sub'][$ap_tab_contents_value] = 'active';
          $data['account_planning']['ap_tab_sub_content'][$ap_tab_contents_value] = ' active in';
        }
      }
    }

    /* Start of Company Information Tab */
    $rsAssignedCompany = $this->TasklistAccountPlanning_model->getSelectedCompanyOption($AccountPlanningId);
    $data['account_planning']['AssignedCompany'] = $rsAssignedCompany;
    //$data['account_planning']['GroupOverview'] = $this->PerformanceAccountPlanning_model->getAccountPlanningGroupOverview($AccountPlanningId);

    $dataShareholder = $this->PerformanceAccountPlanning_model->getAccountPlanningShareholder($AccountPlanningId);
    $data['account_planning']['Shareholder'] = $dataShareholder;
    $totalPortionShareholder = 0;
    foreach($dataShareholder as $key => $value){
      $totalPortionShareholder += $value['Value'];
    }
    $data['account_planning']['totalPortionShareholder'] = $totalPortionShareholder;
    
    $arrColors = Array(
        "#EBD618", 
        "#46CEB6", 
        "#9522F0", 
        "#1998DF", 
        "#F86D43", 
        "#FF62EF", 
        "#455C73", 
        "#9B59B6", 
        "#BDC3C7", 
        "#26B99A", 
        "#3498DB"
    );
    $iShareholder = 0;
    $totalPortionShareholderPercentage = 0;
    foreach($dataShareholder as $key => $value){
      $data['account_planning']['Shareholder'][$iShareholder]['Color'] = $arrColors[$iShareholder];
      
      $portionPercentage = number_format(($value['Value'] / $totalPortionShareholder) * 100, 2);
      $data['account_planning']['Shareholder'][$iShareholder]['PortionPercentage'] = $portionPercentage;
      $totalPortionShareholderPercentage += $portionPercentage;
      $iShareholder++;
    }
    $data['account_planning']['totalPortionShareholderPercentage'] = $totalPortionShareholderPercentage;
    
    for($i=0; $i<count($rsAssignedCompany); $i++){
      $data['account_planning']['GroupOverview'][$i] = $this->TasklistAccountPlanning_model->getAccountPlanningGroupOverview($AccountPlanningId, $rsAssignedCompany[$i]->VCIF);
      $data['account_planning']['StrategicPlan'][$i] = $this->TasklistAccountPlanning_model->getAccountPlanningStrategicPlan($AccountPlanningId, $rsAssignedCompany[$i]->VCIF);
      $data['account_planning']['CoverageMapping'][$i] = $this->TasklistAccountPlanning_model->getAccountPlanningCoverageMapping($AccountPlanningId, $rsAssignedCompany[$i]->VCIF);
      
      /*
      $rsBusinessProcess = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1, $rsAssignedCompany[$i]->VCIF);
      $rsAssignedCompany[$i]->BusinessProcess = $rsBusinessProcess;
      
      $rsCompanyStructure = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3, $rsAssignedCompany[$i]->VCIF);
      $rsAssignedCompany[$i]->CompanyStructure = $rsCompanyStructure;
    
      */
      $data['account_planning']['FileStructure']['1'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1);
      $data['account_planning']['FileStructure']['2'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 2);
      $data['account_planning']['FileStructure']['3'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3);
    
    }

    $rsCSTMember = $this->TasklistAccountPlanning_model->getCSTMember($AccountPlanningId);
    $data['account_planning']['CSTMember'] = $rsCSTMember;
    
    /*
    $data['account_planning']['FileStructure']['1'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1, $rsAssignedCompany[$i]->VCIF);
    $data['account_planning']['FileStructure']['2'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 2);
    $data['account_planning']['FileStructure']['3'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3, $rsAssignedCompany[$i]->VCIF);
    */
    /* End of Company Information Tab */

    //echo json_encode($data); die();

    // GroupOverview
    //$data['account_planning']['GroupOverview'] = $this->PerformanceAccountPlanning_model->getAccountPlanningGroupOverview($AccountPlanningId);

    // Shareholder
    /*
    $dataShareholder = $this->PerformanceAccountPlanning_model->getAccountPlanningShareholder($AccountPlanningId);
    $data['account_planning']['Shareholder'] = $dataShareholder;
    foreach ($dataShareholder as $key => $value) {
      $data['account_planning']['Shareholder2']['labels'][] = $value['Name'];
      $data['account_planning']['Shareholder2']['Quantity'][] = $value['Quantity'];
      $data['account_planning']['Shareholder2']['values'][] = $value['Quantity'];
    }
    */

    // FinancialHighlight
    $FinancialHighlightItem = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlightItem();
    foreach ($FinancialHighlightItem as $key => $value) {
      $heading_panel = ' collapse';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $heading_panel = '';
      }
      $tab_panel = ' collapse';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $tab_panel = ' collapse in';
      }
      $expanded_panel = 'false';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $expanded_panel = 'true';
      }

      $dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlight($AccountPlanningId, $value['FinancialHighlightItemId']);

      $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']][0] = array(
        'FinancialHighlightGroupId'       => $value['FinancialHighlightGroupId']
        , 'FinancialHighlightGroupName'   => $value['FinancialHighlightGroupName']
        , 'heading_panel'                 => $heading_panel
        , 'tab_panel'                     => $tab_panel
        , 'expanded_panel'                => $expanded_panel
        );

      foreach ($data['account_planning']['Years'] as $keyss => $valuess) {
        if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
          $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][$valuess] = array(
              'FinancialHighlightId'            => 0
              , 'Amount'                        => 0
              , 'ChartAmount'                   => 0
              , 'Year'                          => $valuess
            );
        }
        else {
          $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$valuess] = array(
              'FinancialHighlightId'            => 0
              , 'Amount'                        => 0
              , 'ChartAmount'                   => 0
              , 'Year'                          => $valuess
            );
        }
      }
      if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
        $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][0] = array(
            'FinancialHighlightItemId'              => 0
            , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
          );
      }
      else {
        $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
            'FinancialHighlightItemId'              => 0
            , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
          );
      }

      if (is_array($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']])) {
        if ($value['FinancialHighlightGroupId'] == 3 || $value['FinancialHighlightGroupId'] == 4 || $value['FinancialHighlightGroupId'] == 5 || $value['FinancialHighlightGroupId'] == 6) {
          foreach ($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] as $keysss => $values) {
            $ChartAmount = str_replace(',', '', $values['Amount']);
              if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][0] = array(
                  'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
                  , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
                  );

                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][$values['Year']] = array(
                  'FinancialHighlightId'            => $values['FinancialHighlightId']
                  , 'Amount'                        => number_format($values['Amount']/VALUE_PER)
                  , 'ChartAmount'                   => $ChartAmount
                  , 'Year'                          => $values['Year']
                  );
              }
              else {
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
                  'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
                  , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
                  );
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$values['Year']] = array(
                  'FinancialHighlightId'            => $values['FinancialHighlightId']
                  , 'Amount'                        => number_format($values['Amount'])
                  , 'ChartAmount'                   => $values['Amount']
                  , 'Year'                          => $values['Year']
                  );
            }
          }
        }        
        else {
          foreach ($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] as $keysss => $values) {
            $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
              'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
              , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
              );
            $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$values['Year']] = array(
              'FinancialHighlightId'            => $values['FinancialHighlightId']
              , 'Amount'                        => number_format($values['Amount']/VALUE_PER)
              , 'ChartAmount'                   => $values['Amount']/VALUE_PER
              , 'Year'                          => $values['Year']
              );
          }
        }        
      }
    }

    $dataBankFacilityItem = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItem();
    foreach ($dataBankFacilityItem as $key => $value) {
      $heading_panel = ' collapse';
      if ($value['BankFacilityGroupId'] == 1) {
        $heading_panel = '';
      }
      $tab_panel = ' collapse';
      if ($value['BankFacilityGroupId'] == 1) {
        $tab_panel = ' collapse in';
      }
      $expanded_panel = 'false';
      if ($value['BankFacilityGroupId'] == 1) {
        $expanded_panel = 'true';
      }     

    // Facilities Banking
      $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      foreach ($data['account_planning_vcif_list'] as $keyss => $account_planning_vcif) {
        $dataBankFacility[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacility($AccountPlanningId, $value['BankFacilityItemId'], $account_planning_vcif['VCIF']);

        $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
          'BankFacilityId'          => 0
          , 'BankFacilityItemName'  => $value['BankFacilityItemName']
          , 'IDRAmount'             => 0
          , 'IDRRate'               => 0
          , 'ValasAmount'           => 0
          , 'ValasRate'             => 0
          );

        if (is_array($dataBankFacility[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']])) {
          foreach ($dataBankFacility[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] as $keys => $values) {
            $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
              'BankFacilityId'          => $values['BankFacilityId']
              , 'BankFacilityItemName'  => $values['BankFacilityItemName']
              , 'IDRAmount'             => number_format($values['IDRAmount']/VALUE_PER)
              , 'IDRRate'               => number_format($values['IDRRate'], 2)
              , 'ValasAmount'           => number_format($values['ValasAmount']/VALUE_PER)
              , 'ValasRate'             => number_format($values['ValasRate'], 2)
              );
          }
        }

      // facilities banking Addition
        $dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $account_planning_vcif['VCIF'], $value['BankFacilityGroupId']);


        if (isset($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']])) {
          foreach ($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] as $keyssss => $BankFacilityItemAddition) {
            $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                'BankFacilityAdditionId'              => 0
                , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
                , 'IDRAmountAddition'                 => 0
                , 'IDRRateAddition'                   => 0
                , 'ValasAmountAddition'               => 0
                , 'ValasRateAddition'                 => 0
                , 'BankFacilityAdditionSubmit'        => 'add'
              );

            $dataBankFacilityAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $account_planning_vcif['VCIF']);

            foreach ($dataBankFacilityAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] as $keysssss => $BankFacilityAddition) {
              $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                  'BankFacilityAdditionId'              => $BankFacilityAddition['BankFacilityAdditionId']
                  , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                  , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
                  , 'IDRAmountAddition'                 => number_format($BankFacilityAddition['IDRAmountAddition']/VALUE_PER)
                  , 'IDRRateAddition'                   => number_format($BankFacilityAddition['IDRRateAddition'], 2)
                  , 'ValasAmountAddition'               => number_format($BankFacilityAddition['ValasAmountAddition']/VALUE_PER)
                  , 'ValasRateAddition'                 => number_format($BankFacilityAddition['ValasRateAddition'], 2)
                  , 'BankFacilityAdditionSubmit'        => 'edit'
                );

            }

          }
        }

      }
     
    // Estimated Financial
      $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      foreach ($data['account_planning_vcif_list'] as $keyss => $account_planning_vcif) {
        $dataEstimatedFinancial[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningEstimatedFinancial($AccountPlanningId, $value['BankFacilityItemId'], $account_planning_vcif['VCIF']);

        $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
          'EstimatedFinancialId'        => 0
          , 'BankFacilityItemName'      => $value['BankFacilityItemName']
          , 'IDRProjection'             => 0
          , 'IDRTarget'                 => 0
          , 'IDRProgressBar'            => 0
          , 'IDRProgressValue'          => 0
          , 'ValasProjection'           => 0
          , 'ValasTarget'               => 0
          , 'ValasProgressBar'          => 0
          , 'ValasProgressValue'        => 0
          );

        if (isset($dataEstimatedFinancial[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']])) {
          foreach ($dataEstimatedFinancial[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] as $keys => $values) {
            $IDRProgressBar       = 0;
            $IDRProgressValue     = 0;
            $ValasProgressBar     = 0;
            $ValasProgressValue   = 0;

            if ($values['IDRProjection'] > $values['IDRTarget']) {
              $IDRProgressValue     = number_format(($values['IDRTarget'] / $values['IDRProjection']) * 100, 1);
              $IDRProgressBar       = $IDRProgressValue;
            }
            elseif ($values['IDRProjection'] < $values['IDRTarget']) {
              $IDRProgressValue     = 100;
              $IDRProgressBar       = 100;
            }
            if ($values['ValasProjection'] > $values['ValasTarget']) {
              $ValasProgressValue   = number_format(($values['ValasTarget'] / $values['ValasProjection']) * 100, 1);
              $ValasProgressBar     = $ValasProgressValue;
            }
            elseif ($values['ValasProjection'] < $values['ValasTarget']) {
              $ValasProgressValue   = 100;
              $ValasProgressBar     = 100;
            }
            $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
              'EstimatedFinancialId'          => $values['EstimatedFinancialId']
              , 'BankFacilityItemName'        => $value['BankFacilityItemName']
              , 'IDRProjection'               => number_format($values['IDRProjection']/VALUE_PER)
              , 'IDRTarget'                   => number_format($values['IDRTarget']/VALUE_PER)
              , 'IDRProgressBar'              => $IDRProgressBar
              , 'IDRProgressValue'            => $IDRProgressValue
              , 'ValasProjection'             => number_format($values['ValasProjection']/VALUE_PER)
              , 'ValasTarget'                 => number_format($values['ValasTarget']/VALUE_PER)
              , 'ValasProgressBar'            => $ValasProgressBar
              , 'ValasProgressValue'          => $ValasProgressValue
            );
          }
        }

      // Estimated Financial Addition
        $dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $account_planning_vcif['VCIF'], $value['BankFacilityGroupId']);


        if (isset($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']])) {
          foreach ($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] as $keyssss => $BankFacilityItemAddition) {

            $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancialAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
              'EstimatedFinancialAdditionId'         => 0
              , 'BankFacilityItemAdditionName'       => $BankFacilityItemAddition['BankFacilityItemAdditionName']
              , 'IDRProjectionAddition'              => 0
              , 'IDRTargetAddition'                  => 0
              , 'IDRProgressAdditionBar'             => 0
              , 'IDRProgressAdditionValue'           => 0
              , 'ValasProjectionAddition'            => 0
              , 'ValasTargetAddition'                => 0
              , 'ValasProgressAdditionBar'           => 0
              , 'ValasProgressAdditionValue'         => 0
              );

            $dataEstimatedFinancialAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningEstimatedFinancialAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $account_planning_vcif['VCIF']);

            foreach ($dataEstimatedFinancialAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] as $keysssss => $EstimatedFinancialAddition) {

              $IDRProgressAdditionBar       = 0;
              $IDRProgressAdditionValue     = 0;

              $ValasProgressAdditionBar     = 0;
              $ValasProgressAdditionValue   = 0;

                if ($EstimatedFinancialAddition['IDRProjectionAddition'] > $EstimatedFinancialAddition['IDRTargetAddition']) {
                  $IDRProgressAdditionValue     = number_format(($EstimatedFinancialAddition['IDRProjectionAddition'] / $EstimatedFinancialAddition['IDRTargetAddition']) * 100, 1);
                  $IDRProgressAdditionBar       = 100;
                }
                else if ($EstimatedFinancialAddition['IDRProjectionAddition'] < $EstimatedFinancialAddition['IDRTargetAddition']) {
                  $IDRProgressAdditionValue     = number_format(($EstimatedFinancialAddition['IDRProjectionAddition'] / $EstimatedFinancialAddition['IDRTargetAddition']) * 100, 1);
                  $IDRProgressAdditionBar       = $IDRProgressAdditionValue;
                }

                if ($EstimatedFinancialAddition['ValasProjectionAddition'] > $EstimatedFinancialAddition['ValasTargetAddition']) {
                  $ValasProgressAdditionValue   = number_format(($EstimatedFinancialAddition['ValasProjectionAddition'] / $EstimatedFinancialAddition['ValasTargetAddition']) * 100, 1);
                  $ValasProgressAdditionBar     = 100;
                }
                else if ($EstimatedFinancialAddition['ValasProjectionAddition'] < $EstimatedFinancialAddition['ValasTargetAddition']) {
                  $ValasProgressAdditionValue   = number_format(($EstimatedFinancialAddition['ValasProjectionAddition'] / $EstimatedFinancialAddition['ValasTargetAddition']) * 100, 1);
                  $ValasProgressAdditionBar     = $ValasProgressAdditionValue;
                }

              $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancialAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                'EstimatedFinancialAdditionId'          => $EstimatedFinancialAddition['EstimatedFinancialAdditionId']
                , 'BankFacilityItemAdditionName'        => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                , 'IDRProjectionAddition'               => number_format($EstimatedFinancialAddition['IDRProjectionAddition']/VALUE_PER)
                , 'IDRTargetAddition'                   => number_format($EstimatedFinancialAddition['IDRTargetAddition']/VALUE_PER)
                , 'IDRProgressAdditionBar'              => $IDRProgressAdditionBar
                , 'IDRProgressAdditionValue'            => $IDRProgressAdditionValue
                , 'ValasProjectionAddition'             => number_format($EstimatedFinancialAddition['ValasProjectionAddition']/VALUE_PER)
                , 'ValasTargetAddition'                 => number_format($EstimatedFinancialAddition['ValasTargetAddition']/VALUE_PER)
                , 'ValasProgressAdditionBar'            => $ValasProgressAdditionBar
                , 'ValasProgressAdditionValue'          => $ValasProgressAdditionValue
              );
            }
          }
        }

      }

      /* Start of Wallet Share */
      $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
      );

      foreach ($data['account_planning_vcif_list'] as $keyss => $account_planning_vcif) {
        $dataWalletShare[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningWalletShare($AccountPlanningId, $value['BankFacilityItemId'], $account_planning_vcif['VCIF']);
        $IDRAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']]['IDRAmount']);
        $ValasAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']]['ValasAmount']);
        $BRINominal = $IDRAmount + $ValasAmount;
        $OtherNominal = 0;
        $BRIPortion = 0;
        $OtherPortion = 0;
        $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShare_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
          'WalletShareId'           => 0
          , 'BankFacilityItemName'  => $value['BankFacilityItemName']
          , 'BRINominal'            => number_format($BRINominal,0)
          , 'BRIPortion'            => $BRIPortion
          , 'OtherNominal'          => number_format($OtherNominal,0)
          , 'OtherPortion'          => $OtherPortion
          , 'TotalAmount'           => 0
        );
        if (!empty($dataWalletShare[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']])) {
          foreach ($dataWalletShare[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] as $keys => $values) {
            $TotalAmount = $values['TotalAmount']/VALUE_PER;
            $IDRAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']]['IDRAmount']);
            $ValasAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']]['ValasAmount']);
            $BRINominal = $IDRAmount + $ValasAmount;

            if($TotalAmount == 0){
              $OtherNominal = 0;
              $BRIPortion = 0;
              $OtherPortion = 0;
            }else{
              if($BRINominal > $TotalAmount){
                $OtherNominal = 0;
                $BRIPortion = 100;
                $OtherPortion = 0;
              }else{
                $OtherNominal = $TotalAmount - $BRINominal;
                $BRIPortion = ($BRINominal/$TotalAmount)*100;
                $OtherPortion = ($OtherNominal/$TotalAmount)*100;
              }
            }

            $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShare_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
              'WalletShareId'           => $values['WalletShareId']
              , 'BankFacilityItemName'  => $value['BankFacilityItemName']
              , 'BRINominal'            => number_format($BRINominal,0)
              , 'BRIPortion'            => number_format($BRIPortion,2)
              , 'OtherNominal'          => number_format($OtherNominal,0)
              , 'OtherPortion'          => $OtherPortion
              , 'TotalAmount'           => number_format($TotalAmount,0)
            );
          }
        }
        
        // Wallet Share Addition
        $dataWalletShareAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $account_planning_vcif['VCIF'], $value['BankFacilityGroupId']);
        if (isset($dataWalletShareAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']])) {
          foreach ($dataWalletShareAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] as $keyssss => $BankFacilityItemAddition) {
            $IDRAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']]['IDRAmountAddition']);
            $ValasAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']]['ValasAmountAddition']);
            $BRINominal = $IDRAmount + $ValasAmount;
            $OtherNominal = 0;
            $BRIPortion = 0;
            $OtherPortion = 0;
        
            $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShareAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
              'WalletShareAdditionId'         => 0
            , 'BankFacilityItemAdditionName'  => $BankFacilityItemAddition['BankFacilityItemAdditionName']
            , 'BRINominalAddition'            => number_format($BRINominal,0)
            , 'BRIPortionAddition'            => $BRIPortion
            , 'OtherNominalAddition'          => number_format($OtherNominal,0)
            , 'OtherPortionAddition'          => $OtherPortion
            , 'TotalAmountAddition'           => 0
            );

            $dataWalletShareAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningWalletShareAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $account_planning_vcif['VCIF']);
            //echo json_encode($dataWalletShareAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] ); die;
            foreach ($dataWalletShareAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] as $keysssss => $WalletShareAddition) {
              $TotalAmount = $WalletShareAddition['TotalAmountAddition']/VALUE_PER;
              $IDRAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']]['IDRAmountAddition']);
              $ValasAmount = str_replace(',', '', $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']]['ValasAmountAddition']);
              $BRINominal = $IDRAmount + $ValasAmount;

              if($TotalAmount == 0){
                $OtherNominal = 0;
                $BRIPortion = 0;
                $OtherPortion = 0;
              }else{
                if($BRINominal > $TotalAmount){
                  $OtherNominal = 0;
                  $BRIPortion = 100;
                  $OtherPortion = 0;
                }else{
                  $OtherNominal = $TotalAmount - $BRINominal;
                  $BRIPortion = ($BRINominal/$TotalAmount)*100;
                  $OtherPortion = ($OtherNominal/$TotalAmount)*100;
                }
              }

              $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShareAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                'WalletShareAdditionId'         => $WalletShareAddition["WalletShareAdditionId"]
              , 'BankFacilityItemAdditionName'  => $BankFacilityItemAddition['BankFacilityItemAdditionName']
              , 'BRINominalAddition'            => number_format($BRINominal,0)
              , 'BRIPortionAddition'            => number_format($BRIPortion, 2)
              , 'OtherNominalAddition'          => number_format($OtherNominal,0)
              , 'OtherPortionAddition'          => $OtherPortion
              , 'TotalAmountAddition'           => number_format($TotalAmount,0)
              );
            }
          }
        }
      }
      /* End of Wallet Share */

    // competitionAnalys
      $dataCompetitionAnalysis[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountCompetitions($AccountPlanningId, $value['BankFacilityItemId']);
      $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']]['CompetitionAnalysis_detail'][$value['BankFacilityItemId']] = array(
        'CompetitionAnalysisId'        => 0
        , 'BankFacilityItemName'      => $value['BankFacilityItemName']
        , 'BankName1'                 => ''
        , 'BankName2'                 => ''
        , 'BankName3'                 => ''
        );

      if (is_array($dataCompetitionAnalysis[$value['BankFacilityGroupId']])) {
        foreach ($dataCompetitionAnalysis as $keys => $values) {
          $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']]['CompetitionAnalysis_detail'][$value['BankFacilityItemId']] = array(
            'CompetitionAnalysisId'       => $values['CompetitionAnalysisId']
            , 'BankFacilityItemName'      => $value['BankFacilityItemName']
            , 'BankName1'                 => $values['BankName1']
            , 'BankName2'                 => $values['BankName2']
            , 'BankName3'                 => $values['BankName3']
            );
        }
      }
    }

    if (!empty($data['account_planning_vcif_list'])) {
      foreach ($data['account_planning_vcif_list'] as $key => $valuess) {
      // Initiative Action
        $data['account_planning']['InitiativeAction'][$valuess['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningInitiativeAction($AccountPlanningId, $valuess['VCIF']);
        foreach ($data['account_planning']['InitiativeAction'][$valuess['VCIF']] as $keys => $values) {
          $dataDateTimePeriod[$keys]['DateTimePeriod'] = new DateTime(date($values['Period'].'-01'));
          $data['account_planning']['InitiativeAction'][$valuess['VCIF']][$keys]['DateTimePeriod'] = $dataDateTimePeriod[$keys]['DateTimePeriod']->format('F Y');
        }

        // Client Needs Funding
        $data['account_planning']['Funding'][$valuess['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningFunding($AccountPlanningId, $valuess['VCIF']);

        // Client Needs Service
        $dataService = $this->PerformanceAccountPlanning_model->getAccountPlanningService($AccountPlanningId, $valuess['VCIF']);
        foreach ($dataService as $key => $value) {
          $TagServiceUnitKerja = $this->PerformanceAccountPlanning_model->getAccountPlanningServiceTag($value['ServiceId']);
          $data['account_planning']['Service'][$valuess['VCIF']][] = array(
              'ServiceId'               => $value['ServiceId'],
              'ServiceName'             => $value['ServiceName'],
              'ServiceTarget'           => $value['Target'],
              'ServiceDescription'      => $value['Description'],
              'TagServiceUnitKerja'     => $TagServiceUnitKerja
              );
        }
      }
    }

    //echo json_encode($data); die;

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/account_planning_input.php', $data);
    $this->load->view('layout/footer.php');
  }

  public function detail($AccountPlanningId) {
    $this->checkModule();
    // $this->checkStatus($AccountPlanningId);
    // $this->checkOwner($AccountPlanningId);

    $ap_tab_get = ($this->uri->segment(5)) ? $this->uri->segment(5) : 'company_information';
    $ap_tab_subcontent_get = ($this->uri->segment(6)) ? $this->uri->segment(6) : '';

    $data['account_planning'] = $this->PerformanceAccountPlanning_model->getDetailPerformanceAccountPlanning($AccountPlanningId);
    $data['account_planning_vcif_list'] = $this->PerformanceAccountPlanning_model->getAccountPlanningVCIFList($AccountPlanningId);

    $data['account_planning']['Clasifications'] = 'Gold';
    $data['account_planning']['AccountPlanningId'] = $AccountPlanningId;
    $data['account_planning']['KursUSD'] = $this->getKursUSD();
    $data['account_planning']['Years'] = Array(  
                                                date('Y') - 3,
                                                date('Y') - 2,
                                                date('Y') - 1
                                        );

    $data['account_planning']['backgroundColors'] = Array(
            // "",
            "#EBD618", 
            "#46CEB6", 
            "#9522F0", 
            "#1998DF", 
            "#F86D43", 
            "#FF62EF", 
            "#455C73", 
            "#9B59B6", 
            "#BDC3C7", 
            "#26B99A", 
            "#3498DB"
      );
    $data['account_planning']['hoverBackgroundColors'] = Array(
            // "",
            "#f3e672", 
            "#86dfcf", 
            "#b970f5", 
            "#75c3f0", 
            "#fa8d6b", 
            "#ff99f5", 
            "#34495E", 
            "#B370CF", 
            "#CFD4D8", 
            "#36CAAB", 
            "#49A9EA"
      );
    $ap_tabs = array (
        'company_information'
        , 'bri_starting_position'
        , 'client_needs'
        , 'action_plans'
        , 'cpa'
      );

    $ap_tab_contents = array (
        'financial_highlights'
        , 'facilities_banking'
        , 'wallet_share'
        , 'competition_analysis'
        , 'estimated_financial'
        , 'initiatives_action'
      );

    foreach ($ap_tabs as $ap_tabs_key => $ap_tabs_value) {
      $data['account_planning']['ap_tab'][$ap_tabs_value] = '';
      $data['account_planning']['ap_tab_content'][$ap_tabs_value] = '';
      if ($ap_tab_get == $ap_tabs_value) {
        $data['account_planning']['ap_tab'][$ap_tabs_value] = 'active';
        $data['account_planning']['ap_tab_content'][$ap_tabs_value] = ' active in';
      }
    }

    foreach ($ap_tab_contents as $ap_tab_contents_key => $ap_tab_contents_value) {
      $data['account_planning']['ap_tab_sub'][$ap_tab_contents_value] = '';
      $data['account_planning']['ap_tab_sub_content'][$ap_tab_contents_value] = '';
      if ($ap_tab_subcontent_get == $ap_tab_contents_value) {
        $data['account_planning']['ap_tab_sub'][$ap_tab_contents_value] = 'active';
        $data['account_planning']['ap_tab_sub_content'][$ap_tab_contents_value] = ' active in';
      }
      if (empty($ap_tab_subcontent_get)) {
        if ($ap_tab_contents_value == 'financial_highlights' || $ap_tab_contents_value == 'estimated_financial') {
          $data['account_planning']['ap_tab_sub'][$ap_tab_contents_value] = 'active';
          $data['account_planning']['ap_tab_sub_content'][$ap_tab_contents_value] = ' active in';
        }
      }
    }

    /* Start of Company Information Tab */
    $rsAssignedCompany = $this->TasklistAccountPlanning_model->getSelectedCompanyOption($AccountPlanningId);
    $data['account_planning']['AssignedCompany'] = $rsAssignedCompany;
    //$data['account_planning']['GroupOverview'] = $this->PerformanceAccountPlanning_model->getAccountPlanningGroupOverview($AccountPlanningId);

    $dataShareholder = $this->PerformanceAccountPlanning_model->getAccountPlanningShareholder($AccountPlanningId);
    $data['account_planning']['Shareholder'] = $dataShareholder;
    $totalPortionShareholder = 0;
    foreach($dataShareholder as $key => $value){
      $totalPortionShareholder += $value['Value'];
    }
    $data['account_planning']['totalPortionShareholder'] = $totalPortionShareholder;
    
    $arrColors = Array(
        "#EBD618", 
        "#46CEB6", 
        "#9522F0", 
        "#1998DF", 
        "#F86D43", 
        "#FF62EF", 
        "#455C73", 
        "#9B59B6", 
        "#BDC3C7", 
        "#26B99A", 
        "#3498DB"
    );
    $iShareholder = 0;
    $totalPortionShareholderPercentage = 0;
    foreach($dataShareholder as $key => $value){
      $data['account_planning']['Shareholder'][$iShareholder]['Color'] = $arrColors[$iShareholder];
      
      $portionPercentage = number_format(($value['Value'] / $totalPortionShareholder) * 100, 2);
      $data['account_planning']['Shareholder'][$iShareholder]['PortionPercentage'] = $portionPercentage;
      $totalPortionShareholderPercentage += $portionPercentage;
      $iShareholder++;
    }
    $data['account_planning']['totalPortionShareholderPercentage'] = $totalPortionShareholderPercentage;
    
    for($i=0; $i<count($rsAssignedCompany); $i++){
      $data['account_planning']['GroupOverview'][$i] = $this->TasklistAccountPlanning_model->getAccountPlanningGroupOverview($AccountPlanningId, $rsAssignedCompany[$i]->VCIF);
      $data['account_planning']['StrategicPlan'][$i] = $this->TasklistAccountPlanning_model->getAccountPlanningStrategicPlan($AccountPlanningId, $rsAssignedCompany[$i]->VCIF);
      $data['account_planning']['CoverageMapping'][$i] = $this->TasklistAccountPlanning_model->getAccountPlanningCoverageMapping($AccountPlanningId, $rsAssignedCompany[$i]->VCIF);
      
      /*
      $rsBusinessProcess = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1, $rsAssignedCompany[$i]->VCIF);
      $rsAssignedCompany[$i]->BusinessProcess = $rsBusinessProcess;
      
      $rsCompanyStructure = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3, $rsAssignedCompany[$i]->VCIF);
      $rsAssignedCompany[$i]->CompanyStructure = $rsCompanyStructure;
    
      */
      $data['account_planning']['FileStructure']['1'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1);
      $data['account_planning']['FileStructure']['2'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 2);
      $data['account_planning']['FileStructure']['3'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3);
    
    }

    $rsCSTMember = $this->TasklistAccountPlanning_model->getCSTMember($AccountPlanningId);
    $data['account_planning']['CSTMember'] = $rsCSTMember;
    
    /*
    $data['account_planning']['FileStructure']['1'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1, $rsAssignedCompany[$i]->VCIF);
    $data['account_planning']['FileStructure']['2'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 2);
    $data['account_planning']['FileStructure']['3'] = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3, $rsAssignedCompany[$i]->VCIF);
    */
    /* End of Company Information Tab */

    //echo json_encode($data); die();

    // GroupOverview
    //$data['account_planning']['GroupOverview'] = $this->PerformanceAccountPlanning_model->getAccountPlanningGroupOverview($AccountPlanningId);

    // Shareholder
    /*
    $dataShareholder = $this->PerformanceAccountPlanning_model->getAccountPlanningShareholder($AccountPlanningId);
    $data['account_planning']['Shareholder'] = $dataShareholder;
    foreach ($dataShareholder as $key => $value) {
      $data['account_planning']['Shareholder2']['labels'][] = $value['Name'];
      $data['account_planning']['Shareholder2']['Quantity'][] = $value['Quantity'];
      $data['account_planning']['Shareholder2']['values'][] = $value['Quantity'];
    }
    */

    // FinancialHighlight
    $FinancialHighlightItem = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlightItem();
    foreach ($FinancialHighlightItem as $key => $value) {
      $heading_panel = ' collapse';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $heading_panel = '';
      }
      $tab_panel = ' collapse';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $tab_panel = ' collapse in';
      }
      $expanded_panel = 'false';
      if ($value['FinancialHighlightGroupId'] == 1) {
        $expanded_panel = 'true';
      }

      $dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningFinancialHighlight($AccountPlanningId, $value['FinancialHighlightItemId']);

      $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']][0] = array(
        'FinancialHighlightGroupId'       => $value['FinancialHighlightGroupId']
        , 'FinancialHighlightGroupName'   => $value['FinancialHighlightGroupName']
        , 'heading_panel'                 => $heading_panel
        , 'tab_panel'                     => $tab_panel
        , 'expanded_panel'                => $expanded_panel
        );

      foreach ($data['account_planning']['Years'] as $keyss => $valuess) {
        if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
          $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][$valuess] = array(
              'FinancialHighlightId'            => 0
              , 'Amount'                        => 0
              , 'ChartAmount'                   => 0
              , 'Year'                          => $valuess
            );
        }
        else {
          $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$valuess] = array(
              'FinancialHighlightId'            => 0
              , 'Amount'                        => 0
              , 'ChartAmount'                   => 0
              , 'Year'                          => $valuess
            );
        }
      }
      if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
        $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][0] = array(
            'FinancialHighlightItemId'              => 0
            , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
          );
      }
      else {
        $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
            'FinancialHighlightItemId'              => 0
            , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
          );
      }

      if (is_array($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']])) {
        if ($value['FinancialHighlightGroupId'] == 3 || $value['FinancialHighlightGroupId'] == 4 || $value['FinancialHighlightGroupId'] == 5 || $value['FinancialHighlightGroupId'] == 6) {
          foreach ($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] as $keysss => $values) {
            $ChartAmount = str_replace(',', '', $values['Amount']);
              if ($value['FinancialHighlightItemId'] == 14 || $value['FinancialHighlightItemId'] == 24 || $value['FinancialHighlightItemId'] == 25) {
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][0] = array(
                  'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
                  , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
                  );

                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details2'][$value['FinancialHighlightItemId']][$values['Year']] = array(
                  'FinancialHighlightId'            => $values['FinancialHighlightId']
                  , 'Amount'                        => number_format($values['Amount']/VALUE_PER)
                  , 'ChartAmount'                   => $ChartAmount
                  , 'Year'                          => $values['Year']
                  );
              }
              else {
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
                  'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
                  , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
                  );
                $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$values['Year']] = array(
                  'FinancialHighlightId'            => $values['FinancialHighlightId']
                  , 'Amount'                        => number_format($values['Amount'])
                  , 'ChartAmount'                   => $values['Amount']
                  , 'Year'                          => $values['Year']
                  );
            }
          }
        }        
        else {
          foreach ($dataFinancialHighlightItem[$value['FinancialHighlightGroupId']] as $keysss => $values) {
            $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][0] = array(
              'FinancialHighlightItemId'              => $value['FinancialHighlightItemId']
              , 'FinancialHighlightItemName'          => $value['FinancialHighlightItemName']
              );
            $data['account_planning']['FinancialHighlight'][$value['FinancialHighlightGroupId']]['FinancialHighlight_details'][$value['FinancialHighlightItemId']][$values['Year']] = array(
              'FinancialHighlightId'            => $values['FinancialHighlightId']
              , 'Amount'                        => number_format($values['Amount']/VALUE_PER)
              , 'ChartAmount'                   => $values['Amount']/VALUE_PER
              , 'Year'                          => $values['Year']
              );
          }
        }        
      }
    }

    $dataBankFacilityItem = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItem();
    foreach ($dataBankFacilityItem as $key => $value) {
      $heading_panel = ' collapse';
      if ($value['BankFacilityGroupId'] == 1) {
        $heading_panel = '';
      }
      $tab_panel = ' collapse';
      if ($value['BankFacilityGroupId'] == 1) {
        $tab_panel = ' collapse in';
      }
      $expanded_panel = 'false';
      if ($value['BankFacilityGroupId'] == 1) {
        $expanded_panel = 'true';
      }     

    // Facilities Banking
      $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      foreach ($data['account_planning_vcif_list'] as $keyss => $account_planning_vcif) {
        $dataBankFacility[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacility($AccountPlanningId, $value['BankFacilityItemId'], $account_planning_vcif['VCIF']);

        $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
          'BankFacilityId'          => 0
          , 'BankFacilityItemName'  => $value['BankFacilityItemName']
          , 'IDRAmount'             => 0
          , 'IDRRate'               => 0
          , 'ValasAmount'           => 0
          , 'ValasRate'             => 0
          );

        if (is_array($dataBankFacility[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']])) {
          foreach ($dataBankFacility[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] as $keys => $values) {
            $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['FacilitiesBanking_details'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
              'BankFacilityId'          => $values['BankFacilityId']
              , 'BankFacilityItemName'  => $values['BankFacilityItemName']
              , 'IDRAmount'             => number_format($values['IDRAmount']/VALUE_PER)
              , 'IDRRate'               => number_format($values['IDRRate'], 2)
              , 'ValasAmount'           => number_format($values['ValasAmount']/VALUE_PER)
              , 'ValasRate'             => number_format($values['ValasRate'], 2)
              );
          }
        }

      // facilities banking Addition
        $dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $account_planning_vcif['VCIF'], $value['BankFacilityGroupId']);


        if (isset($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']])) {
          foreach ($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] as $keyssss => $BankFacilityItemAddition) {
            $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                'BankFacilityAdditionId'              => 0
                , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
                , 'IDRAmountAddition'                 => 0
                , 'IDRRateAddition'                   => 0
                , 'ValasAmountAddition'               => 0
                , 'ValasRateAddition'                 => 0
                , 'BankFacilityAdditionSubmit'        => 'add'
              );

            $dataBankFacilityAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $account_planning_vcif['VCIF']);

            foreach ($dataBankFacilityAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] as $keysssss => $BankFacilityAddition) {
              $data['account_planning']['FacilitiesBanking'][$value['BankFacilityGroupId']]['BankFacilityAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                  'BankFacilityAdditionId'              => $BankFacilityAddition['BankFacilityAdditionId']
                  , 'BankFacilityItemAdditionName'      => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                  , 'BankFacilityItemAdditionId'        => $BankFacilityItemAddition['BankFacilityItemAdditionId']
                  , 'IDRAmountAddition'                 => number_format($BankFacilityAddition['IDRAmountAddition']/VALUE_PER)
                  , 'IDRRateAddition'                   => number_format($BankFacilityAddition['IDRRateAddition'], 2)
                  , 'ValasAmountAddition'               => number_format($BankFacilityAddition['ValasAmountAddition']/VALUE_PER)
                  , 'ValasRateAddition'                 => number_format($BankFacilityAddition['ValasRateAddition'], 2)
                  , 'BankFacilityAdditionSubmit'        => 'edit'
                );

            }

          }
        }

      }
     
    // Estimated Financial
      $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      foreach ($data['account_planning_vcif_list'] as $keyss => $account_planning_vcif) {
        $dataEstimatedFinancial[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningEstimatedFinancial($AccountPlanningId, $value['BankFacilityItemId'], $account_planning_vcif['VCIF']);

        $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
          'EstimatedFinancialId'        => 0
          , 'BankFacilityItemName'      => $value['BankFacilityItemName']
          , 'IDRProjection'             => 0
          , 'IDRTarget'                 => 0
          , 'IDRProgressBar'            => 0
          , 'IDRProgressValue'          => 0
          , 'ValasProjection'           => 0
          , 'ValasTarget'               => 0
          , 'ValasProgressBar'          => 0
          , 'ValasProgressValue'        => 0
          );

        if (isset($dataEstimatedFinancial[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']])) {
          foreach ($dataEstimatedFinancial[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] as $keys => $values) {
            $IDRProgressBar       = 0;
            $IDRProgressValue     = 0;
            $ValasProgressBar     = 0;
            $ValasProgressValue   = 0;

            if ($values['IDRProjection'] > $values['IDRTarget']) {
              $IDRProgressValue     = number_format(($values['IDRProjection'] / $values['IDRTarget']) * 100, 1);
              $IDRProgressBar       = 100;
            }
            else if ($values['IDRProjection'] < $values['IDRTarget']) {
              $IDRProgressValue     = number_format(($values['IDRProjection'] / $values['IDRTarget']) * 100, 1);
              $IDRProgressBar       = $IDRProgressValue;
            }
            if ($values['ValasProjection'] > $values['ValasTarget']) {
              $ValasProgressValue   = number_format(($values['ValasProjection'] / $values['ValasTarget']) * 100, 1);
              $ValasProgressBar     = 100;
            }
            else if ($values['ValasProjection'] < $values['ValasTarget']) {
              $ValasProgressValue   = number_format(($values['ValasProjection'] / $values['ValasTarget']) * 100, 1);
              $ValasProgressBar     = $ValasProgressValue;
            }
            $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancial_detail'][$account_planning_vcif['VCIF']][$value['BankFacilityItemId']] = array(
              'EstimatedFinancialId'          => $values['EstimatedFinancialId']
              , 'BankFacilityItemName'        => $value['BankFacilityItemName']
              , 'IDRProjection'               => number_format($values['IDRProjection']/VALUE_PER)
              , 'IDRTarget'                   => number_format($values['IDRTarget']/VALUE_PER)
              , 'IDRProgressBar'              => $IDRProgressBar
              , 'IDRProgressValue'            => $IDRProgressValue
              , 'ValasProjection'             => number_format($values['ValasProjection']/VALUE_PER)
              , 'ValasTarget'                 => number_format($values['ValasTarget']/VALUE_PER)
              , 'ValasProgressBar'            => $ValasProgressBar
              , 'ValasProgressValue'          => $ValasProgressValue
            );
          }
        }

      // Estimated Financial Addition
        $dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningBankFacilityItemsAddition($AccountPlanningId, $account_planning_vcif['VCIF'], $value['BankFacilityGroupId']);


        if (isset($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']])) {
          foreach ($dataBankFacilityItemAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']] as $keyssss => $BankFacilityItemAddition) {

            $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancialAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
              'EstimatedFinancialAdditionId'         => 0
              , 'BankFacilityItemAdditionName'       => $BankFacilityItemAddition['BankFacilityItemAdditionName']
              , 'IDRProjectionAddition'              => 0
              , 'IDRTargetAddition'                  => 0
              , 'IDRProgressAdditionBar'             => 0
              , 'IDRProgressAdditionValue'           => 0
              , 'ValasProjectionAddition'            => 0
              , 'ValasTargetAddition'                => 0
              , 'ValasProgressAdditionBar'           => 0
              , 'ValasProgressAdditionValue'         => 0
              );

            $dataEstimatedFinancialAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningEstimatedFinancialAddition($AccountPlanningId, $BankFacilityItemAddition['BankFacilityItemAdditionId'], $account_planning_vcif['VCIF']);

            foreach ($dataEstimatedFinancialAddition[$value['BankFacilityGroupId']][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] as $keysssss => $EstimatedFinancialAddition) {

              $IDRProgressAdditionBar       = 0;
              $IDRProgressAdditionValue     = 0;

              $ValasProgressAdditionBar     = 0;
              $ValasProgressAdditionValue   = 0;

                if ($EstimatedFinancialAddition['IDRProjectionAddition'] > $EstimatedFinancialAddition['IDRTargetAddition']) {
                  $IDRProgressAdditionValue     = number_format(($EstimatedFinancialAddition['IDRProjectionAddition'] / $EstimatedFinancialAddition['IDRTargetAddition']) * 100, 1);
                  $IDRProgressAdditionBar       = 100;
                }
                else if ($EstimatedFinancialAddition['IDRProjectionAddition'] < $EstimatedFinancialAddition['IDRTargetAddition']) {
                  $IDRProgressAdditionValue     = number_format(($EstimatedFinancialAddition['IDRProjectionAddition'] / $EstimatedFinancialAddition['IDRTargetAddition']) * 100, 1);
                  $IDRProgressAdditionBar       = $IDRProgressAdditionValue;
                }

                if ($EstimatedFinancialAddition['ValasProjectionAddition'] > $EstimatedFinancialAddition['ValasTargetAddition']) {
                  $ValasProgressAdditionValue   = number_format(($EstimatedFinancialAddition['ValasProjectionAddition'] / $EstimatedFinancialAddition['ValasTargetAddition']) * 100, 1);
                  $ValasProgressAdditionBar     = 100;
                }
                else if ($EstimatedFinancialAddition['ValasProjectionAddition'] < $EstimatedFinancialAddition['ValasTargetAddition']) {
                  $ValasProgressAdditionValue   = number_format(($EstimatedFinancialAddition['ValasProjectionAddition'] / $EstimatedFinancialAddition['ValasTargetAddition']) * 100, 1);
                  $ValasProgressAdditionBar     = $ValasProgressAdditionValue;
                }

              $data['account_planning']['EstimatedFinancial'][$value['BankFacilityGroupId']]['EstimatedFinancialAddition_detail'][$account_planning_vcif['VCIF']][$BankFacilityItemAddition['BankFacilityItemAdditionId']] = array(
                'EstimatedFinancialAdditionId'          => $EstimatedFinancialAddition['EstimatedFinancialAdditionId']
                , 'BankFacilityItemAdditionName'        => $BankFacilityItemAddition['BankFacilityItemAdditionName']
                , 'IDRProjectionAddition'               => number_format($EstimatedFinancialAddition['IDRProjectionAddition']/VALUE_PER)
                , 'IDRTargetAddition'                   => number_format($EstimatedFinancialAddition['IDRTargetAddition']/VALUE_PER)
                , 'IDRProgressAdditionBar'              => $IDRProgressAdditionBar
                , 'IDRProgressAdditionValue'            => $IDRProgressAdditionValue
                , 'ValasProjectionAddition'             => number_format($EstimatedFinancialAddition['ValasProjectionAddition']/VALUE_PER)
                , 'ValasTargetAddition'                 => number_format($EstimatedFinancialAddition['ValasTargetAddition']/VALUE_PER)
                , 'ValasProgressAdditionBar'            => $ValasProgressAdditionBar
                , 'ValasProgressAdditionValue'          => $ValasProgressAdditionValue
              );
            }
          }
        }

      }

    // Wallet Share
      $dataWalletShare[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountPlanningWalletShare($AccountPlanningId, $value['BankFacilityItemId']);

      $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShare_details'][$value['BankFacilityItemId']] = array(
        'WalletShareId'           => 0
        , 'BankFacilityItemName'  => $value['BankFacilityItemName']
        , 'BRINominal'            => 0
        , 'BRIPortion'            => 0
        , 'OtherNominal'          => 0
        , 'OtherPortion'          => 0
        , 'TotalAmount'           => 0
        );

      if (is_array($dataWalletShare[$value['BankFacilityGroupId']])) {
        foreach ($dataWalletShare[$value['BankFacilityGroupId']] as $keys => $values) {
          $data['account_planning']['WalletShare'][$value['BankFacilityGroupId']]['WalletShare_details'][$value['BankFacilityItemId']] = array(
            'WalletShareId'           => $values['WalletShareId']
            , 'BankFacilityItemName'  => $value['BankFacilityItemName']
            , 'BRINominal'            => number_format($values['BRINominal']/VALUE_PER)
            , 'BRIPortion'            => $values['BRIPortion']
            , 'OtherNominal'          => number_format($values['OtherNominal']/VALUE_PER)
            , 'OtherPortion'          => $values['OtherPortion']
            , 'TotalAmount'           => number_format($values['TotalAmount']/VALUE_PER)
            );
        }
      }

    // competitionAnalys
      $dataCompetitionAnalysis[$value['BankFacilityGroupId']] = $this->PerformanceAccountPlanning_model->getAccountCompetitions($AccountPlanningId, $value['BankFacilityItemId']);
      $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']][0] = array(
        'BankFacilityGroupId'     => $value['BankFacilityGroupId']
        , 'BankFacilityGroupName' => $value['BankFacilityGroupName']
        , 'heading_panel'         => $heading_panel
        , 'tab_panel'             => $tab_panel
        , 'expanded_panel'        => $expanded_panel
        );

      $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']]['CompetitionAnalysis_detail'][$value['BankFacilityItemId']] = array(
        'CompetitionAnalysisId'        => 0
        , 'BankFacilityItemName'      => $value['BankFacilityItemName']
        , 'BankName1'                 => ''
        , 'BankName2'                 => ''
        , 'BankName3'                 => ''
        );

      if (is_array($dataCompetitionAnalysis[$value['BankFacilityGroupId']])) {
        foreach ($dataCompetitionAnalysis as $keys => $values) {
          $data['account_planning']['CompetitionAnalysis'][$value['BankFacilityGroupId']]['CompetitionAnalysis_detail'][$value['BankFacilityItemId']] = array(
            'CompetitionAnalysisId'       => $values['CompetitionAnalysisId']
            , 'BankFacilityItemName'      => $value['BankFacilityItemName']
            , 'BankName1'                 => $values['BankName1']
            , 'BankName2'                 => $values['BankName2']
            , 'BankName3'                 => $values['BankName3']
            );
        }
      }
    }

    if (!empty($data['account_planning_vcif_list'])) {
      foreach ($data['account_planning_vcif_list'] as $key => $valuess) {
      // Initiative Action
        $data['account_planning']['InitiativeAction'][$valuess['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningInitiativeAction($AccountPlanningId, $valuess['VCIF']);
        foreach ($data['account_planning']['InitiativeAction'][$valuess['VCIF']] as $keys => $values) {
          $dataDateTimePeriod[$keys]['DateTimePeriod'] = new DateTime(date($values['Period'].'-01'));
          $data['account_planning']['InitiativeAction'][$valuess['VCIF']][$keys]['DateTimePeriod'] = $dataDateTimePeriod[$keys]['DateTimePeriod']->format('F Y');
        }

        // Client Needs Funding
        $data['account_planning']['Funding'][$valuess['VCIF']] = $this->PerformanceAccountPlanning_model->getAccountPlanningFunding($AccountPlanningId, $valuess['VCIF']);

        // Client Needs Service
        $dataService = $this->PerformanceAccountPlanning_model->getAccountPlanningService($AccountPlanningId, $valuess['VCIF']);
        foreach ($dataService as $key => $value) {
          $TagServiceUnitKerja = $this->PerformanceAccountPlanning_model->getAccountPlanningServiceTag($value['ServiceId']);
          $data['account_planning']['Service'][$valuess['VCIF']][] = array(
              'ServiceId'               => $value['ServiceId'],
              'ServiceName'             => $value['ServiceName'],
              'ServiceTarget'           => $value['Target'],
              'ServiceDescription'      => $value['Description'],
              'TagServiceUnitKerja'     => $TagServiceUnitKerja
              );
        }
      }
    }

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/account_planning_detail.php', $data);
    $this->load->view('layout/footer.php');
  }

  public function getKursUSD() {
    $url = "http://kurs.web.id/api/v1/bri";
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
    curl_setopt($ch, CURLOPT_HEADER, TRUE); 
    curl_setopt($ch, CURLOPT_NOBODY, TRUE); // remove body 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 

    $head = curl_exec($ch); 
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); 

    curl_error($ch);
    curl_close($ch); 

    // echo "14.934";    

  }

  public function retrieve($AccountPlanningId) {
    $this->checkModule();

    $data_input = array(
      'AccountPlanningId'     => $AccountPlanningId
      , 'DocumentStatusId'    => 1
      , 'CreatedDate'         => $this->current_datetime
      , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
    );

    $insertData = $this->TasklistAccountPlanning_model->insertData('AccountPlanningStatus', $data_input);
    
    $updateChecker = $this->TasklistAccountPlanning_model->updateData('AccountPlanningChecker', array('IsActive' => 0), 'AccountPlanningId', $AccountPlanningId);
    $updateSigner = $this->TasklistAccountPlanning_model->updateData('AccountPlanningSigner', array('IsActive' => 0), 'AccountPlanningId', $AccountPlanningId);

    // $deleteChecker = $this->TasklistAccountPlanning_model->deleteData('AccountPlanningChecker', array('AccountPlanningId' => $AccountPlanningId));
    // $deleteSigner = $this->TasklistAccountPlanning_model->deleteData('AccountPlanningSigner', array('AccountPlanningId' => $AccountPlanningId));

    echo json_encode($insertData);
  }

  public function add_member() {

    foreach ((array) $this->input->post('member_list') as $key => $value) {
      $insertMemberPerRM = $this->TasklistAccountPlanning_model->addMemberAccountPlanning($this->input->post('AccountPlanningId'), $value, $this->session->PERSONAL_NUMBER);
      if ($insertMemberPerRM['insertStatus'] == 'error') 
        break;    
    }

    foreach ((array) $this->input->post('member_selected_list') as $key => $value) {
      $removeMemberPerRM = $this->TasklistAccountPlanning_model->removeMemberAccountPlanning($this->input->post('AccountPlanningId'), $value, $this->session->PERSONAL_NUMBER);
      if ($removeMemberPerRM['removeStatus'] == 'error') 
        break;
    }

    if(isset($insertMemberPerRM) && isset($removeMemberPerRM))
      echo json_encode(array_merge($insertMemberPerRM,$removeMemberPerRM));
    else if(isset($insertMemberPerRM))
      echo json_encode($insertMemberPerRM);
    else if(isset($removeMemberPerRM))
      echo json_encode($removeMemberPerRM);
  }

  public function add_checkersigner() {

    $data_input = array(
      'AccountPlanningId'     => $this->input->post('AccountPlanningId')
      , 'DocumentStatusId'    => 2
      , 'CreatedDate'         => $this->current_datetime
      , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
    );

    $insertData = $this->TasklistAccountPlanning_model->insertData('AccountPlanningStatus', $data_input);

    foreach ($this->input->post('checker_per_uker_list') as $key => $value) {
      $data_inputChecker[$key] = array (
        'UserId'                => $value
        , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')
        , 'IsActive'            => 1
        , 'IsApproved'          => NULL
        , 'Comment'             => NULL
        , 'CreatedDate'         => $this->current_datetime
        , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
        );

      $insertCheckerPerRM = $this->TasklistAccountPlanning_model->insertCheckerSignerPerRM('AccountPlanningChecker', $data_inputChecker[$key]);
      if ($insertCheckerPerRM['status'] == 'error') 
        break;    
    }

    foreach ($this->input->post('signer_per_uker_list') as $key => $value) {
      $data_inputSigner[$key] = array (
        'UserId'                => $value
        , 'AccountPlanningId'   => $this->input->post('AccountPlanningId')
        , 'IsActive'            => 1
        , 'IsApproved'          => NULL
        , 'Comment'             => NULL
        , 'CreatedDate'         => $this->current_datetime
        , 'CreatedBy'           => $this->session->PERSONAL_NUMBER
        );

      $insertSignerPerRM = $this->TasklistAccountPlanning_model->insertCheckerSignerPerRM('AccountPlanningSigner', $data_inputSigner[$key]);
      if ($insertSignerPerRM['status'] == 'error') 
        break;    
    }

    // echo json_encode($insertCheckerPerRM);
    echo json_encode($insertSignerPerRM);
  }

  public function getMemberSelected($AccountPlanningId) {
    $result = $this->TasklistAccountPlanning_model->getMemberSelected($AccountPlanningId, $this->session->PERSONAL_NUMBER);
    echo json_encode($result);
  }

  public function getMemberList($AccountPlanningId) {
    $memberSelected = $this->TasklistAccountPlanning_model->getMemberSelected($AccountPlanningId, $this->session->PERSONAL_NUMBER);
    $result = $this->TasklistAccountPlanning_model->getMemberLists($memberSelected, $this->session->PERSONAL_NUMBER);
    echo json_encode($result);
  }

  public function getCheckerSelected($AccountPlanningId) {
    $result = $this->TasklistAccountPlanning_model->getCheckerSelected($AccountPlanningId, $this->session->PERSONAL_NUMBER);
    echo json_encode($result);
  }

  public function getChecker($AccountPlanningId) {
    $CheckerSelected = '';
    $CheckerSelected = $this->TasklistAccountPlanning_model->getCheckerSelected($AccountPlanningId, $this->session->PERSONAL_NUMBER);
    foreach ($CheckerSelected as $key => $value) {
        $CheckerSelected['UserId'][] = $value['UserId'];
    }
    $CheckerPerUnitKerjaList = $this->TasklistAccountPlanning_model->getChecker($this->session->DIVISION, $CheckerSelected);
    foreach ($CheckerPerUnitKerjaList as $key => $value) {
      $CheckerPerUnitKerjaList[$key]['Checkerchecked'] = '';
      if (!empty($CheckerSelected['UserId'])) {
        if (in_array($value['UserId'], $CheckerSelected['UserId'])) {
          $CheckerPerUnitKerjaList[$key]['Checkerchecked'] =  ' checked="checked"';
        }
      }
    }

    echo json_encode($CheckerPerUnitKerjaList);
  }

  public function getSignerSelected($AccountPlanningId) {
    $result = $this->TasklistAccountPlanning_model->getSignerSelected($AccountPlanningId, $this->session->PERSONAL_NUMBER);
    echo json_encode($result);
  }

  public function getSigner($AccountPlanningId) {
    $SignerSelected = '';
    $SignerSelected = $this->TasklistAccountPlanning_model->getSignerSelected($AccountPlanningId, $this->session->PERSONAL_NUMBER);
    foreach ($SignerSelected as $key => $value) {
        $SignerSelected['UserId'][] = $value['UserId'];
    }
    $SignerPerUnitKerjaList = $this->TasklistAccountPlanning_model->getSigner($this->session->DIVISION, $SignerSelected);
    foreach ($SignerPerUnitKerjaList as $key => $value) {
      $SignerPerUnitKerjaList[$key]['Signerchecked'] = '';
      if (!empty($SignerSelected['UserId'])) {
        if (in_array($value['UserId'], $SignerSelected['UserId'])) {
          $SignerPerUnitKerjaList[$key]['Signerchecked'] = ' checked="checked"';
        }
      }
    }

    echo json_encode($SignerPerUnitKerjaList);
  }

  /*
    Start Script From Irvan 
  */
  public function upload_businessprocessorganitation($accountPlanningId){
		$user = $this->session->all_userdata();
    $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
    $structureTypeId = $this->input->post('structureTypeId');
    
    $base_path = './uploads/account_planning';
		
    switch($structureTypeId){
      case 1: 
        $vcif = $this->input->post('vcif');
        $fname = 'Business_Process_'.$vcif.'.'.$ext;
        if( is_dir($base_path.'/'.$accountPlanningId.'/'.$vcif.'/') === false )
        {
          mkdir($base_path.'/'.$accountPlanningId.'/'.$vcif.'/', 0755, true);
        }
        $full_path = $base_path.'/'.$accountPlanningId.'/'.$vcif.'/';
        break;
      case 2: 
        $vcif = NULL;
        $fname = 'Group_Structure.'.$ext;
        if( is_dir($base_path.'/'.$accountPlanningId) === false )
        {
          mkdir($base_path.'/'.$accountPlanningId, 0755, true);
        }
        $full_path = $base_path.'/'.$accountPlanningId.'/';
        break;
      case 3: 
        $vcif = $this->input->post('vcif');
        $fname = 'Company_Structure_'.$vcif.'.'.$ext;
        if( is_dir($base_path.'/'.$accountPlanningId.'/'.$vcif.'/') === false )
        {
          mkdir($base_path.'/'.$accountPlanningId.'/'.$vcif.'/', 0755, true);
        }
        $full_path = $base_path.'/'.$accountPlanningId.'/'.$vcif.'/';
        break;
    }
    
		$config['upload_path'] = $full_path;
    $config['allowed_types'] = '*';
    $config['file_name'] = $fname;
    $config['max_filename'] = '255';
    $config['encrypt_name'] = false;
    $config['max_size'] = '';
    $config['overwrite'] = TRUE;
		$status = "";
		$msg = "";
		
		if (isset($_FILES['file']['name'])) {
			if (0 < $_FILES['file']['error']) {
				$status = "error";
				$code = $_FILES['file']['error'];
        switch ($code) {
            case 1:
                $msg = "The uploaded file exceeds the upload_max_filesize directive in php.ini";
                break;
            case 2:
                $msg = "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form";
                break;
            case 3:
                $msg = "The uploaded file was only partially uploaded";
                break;
            case 4:
                $msg = "No file was uploaded";
                break;
            case 6:
                $msg = "Missing a temporary folder";
                break;
            case 7:
                $msg = "Failed to write file to disk";
                break;
            case 8:
                $msg = "File upload stopped by extension";
                break;

            default:
                $msg = "Unknown upload error";
                break;
        }		
      }else{
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if (!$this->upload->do_upload('file')) {
          $status = "error";
          $msg = $this->upload->display_errors('', '');
        } else {
          
          $data = array(
            'StructureTypeId' => $structureTypeId,
            'AccountPlanningId' => $accountPlanningId,
            'VCIF' => $vcif,
            'FilePath' => $fname,
            'Size' => $_FILES['file']['size'], // as Bytes
            'Type' => $_FILES['file']['type'],
            'createdBy' => $user['PERSONAL_NUMBER']
          );
          if($this->TasklistAccountPlanning_model->uploadBusinessProcessOrganization($data)){
            $status = "success";
            $msg = "File successfully uploaded";
          }else{
            $status = "error";
            $msg = "Something went wrong when saving the file, please try again.";	
          }
        }
      }
    }else {
      $status = "error";
      $msg = 'Please choose a file';
    }
		echo json_encode(array('status' => $status, 'msg' => $msg));
	}
  public function editbusinessprocessorganisation($AccountPlanningId, $AccountPlanningTab){
    $data['AccountPlanningId'] = $AccountPlanningId;
    $data['AccountPlanningTab'] = $AccountPlanningTab;

    $rsGroupStructure = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 2);
    $data['GroupStructure'] = $rsGroupStructure;
    
    $rsAssignedCompany = $this->TasklistAccountPlanning_model->getSelectedCompanyOption($AccountPlanningId);
    for($i=0; $i<count($rsAssignedCompany); $i++){
      $rsBusinessProcess = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 1, $rsAssignedCompany[$i]->VCIF);
      $rsAssignedCompany[$i]->BusinessProcess = $rsBusinessProcess;

      $rsCompanyStructure = $this->TasklistAccountPlanning_model->getAccountPlanningFileStructure($AccountPlanningId, 3, $rsAssignedCompany[$i]->VCIF);
      $rsAssignedCompany[$i]->CompanyStructure = $rsCompanyStructure;
    }
    $data['AssignedCompany'] = $rsAssignedCompany;
    //echo json_encode($data); die;

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/editform/business_process_organitation', $data); 
    $this->load->view('layout/footer.php');
  }
  public function proses_editcoveragemapping($AccountPlanningId){
    $this->checkModule();
    $user = $this->session->all_userdata();
    $vcif = $this->input->post('vcif');
    $jumlahCoverageMapping = $this->input->post('jumlahCoverageMapping');
    $dataCoverageMapping = explode(',',$this->input->post('dataCoverageMapping'));
    
    $arrCoverageMapping = array();
    foreach($dataCoverageMapping as $row){
      $coverageMapping = array(
        'ClientName' => $this->input->post('client_name_'.$row),
        'ContactNumber' => $this->input->post('client_contact_'.$row),
        'ClientPosition' => $this->input->post('client_position_'.$row),
        'BankPerson' => $this->input->post('bank_person_name_'.$row),
        'BankContact' => $this->input->post('bank_contact_'.$row),
        'BankPosition' => $this->input->post('bank_position_'.$row),
        'OtherInformation' => $this->input->post('other_information_'.$row)          
      );
      array_push($arrCoverageMapping, $coverageMapping);
    }
    
    $data = array(
      'accountPlanningId' => $AccountPlanningId,
      'vcif' => $vcif,
      'jumlahCoverageMapping' => $jumlahCoverageMapping,
      'arrCoverageMapping' => $arrCoverageMapping,
      'createdBy' => $user['PERSONAL_NUMBER']
    );
    //echo json_encode($data); die;
    $this->TasklistAccountPlanning_model->updateCoverageMapping($data);
    redirect('tasklist/AccountPlanning/input/'.$AccountPlanningId); 
  }
  public function editcoveragemapping($AccountPlanningId, $AccountPlanningTab, $VCIF){
    $this->checkModule();

    $data['AccountPlanningId'] = $AccountPlanningId;
    $data['AccountPlanningTab'] = $AccountPlanningTab;
    $data['VCIF'] = $VCIF;

    $rsCompany = $this->TasklistAccountPlanning_model->getCompanyInformation($VCIF);
    $data['CompanyInformation'] = $rsCompany;

    $rsCoverageMapping = $this->TasklistAccountPlanning_model->getAccountPlanningCoverageMapping($AccountPlanningId, $VCIF);
    $data['CoverageMapping'] = $rsCoverageMapping;
    //echo json_encode($rsCoverageMapping); die;

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/editform/coverage_mapping', $data); 
    $this->load->view('layout/footer.php');
  }
  public function proses_editstrategicplan($AccountPlanningId){
    $this->checkModule();
    $user = $this->session->all_userdata();
    $vcif = $this->input->post('vcif');
    $jumlahStrategicPlan = $this->input->post('jumlahStrategicPlan');
    $dataStrategicPlan = explode(',',$this->input->post('dataStrategicPlan'));
    
    $arrStrategicPlan = array();
    foreach($dataStrategicPlan as $row){
      $name = trim($this->input->post('name_'.$row));
      if($name != ""){
        $strategicPlan = array(
          'StrategicPlanTypeId' => $this->input->post('type_'.$row),
          'Name' => $this->input->post('name_'.$row)
        );
        array_push($arrStrategicPlan, $strategicPlan);
      }     
    }
    
    $data = array(
      'accountPlanningId' => $AccountPlanningId,
      'vcif' => $vcif,
      'jumlahStrategicPlan' => count($arrStrategicPlan),
      'arrStrategicPlan' => $arrStrategicPlan,
      'createdBy' => $user['PERSONAL_NUMBER']
    );
    //echo json_encode($data); die;
    $this->TasklistAccountPlanning_model->updateStrategicPlan($data);
    redirect('tasklist/AccountPlanning/input/'.$AccountPlanningId); 
  }
  public function editstrategicplan($AccountPlanningId, $AccountPlanningTab, $VCIF){
    $this->checkModule();

    $data['AccountPlanningId'] = $AccountPlanningId;
    $data['AccountPlanningTab'] = $AccountPlanningTab;
    $data['VCIF'] = $VCIF;

    $rsCompany = $this->TasklistAccountPlanning_model->getCompanyInformation($VCIF);
    $data['CompanyInformation'] = $rsCompany;

    $rsStrategicPlanType = $this->TasklistAccountPlanning_model->getStrategicPlanTypeOption();
    $data['StrategicPlanTypeOption'] = $rsStrategicPlanType;
    
    $rsStrategicPlan = $this->TasklistAccountPlanning_model->getAccountPlanningStrategicPlan($AccountPlanningId, $VCIF);
    $data['StrategicPlan'] = $rsStrategicPlan;

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/editform/strategic_plan', $data); 
    $this->load->view('layout/footer.php');
  }
  public function proses_editkeyshareholders($AccountPlanningId){
    $this->checkModule();
    $user = $this->session->all_userdata();
    $dataShareholders = explode(',',$this->input->post('arrShareholders'));
    $arrShareholders = array();
    
    foreach($dataShareholders as $row){
      $shareholders = array(
          'Name' => $this->input->post('name_'.$row),
          'Value' => str_replace(",","",$this->input->post('value_'.$row))
      );
      array_push($arrShareholders, $shareholders);
    }  
    
    $data = array(
      'accountPlanningId' => $AccountPlanningId,
      'jumlahShareholders' => count($arrShareholders),
      'arrShareholders' => $arrShareholders,
      'createdBy' => $user['PERSONAL_NUMBER']
    );
    $this->TasklistAccountPlanning_model->updateShareholders($data);
    redirect('tasklist/AccountPlanning/input/'.$AccountPlanningId); 
  }
  public function editkeyshareholders($AccountPlanningId, $AccountPlanningTab){
    $this->checkModule();

    $data['AccountPlanningId'] = $AccountPlanningId;
    $data['AccountPlanningTab'] = $AccountPlanningTab;

    $rsShareholder = $this->PerformanceAccountPlanning_model->getAccountPlanningShareholder($AccountPlanningId);
    for($i=0; $i<count($rsShareholder); $i++){
      $rsShareholder[$i]['Value'] =  round($rsShareholder[$i]['Value'],0);
    }
    $data['Shareholder'] = $rsShareholder;

    //echo json_encode($rsShareholder); die;

    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/editform/key_shareholders', $data); 
    $this->load->view('layout/footer.php');
  }
  public function proses_editgroupoverview(){
    $this->checkModule();
    $user = $this->session->all_userdata();
    $accountPlanningId = $this->input->post('account_planning_id');

    $data = array(
      'accountPlanningId' => $accountPlanningId,
      'VCIF' => $this->input->post('vcif'),
      'address' => $this->input->post('address'),
      'provinceId' => $this->input->post('city'),
      'globalRatingId' => $this->input->post('global_ratings'),
      'domesticRatingId' => $this->input->post('domestic_ratings'),
      'industry' => $this->input->post('industry'),
      'industryTrendId' => $this->input->post('industry_trend'),
      'lifeCycleId' => $this->input->post('life_cycle'),
      'createdBy' => $user['PERSONAL_NUMBER']
    );

    $this->TasklistAccountPlanning_model->updateGroupOverview($data);
    redirect('tasklist/AccountPlanning/input/'.$accountPlanningId);
  }
  public function editgroupoverview($AccountPlanningId, $AccountPlanningTab, $VCIF) {
    $this->checkModule();

    $data['AccountPlanningId'] = $AccountPlanningId;
    $data['AccountPlanningTab'] = $AccountPlanningTab;
    $data['VCIF'] = $VCIF;

    $CustomerName = $this->TasklistAccountPlanning_model->getCustomerInformation($VCIF);
    $data['CustomerName'] = $CustomerName;

    $rsCity = $this->TasklistAccountPlanning_model->getCityOption();
    $data['CityOption'] = $rsCity;

    $rsGlobalRating = $this->TasklistAccountPlanning_model->getGlobalRatingOption();
    $data['GlobalRatingOption'] = $rsGlobalRating;

    $defaultGlobalRatingDescription = $this->TasklistAccountPlanning_model->getGlobalRatingDescription($rsGlobalRating[0]->GlobalRatingId);
    $data['defaultGlobalRatingDescription'] = $defaultGlobalRatingDescription;

    $rsDomesticRating = $this->TasklistAccountPlanning_model->getDomesticRatingOption();
    $data['DomesticRatingOption'] = $rsDomesticRating;

    $rsIndustryTrend = $this->TasklistAccountPlanning_model->getIndustryTrendOption();
    $data['IndustryTrendOption'] = $rsIndustryTrend;

    $rsLifeCycle = $this->TasklistAccountPlanning_model->getLifeCycleOption();
    $data['LifeCycleOption'] = $rsLifeCycle;

    $rsGroupOverview = $this->TasklistAccountPlanning_model->getGroupOverviewInformation($VCIF);
    $data['GroupOverview'] = $rsGroupOverview;

    //echo json_encode($data); die;
    
    $this->load->view('layout/header.php');
    $this->load->view('layout/side-nav.php');
    $this->load->view('layout/top-nav.php');
    $this->load->view('tasklist/editform/group_overview', $data); 
    $this->load->view('layout/footer.php');
  }
  public function serviceGetGlobalRatingDescription($globalRatingId){
    $user = $this->session->all_userdata();
    if(empty($user['USER_ID'])) redirect('logins');
    $result = $this->TasklistAccountPlanning_model->getGlobalRatingDescription($globalRatingId);
    echo json_encode($result);
  }
  /*
    End Script From Irvan
  */
}

?>
