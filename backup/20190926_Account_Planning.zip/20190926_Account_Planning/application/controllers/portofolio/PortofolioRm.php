<?php
    class PortofolioRm Extends MY_Controller {

        function __construct() {
            parent::__construct();
            $this->load->helper(array(
                "form",
                "url",
                "security"
            ));
            $this->load->library(array(
                "session",
                "form_validation",
                "pagination"
            ));
            $this->load->model("PortofolioRm_model");
        }

        public function index(){
            $this->checkModule();
            $data = array();
            if($this->input->post()){
                $keyword = $this->input->post("keyword");
            }else{
                $keyword = NULL;
            }
            $data["keyword"] = $keyword;
            
            $arrColors = Array(
                "#EBD618", 
                "#46CEB6", 
                "#9522F0", 
                "#1998DF", 
                "#F86D43", 
                "#FF62EF", 
                "#455C73", 
                "#9B59B6", 
                "#BDC3C7", 
                "#26B99A", 
                "#3498DB"
            );

            /* Config X Axis For 3 Months Backward */
            for($i = 1; $i <= 3; $i++) {
                $arrayMonth[] = date("Y-m", strtotime( date( 'Y-m-01' )." -$i months"));
            }
            for($x = count($arrayMonth); $x >= 1; $x--){
                $i = $x - 1;
                $arrayMonths[] = date("Y-m", strtotime($arrayMonth[$i]));
                $arrayMonthLabel[] = date("F Y", strtotime($arrayMonth[$i]));
            }

            $totalRecords = count($this->PortofolioRm_model->getTotalCustomerPortofolioRm($this->session->PERSONAL_NUMBER, $keyword));

            $limitPage = 3;
            $rowNo = 0;
            $rsCustomerPortofolioRm = $this->PortofolioRm_model->getCustomerPortofolioRm($this->session->PERSONAL_NUMBER, $limitPage, $rowNo, $keyword);
            $iPortofolioHeader = 0;
            foreach($rsCustomerPortofolioRm as $rowCustomerPortofolioRm){
                $cif = $rowCustomerPortofolioRm->Cif;
                $rsRekeningPortofolioRm = $this->PortofolioRm_model->getRekeningPortofolioRm($cif);
                $iRekeningPortofolioRm = 0;
                foreach($rsRekeningPortofolioRm as $rowRekeningPortofolioRm){
                    $noRek = $rowRekeningPortofolioRm->RekNo;
                    
                    /* Get Latest Status For Each Rekening */
                    $rsLatestStatusRekeningPortofolioRm = $this->PortofolioRm_model->getLatestStatusRekeningPortofolioRm($noRek);
                    $rowRekeningPortofolioRm->Fasilitas = $rsLatestStatusRekeningPortofolioRm->Fasilitas;
                    $rowRekeningPortofolioRm->Plafond = $rsLatestStatusRekeningPortofolioRm->Plafond;
                    $rowRekeningPortofolioRm->Ews = $rsLatestStatusRekeningPortofolioRm->Ews;
                    $rowRekeningPortofolioRm->Kolektibilitas = $rsLatestStatusRekeningPortofolioRm->Kolektibilitas;
                    $rowRekeningPortofolioRm->ProdukPinjaman = $rsLatestStatusRekeningPortofolioRm->Produk;
                    $rowRekeningPortofolioRm->FlagRestruct = $rsLatestStatusRekeningPortofolioRm->IsRestruct;
                    $rowRekeningPortofolioRm->JatuhTempo = $rsLatestStatusRekeningPortofolioRm->DueDate;

                    /* Config Y Axis For 3 Months Backward */
                    $arrOutstandingPortofolioRm = array();
                    foreach($arrayMonths as $rowMonth):
                        $rsOutstandingPortofolioRm = $this->PortofolioRm_model->getOutstandingPortofolioRm($noRek, $rowMonth);
                        if(!empty($rsOutstandingPortofolioRm))
                            $arrOutstandingPortofolioRm[] = $rsOutstandingPortofolioRm[0]->Outstanding;
                        else
                            $arrOutstandingPortofolioRm[] = 0;
                    endforeach;
                    $rowRekeningPortofolioRm->color = $arrColors[$iRekeningPortofolioRm];
                    $rowRekeningPortofolioRm->datasets = $arrOutstandingPortofolioRm;
                    $iRekeningPortofolioRm++;
                }
                $rowCustomerPortofolioRm->labels = $arrayMonthLabel;
                $rowCustomerPortofolioRm->Rekening = $rsRekeningPortofolioRm;                
            }

            $data["PortofolioRm"] = $rsCustomerPortofolioRm;
            
            $config['base_url'] = base_url().'portofolio/portofolioRm/page';
            $config['use_page_numbers'] = TRUE;
            $config['total_rows'] = $totalRecords;
            $config['per_page'] = $limitPage;
            $config["uri_segment"] = 3;
            $config['full_tag_open'] = '<ul class="pagination">';
            $config['full_tag_close'] = '</ul>';
            $config['num_tag_open'] = '<li class="page-item">';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
            $config['cur_tag_close'] = '</a></li>';
            $config['next_tag_open'] = '<li class="page-item">';
            $config['next_tagl_close'] = '</a></li>';
            $config['prev_tag_open'] = '<li class="page-item">';
            $config['prev_tagl_close'] = '</li>';
            $config['first_tag_open'] = '<li class="page-item ">';
            $config['first_tagl_close'] = '</li>';
            $config['last_tag_open'] = '<li class="page-item">';
            $config['last_tagl_close'] = '</a></li>';
            $config['attributes'] = array('class' => 'page-link');

            $this->pagination->initialize($config);
            $data["links"] = $this->pagination->create_links();

            //echo json_encode($data); die;

            $this->load->view("layout/header.php");
            $this->load->view("layout/side-nav.php");
            $this->load->view("layout/top-nav.php");
            $this->load->view("portofolio/portofolio_rm.php", $data);
            $this->load->view("layout/footer.php");
        }

        public function page($rowNo = 1){
            $this->checkModule();
            $data = array();
            if($this->input->post()){
                $keyword = $this->input->post("keyword");
            }else{
                $keyword = NULL;
            }
            $data["keyword"] = $keyword;
            
            $arrColors = Array(
                "#EBD618", 
                "#46CEB6", 
                "#9522F0", 
                "#1998DF", 
                "#F86D43", 
                "#FF62EF", 
                "#455C73", 
                "#9B59B6", 
                "#BDC3C7", 
                "#26B99A", 
                "#3498DB"
            );

            /* Config X Axis For 3 Months Backward */
            for($i = 1; $i <= 3; $i++) {
                $arrayMonth[] = date("Y-m", strtotime( date( 'Y-m-01' )." -$i months"));
            }
            for($x = count($arrayMonth); $x >= 1; $x--){
                $i = $x - 1;
                $arrayMonths[] = date("Y-m", strtotime($arrayMonth[$i]));
                $arrayMonthLabel[] = date("F Y", strtotime($arrayMonth[$i]));
            }

            $totalRecords = count($this->PortofolioRm_model->getTotalCustomerPortofolioRm($this->session->PERSONAL_NUMBER, $keyword));

            $limitPage = 3;
            $rowNo = ($rowNo-1) * $limitPage;
            $rsCustomerPortofolioRm = $this->PortofolioRm_model->getCustomerPortofolioRm($this->session->PERSONAL_NUMBER, $limitPage, $rowNo, $keyword);
            $iPortofolioHeader = 0;
            foreach($rsCustomerPortofolioRm as $rowCustomerPortofolioRm){
                $cif = $rowCustomerPortofolioRm->Cif;
                $rsRekeningPortofolioRm = $this->PortofolioRm_model->getRekeningPortofolioRm($cif);
                $iRekeningPortofolioRm = 0;
                foreach($rsRekeningPortofolioRm as $rowRekeningPortofolioRm){
                    $noRek = $rowRekeningPortofolioRm->RekNo;
                    
                    /* Get Latest Status For Each Rekening */
                    $rsLatestStatusRekeningPortofolioRm = $this->PortofolioRm_model->getLatestStatusRekeningPortofolioRm($noRek);
                    $rowRekeningPortofolioRm->Fasilitas = $rsLatestStatusRekeningPortofolioRm->Fasilitas;
                    $rowRekeningPortofolioRm->Plafond = $rsLatestStatusRekeningPortofolioRm->Plafond;
                    $rowRekeningPortofolioRm->Ews = $rsLatestStatusRekeningPortofolioRm->Ews;
                    $rowRekeningPortofolioRm->Kolektibilitas = $rsLatestStatusRekeningPortofolioRm->Kolektibilitas;
                    $rowRekeningPortofolioRm->ProdukPinjaman = $rsLatestStatusRekeningPortofolioRm->Produk;
                    $rowRekeningPortofolioRm->FlagRestruct = $rsLatestStatusRekeningPortofolioRm->IsRestruct;
                    $rowRekeningPortofolioRm->JatuhTempo = $rsLatestStatusRekeningPortofolioRm->DueDate;

                    /* Config Y Axis For 3 Months Backward */
                    $arrOutstandingPortofolioRm = array();
                    foreach($arrayMonths as $rowMonth):
                        $rsOutstandingPortofolioRm = $this->PortofolioRm_model->getOutstandingPortofolioRm($noRek, $rowMonth);
                        if(!empty($rsOutstandingPortofolioRm))
                            $arrOutstandingPortofolioRm[] = $rsOutstandingPortofolioRm[0]->Outstanding;
                        else
                            $arrOutstandingPortofolioRm[] = 0;
                    endforeach;
                    $rowRekeningPortofolioRm->color = $arrColors[$iRekeningPortofolioRm];
                    $rowRekeningPortofolioRm->datasets = $arrOutstandingPortofolioRm;
                    $iRekeningPortofolioRm++;
                }
                $rowCustomerPortofolioRm->labels = $arrayMonthLabel;
                $rowCustomerPortofolioRm->Rekening = $rsRekeningPortofolioRm;                
            }

            $data["PortofolioRm"] = $rsCustomerPortofolioRm;
            
            $config['base_url'] = base_url().'portofolio/portofolioRm/page';
            $config['use_page_numbers'] = TRUE;
            $config['total_rows'] = $totalRecords;
            $config['per_page'] = $limitPage;
            $config["uri_segment"] = 4;
            $config['full_tag_open'] = '<ul class="pagination">';
            $config['full_tag_close'] = '</ul>';
            $config['num_tag_open'] = '<li class="page-item">';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
            $config['cur_tag_close'] = '</a></li>';
            $config['next_tag_open'] = '<li class="page-item">';
            $config['next_tagl_close'] = '</a></li>';
            $config['prev_tag_open'] = '<li class="page-item">';
            $config['prev_tagl_close'] = '</li>';
            $config['first_tag_open'] = '<li class="page-item ">';
            $config['first_tagl_close'] = '</li>';
            $config['last_tag_open'] = '<li class="page-item">';
            $config['last_tagl_close'] = '</a></li>';
            $config['attributes'] = array('class' => 'page-link');

            $this->pagination->initialize($config);
            $data["links"] = $this->pagination->create_links();

            //echo json_encode($data); die;

            $this->load->view("layout/header.php");
            $this->load->view("layout/side-nav.php");
            $this->load->view("layout/top-nav.php");
            $this->load->view("portofolio/portofolio_rm.php", $data);
            $this->load->view("layout/footer.php");
        }
    }
?>