<?php

class Divisions extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array(
            'form',
            'url',
            'security'
        ));
        $this->load->library(array(
            'session',
            'form_validation'
        ));
        $this->load->library('form_validation');
    }

    public function index() {
        //$this->load->database();

        $this->checkModule();

        $sql = "SELECT A.*, B.Name [Type], C.Name Segment, D.Name MAKER, E.Name MODIFIER
            FROM UnitKerja A
            LEFT JOIN UnitKerjaType B ON A.UnitKerjaTypeId=B.UnitKerjaTypeId
            LEFT JOIN Segment C ON A.SegmentId=C.SegmentId
            LEFT JOIN [User] D ON A.CreatedBy=D.UserId
            LEFT JOIN [User] E ON A.ModifiedBy=E.UserId";

        $queryData = $this->db->query($sql);
        $data['data'] = $queryData->result();

        $persn = $_SESSION['PERSONAL_NUMBER'];
        $this->insertLog('INFO', $persn, "Get Division", "", "", "", "");

        $this->load->view('layout/header.php');
        $this->load->view('layout/side-nav.php');
        $this->load->view('layout/top-nav.php');
        $this->load->view('backend/master_data/division_index.php', $data);
        $this->load->view('layout/footer.php');
    }

    public function insertNew() {
        //$this->load->database();

        $divId = $this->input->post('divisionId');
        $divName = $this->input->post('divisionName');
        $userId = $this->input->post('currentUser');
        $divSegment = $this->input->post('divisionSegment');
        $divType = $this->input->post('divisionType');
        $today = date('Y-m-d H:i:s');

        if ($divName) {
            $newData = [
                'UnitKerjaId' => $divId,
                'Name' => $divName,
                'SegmentId' => $divSegment,
                'UnitKerjaTypeId' => $divType,
                'IsActive' => '1',
                'CreatedDate' => $today,
                'CreatedBy' => $userId
            ];

            $persn = $_SESSION['PERSONAL_NUMBER'];
            $this->insertLog('INFO', $persn, "Insert Division", "", "", json_encode($newData), "");

            $insertData = $this->db->insert('UnitKerja', $newData);

            print_r($insertData);
            die();
        }
    }

    public function updateData() {
        //$this->load->database();

        $divId = $this->input->post('divisionId');
        $divName = $this->input->post('divisionName');

        $this->form_validation->set_rules('editDivName', 'harus diisi', 'required');

        if ($this->input->post('divisionStatus') == 'Active') {
            $divStatus = '1';
        } else {
            $divStatus = '0';
        }

        if ($this->input->post('divisionSegment') == 'Korporasi') {
            $divSegment = '1';
        } else {
            $divSegment = '2';
        }

        if ($this->input->post('divisionType') == 'Business') {
            $divType = '1';
        } else {
            $divType = '2';
        }

        $userId = $this->input->post('userId');
        $today = date('Y-m-d H:i:s');

        if ($divId) {
            $newData = [
                'Name' => $divName,
                'SegmentId' => $divSegment,
                'UnitKerjaTypeId' => $divType,
                'IsActive' => $divStatus,
                'ModifiedDate' => $today,
                'ModifiedBy' => $userId
            ];
            $getData = $this->db->where('UnitKerjaId', $divId)->get('UnitKerja')->result_array()[0];
            $persn = $_SESSION['PERSONAL_NUMBER'];
            $this->insertLog('INFO', $persn, "Update Division", "", json_encode($getData), json_encode($newData), "");

            $updateData = $this->db->where('UnitKerjaId', $divId)->update('UnitKerja', $newData);

            print_r($updateData);
            die();
        }
    }

    public function deleteData() {
        $this->load->database();

        $divId = $this->input->post('divisionId');
        $userId = $this->input->post('userId');
        $today = date('Y-m-d H:i:s');

        if ($divId) {
            /*$newData = [
                'IsActive' => 0,
                'ModifiedDate' => $today,
                'ModifiedBy' => $userId
            ];
            */

            $getData = $this->db->where('UnitKerjaId', $divId)->get('UnitKerja')->result_array()[0];
            $persn = $_SESSION['PERSONAL_NUMBER'];
            $this->insertLog('INFO', $persn, "Delete Division", "", json_encode($getData), "", "");

            $updateData = $this->db->where('UnitKerjaId', $divId)->delete('UnitKerja');

            print_r($updateData);
        }
    }

    function insertLog($level, $userId, $action, $msg, $old, $new, $exception) {
        $newData = [
            'Level' => $level,
            'LogDate' => date('Y-m-d H:i:s'),
            'CreatedBy' => $userId,
            'Action' => $action,
            'Message' => $msg,
            'OldValue' => $old,
            'NewValue' => $new,
            'Exception' => $exception
        ];
        $updateData = $this->db->insert('LOG', $newData);
    }

}

?>