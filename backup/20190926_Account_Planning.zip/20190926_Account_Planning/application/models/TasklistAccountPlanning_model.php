<?php

class TasklistAccountPlanning_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $today = new DateTime(date('Y-m-d H:i:s'));
        $this->year_current = $today->format('Y');
        $this->current_datetime = $today->format('Y-m-d H:i:s');
        $this->created_date = date('Y-m-d H:i:s.v');
    }

    public function getAccountPlanningEstimatedFinancial($AccountPlanningId, $BankFacilityItemId, $VCIF) {
        $sql = '
        SELECT "c"."Name" AS BankFacilityGroupName, 
        "b"."Name" AS BankFacilityItemName, "b"."BankFacilityGroupId",
        "a"."EstimatedFinancialId", "a"."IDRProjection", "a"."ValasProjection", "a"."IDRTarget", "a"."ValasTarget", "a"."VCIF",
        "d"."Name" AS "CompanyName"
                FROM "EstimatedFinancial" "a"
                LEFT JOIN "BankFacilityItem" "b" ON "a"."BankFacilityItemId" = "b"."BankFacilityItemId"
                LEFT JOIN "BankFacilityGroup" "c" ON "b"."BankFacilityGroupId" = "c"."BankFacilityGroupId"
                LEFT JOIN "CustomerKorporasi" "d" ON "a"."VCIF" = "d"."VCIF"
                WHERE "a"."AccountPlanningId" = '. $AccountPlanningId .' AND "a"."VCIF" = \''. $VCIF .'\' AND "b"."BankFacilityItemId" = '. $BankFacilityItemId;
        // echo $sql;

        $result = $this->db->query($sql)->result_array();

        return $result;
    }

    public function getMemberSelected($AccountPlanningId, $CreatedBy) {
        $sql = 'SELECT "a"."UserId", "b"."Name" AS "RMName"
                FROM "AccountPlanningMember" "a"
                LEFT JOIN "User" "b" ON "a"."UserId"="b"."UserId"
                WHERE "a"."AccountPlanningId"='. $AccountPlanningId .' AND "a"."CreatedBy"=\''. $CreatedBy.'\'';

        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getMemberLists($memberSelected, $userId) {
        $sql = 'SELECT "a"."UserId", "a"."Name"
                FROM "User" "a"
                WHERE IsActive = 1 AND UserId <> \''.$userId.'\'';
        if (!empty($memberSelected)) {
            $sql .= ' AND UserId NOT IN (';
            $selected = '';
            foreach ($memberSelected as $key => $value) {
                $selected .= "'".$value['UserId']."', ";
            }
            $sql .= substr($selected, 0, -2);
            $sql .= ')';
        }

        $results = $this->db->query($sql)->result_array();  

        return $results;
    }

    public function getCheckerSelected($AccountPlanningId, $CreatedBy) {
        $sql = 'SELECT "a"."UserId", "b"."Name" AS "CheckerName"
                FROM "AccountPlanningChecker" "a"
                LEFT JOIN "User" "b" ON "a"."UserId"="b"."UserId"
                WHERE "a"."AccountPlanningId"='. $AccountPlanningId .' AND "a"."CreatedBy"=\''. $CreatedBy.'\' AND "a"."IsActive"=1 ';

        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getChecker($UnitKerjaId, $memberSelected='') {
        $sql = 'SELECT "a"."UserId", "a"."Name" AS "CheckerName", "a"."RoleID"
                FROM "User" "a"
                WHERE 
                 RoleID IN (7, 8, 9) 
                --AND "a"."UnitKerjaId" ='. $UnitKerjaId .' 
                ';
        // echo $sql;

        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getSignerSelected($AccountPlanningId, $CreatedBy) {
        $sql = 'SELECT "a"."UserId", "b"."Name" AS "SignerName"
                FROM "AccountPlanningSigner" "a"
                LEFT JOIN "User" "b" ON "a"."UserId"="b"."UserId"
                WHERE "a"."AccountPlanningId"='. $AccountPlanningId .' AND "a"."CreatedBy"=\''. $CreatedBy.'\' AND "a"."IsActive"=1';

        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getSigner($UnitKerjaId, $memberSelected='') {
        $sql = 'SELECT "a"."UserId", "a"."Name" AS "SignerName", "a"."RoleID"
                FROM "User" "a"
                WHERE 
                 RoleID IN (7, 8, 9) 
                -- AND"a"."UnitKerjaId" ='. $UnitKerjaId .' 
                ';
        // echo $sql;

        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getBankList() {
        $sql = '
            SELECT BankId, Name, Logo
            FROM Bank 
            WHERE IsActive = 1
        ';

        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getAccountPlanningFinancialHighlightItem($FinancialHighlightGroupId) {
        $sql = 'SELECT "a"."FinancialHighlightItemId", "a"."FinancialHighlightGroupId", "a"."Name" AS "FinancialHighlightItemName",
                "b"."Name" AS "FinancialHighlightGroupName"
                FROM "FinancialHighlightItem" "a"
                LEFT JOIN "FinancialHighlightGroup" "b" ON "a"."FinancialHighlightGroupId" = "b"."FinancialHighlightGroupId"
                WHERE "a"."IsActive" ='. 1 .' AND "a"."FinancialHighlightGroupId" = '. $FinancialHighlightGroupId;

        $result = $this->db->query($sql)->result_array();

        return $result;
    }

    public function getAccountPlanningBankFacilityItem($BankFacilityGroupId) {
        $sql = 'SELECT "a"."BankFacilityItemId", "a"."BankFacilityGroupId", "a"."Name" AS "BankFacilityItemName",
                "b"."Name" AS "BankFacilityGroupName"
                FROM "BankFacilityItem" "a"
                LEFT JOIN "BankFacilityGroup" "b" ON "a"."BankFacilityGroupId" = "b"."BankFacilityGroupId"
                WHERE "a"."IsActive" ='. 1 .' AND "a"."BankFacilityGroupId" = '. $BankFacilityGroupId;

        $result = $this->db->query($sql)->result_array();

        return $result;
    }

    public function getTotalViewTasklistAccountPlanning($UserId, $keyword_search_box, $uker_search_box, $tahun_search_box, $status_search_box) {
        $sql = '
            SELECT COUNT(*) AS "numrows" 
            FROM "AccountPlanningOwner" 
            WHERE UserId = \''.$UserId.'\' AND IsActive = 1
        ';

        $result = $this->db->query($sql)->result_array();  

        return $result[0]['numrows'];
    }

    public function getViewTasklistAccountPlanning($UserId, $rowperpage, $rowno, $keyword_search_box, $uker_search_box, $tahun_search_box, $status_search_box) {
        $sql = '
            SELECT "k"."CreatedBy", "k"."AccountPlanningId", "k"."UserId" AS "RMId",
            "a"."Year", "a"."FinancialHighlightCurrency" AS "Currency", "a"."CreatedDate",
            "b"."VCIF", 
            "c"."Name" AS "CustomerName", "c"."CustomerGroupId", 
            --"d"."DocumentStatusId", 
            --"e"."Name" AS "Status",
            "g"."Name" AS "RMName",
            "h"."Name" AS "CustomerGroupName",
            "i"."PinjamanTotal" AS "PinjamanTotalGroup", "i"."PinjamanRatas" AS "PinjamanRatasGroup", "i"."SimpananTotal" AS "SimpananTotalGroup", "i"."SimpananRatas" AS "SimpananRatasGroup", "i"."CurrentCPA" AS "CurrentCPAGroup", "i"."ValueChain" AS "ValueChainGroup",
            "j"."PinjamanTotal" AS "PinjamanTotalAP", "j"."PinjamanRatas" AS "PinjamanRatasAP", "j"."SimpananTotal" AS "SimpananTotalAP", "j"."SimpananRatas" AS "SimpananRatasAP", "j"."CurrentCPA" AS "CurrentCPAAP", "j"."ValueChain" AS "ValueChainAP"
            FROM "AccountPlanningOwner" "k"
            LEFT JOIN "AccountPlanning" "a" ON "k"."AccountPlanningId"="a"."AccountPlanningId"
            LEFT JOIN "AccountPlanningCustomer" "b" ON "k"."AccountPlanningId"="b"."AccountPlanningId" AND "b"."IsMain"=1
            LEFT JOIN "CustomerKorporasi" "c" ON "b"."VCIF"="c"."VCIF"
            --LEFT JOIN "AccountPlanningStatus" "d" ON "k"."AccountPlanningId"="d"."AccountPlanningId"
            --LEFT JOIN "DocumentStatus" "e" ON "d"."DocumentStatusId"="e"."DocumentStatusId"
            LEFT JOIN "User" "g" ON "k"."UserId"="g"."UserId" AND "g"."IsActive"=1
            LEFT JOIN "CustomerGroup" "h" ON "c"."CustomerGroupId"="h"."CustomerGroupId"
            LEFT JOIN "Summary_SimpanPinjamCustomerGroup" "i" ON "c"."CustomerGroupId"="i"."CustomerGroupId"
            LEFT JOIN "Summary_SimpanPinjamAccountPlanning" "j" ON "k"."AccountPlanningId"="j"."AccountPlanningId"
            WHERE "k"."UserId" = \''.$UserId.'\'  AND "k"."IsActive" = 1
        ';

        $sql .= ' ORDER BY k.StartDate DESC OFFSET '.$rowno.' ROWS FETCH NEXT '.$rowperpage.' ROWS ONLY';
        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function insertData($table, $data_input) {

        $str = $this->db->insert($table, $data_input);
        // echo $this->db->last_query(); //die();
        $error = $this->db->error();
        // print_r($error); die();
        if($error['code']<>0) {
            $result = array(
                'status' => 'error',
                'message'=> $error['message']
            );
        } else {
            $result = array(
                'status' => 'success'
            );
        }

        return $result;

    }

    public function insertDataGetInputedId($table, $data_input) {

        $str = $this->db->insert($table, $data_input);
        $InputedId = $this->getInputedId();  
        return $InputedId;

    }

    public function updateData($table, $data, $IDField, $IDValue) {

        $this->db->where($IDField, $IDValue);
        $str = $this->db->update($table, $data);
        // echo $this->db->last_query(); //die();

        $error = $this->db->error();

        if($error['code']<>0) {
            $result = array(
                'status' => 'error',
                'message'=> $error['message']
            );
        } else {
            $result = array(
                'status' => 'success'
            );
        }

        return $result;

    }

    public function deleteData($table, $data_delete) {

        $str = $this->db->delete($table, $data_delete);

    }

    public function getInputedId() {
        $sql = "SELECT SCOPE_IDENTITY() AS InputedId;";
        $result = $this->db->query($sql)->result_array();   

        return $result[0]['InputedId'];
    }

    public function insertMemberPerRM($AccountPlanningId, $UserId, $CreatedBy) {
        $data = array(
            'AccountPlanningId'     => $AccountPlanningId, 
            'UserId'                => $UserId, 
            'CreatedDate'           => $this->current_datetime, 
            'CreatedBy'             => $CreatedBy, 
            );

        $str = $this->db->insert('AccountPlanningMember', $data);

        // $str = $this->db->query('AccountPlanningMember ?,?,?,?',$data);

        $error = $this->db->error();
        // print_r($error); die();
        if($error['code']<>0) {
            $result = array(
                'status' => 'error',
                'message'=> $error['message']
            );
        } else {
            $result = array(
                'status' => 'success'
            );
        }

        return $result;

    }

    public function insertCheckerSignerPerRM($Table, $data) {

        $str = $this->db->insert($Table, $data);

        // $str = $this->db->query('AccountPlanningMember ?,?,?,?',$data);

        $error = $this->db->error();
        // print_r($error); die();
        if($error['code']<>0) {
            $result = array(
                'status' => 'error',
                'message'=> $error['message']
            );
        } else {
            $result = array(
                'status' => 'success'
            );
        }

        return $result;

    }

    /*
        Start Script From Irvan 
    */
    public function getAccountPlanningGroupOverview($AccountPlanningId, $VCIF = NULL) {
        $whereClause = "";
        if($VCIF != NULL){
            $whereClause .= " AND a.VCIF = '".$VCIF."'";
        }
        $sql = 'SELECT "a".GroupOverviewId, "a"."Address1", "a"."Address2", "a"."Address3", "a"."Address1", "a"."IndustryName",
                    "b"."Name" AS "Province",
                    "c"."Name" AS "GlobalRatingName", "c"."Description" AS "GlobalRatingDescription", 
                    "d"."Name" AS "DomesticRating",
                    "e"."Name" AS "LifeCycle",
                    "f"."Name" AS "ChildCompanyName",
                    "g"."Name" AS "IndustryTrend"
                FROM "GroupOverview" "a"
                LEFT JOIN "Province" "b" on "a"."ProvinceId"="b"."ProvinceId" AND "b"."IsActive"=1
                LEFT JOIN "GlobalRating" "c" on "a"."GlobalRatingId"="c"."GlobalRatingId" AND "c"."IsActive"=1
                LEFT JOIN "DomesticRating" "d" on "a"."DomesticRatingId"="d"."DomesticRatingId" AND "d"."IsActive"=1
                LEFT JOIN "LifeCycle" "e" on "a"."LifeCycleId"="e"."LifeCycleId" AND "e"."IsActive"=1
                LEFT JOIN "CustomerKorporasi" "f" on "a"."VCIF"="f"."VCIF" 
                LEFT JOIN "IndustryTrend" "g" on "a"."IndustryTrendId"="g"."IndustryTrendId" AND "g"."IsActive"=1
                WHERE "a"."AccountPlanningId" ='. $AccountPlanningId .$whereClause;

        $result = $this->db->query($sql)->result_array();

        return $result;
    }
    public function getAccountPlanningFileStructure($AccountPlanningId, $StructureTypeId, $VCIF = NULL){
        $whereClause = "";
        if($StructureTypeId == 1 || $StructureTypeId == 3){
            $whereClause .= " AND t1.VCIF IS NOT NULL ";
        }
        if($VCIF != NULL){
            $whereClause .= " AND t1.VCIF = '".$VCIF."'";
        }
        $sql = "SELECT t1.FilePath, t1.VCIF, t2.Name
                FROM FileStructure t1
                LEFT JOIN CustomerKorporasi t2 ON t1.VCIF = t2.VCIF
                WHERE t1.AccountPlanningId = ".$AccountPlanningId." AND t1.StructureTypeId = ".$StructureTypeId. $whereClause;
        $result = $this->db->query($sql)->result();
        return $result;
    }
    public function uploadBusinessProcessOrganization($data){
        $isCommit = 1;
        $this->db->trans_begin();

        switch($data['StructureTypeId']){
            case 1:
                $arrayWhere = array('AccountPlanningId' => $data["AccountPlanningId"], 
                                    'StructureTypeId' => $data['StructureTypeId'],
                                    'VCIF' => $data['VCIF']);
                break;
            case 2:
                $arrayWhere = array('AccountPlanningId' => $data["AccountPlanningId"], 
                                    'StructureTypeId' => $data['StructureTypeId']);
                break;
            case 3:
                $arrayWhere = array('AccountPlanningId' => $data["AccountPlanningId"], 
                                    'StructureTypeId' => $data['StructureTypeId'],
                                    'VCIF' => $data['VCIF']);
                break;
        }

        $this->db->delete('FileStructure', $arrayWhere);
        if ($this->db->trans_status() === FALSE){
            $isCommit = 0;
        }

        $dataPost = array(
            'StructureTypeId' => $data['StructureTypeId'],
            'AccountPlanningId' => $data['AccountPlanningId'],
            'VCIF' => $data['VCIF'],
            'FilePath' => $data['FilePath'],
            'Size' => $data['Size'],
            'Type' => $data['Type'],
            'CreatedBy' => $data['createdBy'],
            'CreatedDate' => $this->created_date
        );
        $this->db->insert('FileStructure', $dataPost);
        if ($this->db->trans_status() === FALSE){
            $isCommit = 0;
        }

        //Commit Transaction
		if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
            $this->db->trans_commit();
            return 1;
		}
    }
    public function updateCoverageMapping($data){
        $isCommit = 1;
        $this->db->trans_begin();

        $this->db->delete('CoverageMapping', array('AccountPlanningId' => $data["accountPlanningId"], 'VCIF' => $data['vcif']));
        if ($this->db->trans_status() === FALSE){
            $isCommit = 0;
        }

        if($data['jumlahCoverageMapping'] > 0){
            $arrCoverageMapping = array();
            foreach($data['arrCoverageMapping'] as $rows){
                $dataPost = array(
                            'AccountPlanningId' => $data['accountPlanningId'],
                            'VCIF' => $data['vcif'],
                            'ClientName' => $rows['ClientName'],
                            'ContactNumber' => $rows['ContactNumber'],
                            'ClientPosition' => $rows['ClientPosition'],
                            'BankPerson' => $rows['BankPerson'],
                            'BankContact' => $rows['BankContact'],
                            'BankPosition' => $rows['BankPosition'],
                            'OtherInformation' => $rows['OtherInformation'],
                            'CreatedBy' => $data['createdBy'],
                            'CreatedDate' => $this->created_date
                        );
                array_push($arrCoverageMapping, $dataPost);
            }

            $this->db->insert_batch('CoverageMapping', $arrCoverageMapping);
            if ($this->db->trans_status() === FALSE){
                $isCommit = 0;
            }
        }

        //Commit Transaction
		if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
            $this->db->trans_commit();
            return 1;
		}
    }
    public function getAccountPlanningCoverageMapping($AccountPlanningId, $VCIF) {
        $sql = "SELECT ClientPosition, ClientName, ContactNumber, OtherInformation, BankPosition, BankPerson, BankContact, Description
                FROM CoverageMapping
                WHERE AccountPlanningId = ".$AccountPlanningId." AND VCIF = '".$VCIF."'";
        $result = $this->db->query($sql)->result();
        return $result;
    }
    public function updateStrategicPlan($data){
        $isCommit = 1;
        $this->db->trans_begin();

        $this->db->delete('StrategicPlan', array('AccountPlanningId' => $data["accountPlanningId"], 'VCIF' => $data['vcif']));
        if ($this->db->trans_status() === FALSE){
            $isCommit = 0;
        }

        if($data['jumlahStrategicPlan'] > 0){
            $arrStrategicPlan = array();
            foreach($data['arrStrategicPlan'] as $rows){
                $dataPost = array(
                            'VCIF' => $data['vcif'],
                            'AccountPlanningId' => $data['accountPlanningId'],
                            'StrategicPlanTypeId' => $rows['StrategicPlanTypeId'],
                            'Name' => $rows['Name'],
                            'CreatedBy' => $data['createdBy'],
                            'CreatedDate' => $this->created_date
                        );
                array_push($arrStrategicPlan, $dataPost);
            }

            $this->db->insert_batch('StrategicPlan', $arrStrategicPlan);
            if ($this->db->trans_status() === FALSE){
                $isCommit = 0;
            }
        }

        //Commit Transaction
		if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
            $this->db->trans_commit();
            return 1;
		}
    }
    public function getAccountPlanningStrategicPlan($AccountPlanningId, $VCIF, $StrategicPlanTypeId = NULL) {
        $whereClause = '';
        if($StrategicPlanTypeId != NULL){
            $whereClause .= " AND StrategicPlanTypeId =". $StrategicPlanTypeId;
        }
        $sql = "SELECT t1.StrategicPlanTypeId, t2.Name AS StrategicPlanTypeName, t1.Name
                FROM StrategicPlan t1
                LEFT JOIN StrategicPlanType t2 ON t1.StrategicPlanTypeId = t2.StrategicPlanTypeId
                WHERE t1.AccountPlanningId = ".$AccountPlanningId ."
                AND t1.VCIF = '".$VCIF."' ".$whereClause." ORDER BY t1.StrategicPlanTypeId";

        $result = $this->db->query($sql)->result();

        return $result;
    }
    public function updateShareholders($data){
        $isCommit = 1;
        $this->db->trans_begin();

        $this->db->delete('Shareholder', array('AccountPlanningId' => $data["accountPlanningId"]));
        if ($this->db->trans_status() === FALSE){
            $isCommit = 0;
        }

        if($data['jumlahShareholders'] > 0){
            $arrShareholders = array();
            foreach($data['arrShareholders'] as $rows){
                $dataPost = array(
                            'AccountPlanningId' => $data['accountPlanningId'],
                            'Name' => $rows['Name'],
                            'Quantity' => $rows['Value'],
                            'CreatedBy' => $data['createdBy'],
                            'CreatedDate' => $this->created_date
                        );
                array_push($arrShareholders, $dataPost);
            }

            $this->db->insert_batch('Shareholder', $arrShareholders);
            if ($this->db->trans_status() === FALSE){
                $isCommit = 0;
            }
        }

        //Commit Transaction
		if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
            $this->db->trans_commit();
            return 1;
		}
    }
    public function getGroupOverviewInformation($VCIF) {
        $sql = "SELECT a.GroupOverviewId, a.Address1, a.Address2, a.Address3, a.Address1, a.IndustryName, 
                    a.ProvinceId, a.GlobalRatingId, a.DomesticRatingId,a.IndustryTrendId,a.LifeCycleId,
                    b.Name AS Province,
                    c.Name AS GlobalRatingName, c.Description AS GlobalRatingDescription, 
                    d.Name AS DomesticRating,
                    e.Name AS LifeCycle,
                    f.Name AS ChildCompanyName,
                    g.Name AS IndustryTrend
                FROM CustomerKorporasi f
                LEFT JOIN GroupOverview a on a.VCIF=f.VCIF 
                LEFT JOIN Province b on a.ProvinceId=b.ProvinceId AND b.IsActive=1
                LEFT JOIN GlobalRating c on a.GlobalRatingId=c.GlobalRatingId AND c.IsActive=1
                LEFT JOIN DomesticRating d on a.DomesticRatingId=d.DomesticRatingId AND d.IsActive=1
                LEFT JOIN LifeCycle e on a.LifeCycleId=e.LifeCycleId AND e.IsActive=1
                LEFT JOIN IndustryTrend g on a.IndustryTrendId=g.IndustryTrendId AND g.IsActive=1
                WHERE a.VCIF = '". $VCIF."'";
        $this->db->limit(1);
        $result = $this->db->query($sql)->result();
        if(!empty($result)){
            return $result[0];
        }else return $result;        
    }
    public function updateGroupOverview($data){
        $isCommit = 1;
        $this->db->trans_begin();

        $arrayWhere = array('AccountPlanningId' => $data["accountPlanningId"],
                            'VCIF' => $data['VCIF']);
        $this->db->delete('GroupOverview', $arrayWhere);
        if ($this->db->trans_status() === FALSE){
            $isCommit = 0;
        }

        $row = array(
            'AccountPlanningId' => $data["accountPlanningId"],
            'VCIF' => $data['VCIF'],
            'Address1' => $data['address'],
            'ProvinceId' => $data['provinceId'],
            'GlobalRatingId' => $data['globalRatingId'],
            'DomesticRatingId' => $data['domesticRatingId'],
            'IndustryName' => $data['industry'],
            'IndustryTrendId' => $data['industryTrendId'],
            'LifeCycleId' => $data['lifeCycleId'],
            'CreatedBy' => $data['createdBy']
        );
        $this->db->insert('GroupOverview', $row);

        if ($this->db->trans_status() === FALSE){
            $this->db->trans_rollback();
			return 0;
        }else{
            $this->db->trans_commit();
			return 1;
        }
    }
    public function getStrategicPlanTypeOption(){
        $this->db->select('StrategicPlanTypeId, Name');
        $this->db->from('StrategicPlanType');
        $result = $this->db->get()->result();
        return $result;
    }
    public function getSelectedCompanyOption($AccountPlanningId){
        $this->db->select('t1.VCIF, t2.Name');
        $this->db->from('AccountPlanningCustomer t1');
        $this->db->join('CustomerKorporasi t2','t1.VCIF = t2.VCIF','left');
        $this->db->where('t1.AccountPlanningId',$AccountPlanningId);
        $result = $this->db->get()->result();
        return $result;
    }
    public function getCompanyInformation($VCIF){
        $this->db->select('*');
        $this->db->from('CustomerKorporasi');
        $this->db->where('VCIF',$VCIF);
        $this->db->limit(1);
        $result = $this->db->get()->result();
        return $result[0];
    }
    public function getCityOption(){
        $this->db->select('ProvinceId, Name');
        $this->db->from('Province');
        $this->db->order_by('ViewOrder','asc');
        $result = $this->db->get()->result();
        return $result;
    }
    public function getIndustryTrendOption(){
        $this->db->select('IndustryTrendId, Name');
        $this->db->from('IndustryTrend');
        $this->db->order_by('Name','asc');
        $result = $this->db->get()->result();
        return $result;
    }
    public function getLifeCycleOption(){
        $this->db->select('LifeCycleId, Name');
        $this->db->from('LifeCycle');
        $this->db->order_by('Name','asc');
        $result = $this->db->get()->result();
        return $result;
    }
    public function getDomesticRatingOption(){
        $this->db->select('DomesticRatingId, Name');
        $this->db->from('DomesticRating');
        $this->db->order_by('Name','asc');
        $result = $this->db->get()->result();
        return $result;
    }
    public function getGlobalRatingOption(){
        $this->db->select('GlobalRatingId, Name');
        $this->db->from('GlobalRating');
        $this->db->order_by('Name','asc');
        $result = $this->db->get()->result();
        return $result;
    }
    public function getGlobalRatingDescription($globalRatingId){
        $this->db->select('Description');
        $this->db->from('GlobalRating');
        $this->db->where('GlobalRatingId',$globalRatingId);
        $this->db->limit(1);
        $result = $this->db->get()->result();
        return $result[0]->Description;
    }
    public function getCIF($VCIF){
        $this->db->select('CIF, Name');
        $this->db->from('DetailCustomerKorporasi');
        $this->db->where('VCIF', $VCIF);
        $this->db->order_by('Name','asc');
        $result = $this->db->get()->result();
        return $result;
    }
    public function getCustomerInformation($VCIF){
        $this->db->select('Name');
        $this->db->from('CustomerKorporasi');
        $this->db->where('VCIF', $VCIF);
        $this->db->limit(1);
        $result = $this->db->get()->result();
        return $result[0]->Name;
    }
    public function getCSTMember($AccountPlanningId){
        $this->db->select("t1.CreatedDate, t2.Name AS UserName, t2.Title, t2.ProfilePicture, t3.Name AS UkerName");
        $this->db->from("AccountPlanningMember t1");
        $this->db->join("User t2","t1.UserId = t2.UserId","left");
        $this->db->join("UnitKerja t3","t2.UnitKerjaId = t3.UnitKerjaId","left");
        $this->db->where("t1.AccountPlanningId", $AccountPlanningId);
        $result = $this->db->get()->result();
        return $result;
    }
    /*
        End Script From Irvan
    */

    /* Script Andre */
    public function getTotalMyAccountPlanning($userId, $year='', $docStatusId='', $searchTxt=''){
        $filter = '';
        $tblFilter = '';
        if(!empty($year) && $year <> 'all'){
            $filter .= " AND A.Year='".$year."'";
        }

        if(!empty($docStatusId) && $docStatusId <> 'all'){
            $tblFilter = ", AccountPlanningStatus G ";
            $filter .= " AND G.DocumentStatusId=".$docStatusId." AND G.AccountPlanningStatusId = (
                SELECT MAX(AccountPlanningStatusId) FROM AccountPlanningStatus
                WHERE AccountPlanningId = A.AccountPlanningId) ";
        }

        if(!empty($searchTxt)){
            $filter .= " AND A.AccountPlanningId IN (
                    SELECT X.AccountPlanningId
                    FROM AccountPlanningCustomer X, CustomerKorporasi Y
                    WHERE X.VCIF=Y.VCIF
                        AND (Y.NAME LIKE '%".$searchTxt."%' OR Y.VCIF LIKE '%".$searchTxt."%')
                )";
        }

        $sql = "SELECT COUNT(1) Total FROM(
            SELECT A.AccountPlanningId, A.CreatedDate, A.[Year],
                D.CustomerGroupId, D.Name CustomerName, E.Name RMName, F.Logo
            FROM AccountPlanning A, AccountPlanningOwner B,
                AccountPlanningCustomer C, CustomerKorporasi D, [User] E,
                CustomerGroup F ".$tblFilter."
            WHERE A.AccountPlanningId=B.AccountPlanningId
                AND B.AccountPlanningId=C.AccountPlanningId
                AND C.VCIF=D.VCIF AND E.UserId = B.UserId
                AND D.CustomerGroupId = F.CustomerGroupId
                AND B.UserId='".$userId."' AND B.IsActive=1
                AND C.IsMain=1 ".$filter."
            ) Tbl
        ";

        $result = $this->db->query($sql)->row_array();

        return $result['Total'];
    }

    public function getMyAccountPlanning($userId, $rowperpage, $rowno, $year='', $docStatusId='', $searchTxt=''){
        $filter = '';
        $tblFilter = '';
        if(!empty($year) && $year <> 'all'){
            $filter .= " AND A.Year='".$year."'";
        }

        if(!empty($docStatusId) && $docStatusId <> 'all'){
            $tblFilter = ", AccountPlanningStatus G ";
            $filter .= " AND G.DocumentStatusId=".$docStatusId." AND G.AccountPlanningStatusId = (
                SELECT MAX(AccountPlanningStatusId) FROM AccountPlanningStatus
                WHERE AccountPlanningId = A.AccountPlanningId) ";
        }

        if(!empty($searchTxt)){
            $filter .= " AND A.AccountPlanningId IN (
                    SELECT X.AccountPlanningId
                    FROM AccountPlanningCustomer X, CustomerKorporasi Y
                    WHERE X.VCIF=Y.VCIF
                        AND (Y.NAME LIKE '%".$searchTxt."%' OR Y.VCIF LIKE '%".$searchTxt."%')
                )";
        }

        $sql = "
            SELECT A.AccountPlanningId, A.CreatedDate, A.[Year],
                D.CustomerGroupId, D.Name CustomerName, E.Name RMName, F.Logo
            FROM AccountPlanning A, AccountPlanningOwner B,
                AccountPlanningCustomer C, CustomerKorporasi D, [User] E,
                CustomerGroup F ".$tblFilter."
            WHERE A.AccountPlanningId=B.AccountPlanningId
                AND B.AccountPlanningId=C.AccountPlanningId
                AND C.VCIF=D.VCIF AND E.UserId = B.UserId
                AND D.CustomerGroupId = F.CustomerGroupId
                AND B.UserId='".$userId."' AND B.IsActive=1
                AND C.IsMain=1 ".$filter."
            ORDER BY A.CreatedDate DESC OFFSET ".$rowno." ROWS FETCH NEXT ".$rowperpage." ROWS ONLY
        ";

        $result = $this->db->query($sql);

        return $result->result_array();
    }

    public function addMemberAccountPlanning($accountPlanningId, $UserId, $CreatedBy) {
        $data = array(
            'AccountPlanningId'     => $accountPlanningId, 
            'UserId'                => $UserId, 
            'CreatedBy'             => $CreatedBy, 
            );

        $str = $this->db->query('transAccountPlanningAddMember ?,?,?',$data);

        $error = $this->db->error();
        if($error['code']<>0) {
            $result = array(
                'insertStatus' => 'error',
                'insertMessage'=> $error['message']
            );
        } else {
            $result = array(
                'insertStatus' => 'success'
            );
        }

         return $result;

    }

    public function removeMemberAccountPlanning($accountPlanningId, $UserId, $CreatedBy) {
        $data = array(
            'AccountPlanningId'     => $accountPlanningId, 
            'UserId'                => $UserId, 
            'CreatedBy'             => $CreatedBy, 
            );

        $str = $this->db->query('transAccountPlanningRemoveMember ?,?,?',$data);

        $error = $this->db->error();
        if($error['code']<>0) {
            $result = array(
                'removeStatus' => 'error',
                'removeMessage'=> $error['message']
            );
        } else {
            $result = array(
                'removeStatus' => 'success'
            );
        }

         return $result;

    }
}
