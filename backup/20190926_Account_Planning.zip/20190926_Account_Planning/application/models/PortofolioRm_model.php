<?php
    class PortofolioRm_model extends CI_Model {

        function __construct() {
            parent::__construct();
        }

        public function getTotalCustomerPortofolioRm($Rm, $keyword){
            $whereClause = "";
            if($keyword != NULL){
                $whereClause .= " AND (";
                $whereClause .= " t1.Cif LIKE '%".$keyword."%'";
                $whereClause .= " OR t2.CustomerName LIKE '%".$keyword."%'";
                $whereClause .= " OR t1.JenisUsaha LIKE '%".$keyword."%'";
                $whereClause .= " OR t2.Address LIKE '%".$keyword."%')";
            }
            $sql = "SELECT DISTINCT(t1.Cif)
                    FROM Portofolio t1
                    LEFT JOIN CustomerMenengah t2 ON t1.Cif = t2.CIF
                    WHERE t1.Rm = '".$Rm."' ".$whereClause."
                    GROUP BY t1.Cif";
            //echo $sql; die;
            $query = $this->db->query($sql);
            $result = $query->result();
            return $result;
        }

        public function getCustomerPortofolioRm($Rm, $rowPerPage, $rowNo, $keyword){
            $whereClause = "";
            if($keyword != NULL){
                $whereClause .= " AND (";
                $whereClause .= " t1.Cif LIKE '%".$keyword."%'";
                $whereClause .= " OR t2.CustomerName LIKE '%".$keyword."%'";
                $whereClause .= " OR t1.JenisUsaha LIKE '%".$keyword."%'";
                $whereClause .= " OR t2.Address LIKE '%".$keyword."%')";
            }
            $sql = "SELECT t1.Cif, t2.CustomerName, t1.JenisUsaha, t2.Address, t1.Lpg
                    FROM Portofolio t1
                    LEFT JOIN CustomerMenengah t2 ON t1.Cif = t2.CIF
                    WHERE t1.Rm = '".$Rm."' ".$whereClause."
                    GROUP BY t1.Cif, t2.CustomerName, t1.JenisUsaha, t2.Address, t1.Lpg
                    ORDER BY t1.Cif OFFSET ".$rowNo." ROWS FETCH NEXT ".$rowPerPage." ROWS ONLY";
            $query = $this->db->query($sql);		
            $result = $query->result();
            return $result;
        }

        public function getRekeningPortofolioRm($Cif){
            $sql = "SELECT RekNo
                    FROM Portofolio
                    WHERE Cif = '".$Cif."'
                    GROUP BY RekNo";
            $query = $this->db->query($sql);		
            $result = $query->result();
            return $result;
        }

        public function getLatestStatusRekeningPortofolioRm($RekNo){
            $sql = "SELECT RekNo, Fasilitas, Plafond, Ews, Kolektibilitas, Produk, IsRestruct, DueDate
                    FROM Portofolio
                    WHERE RekNo = '".$RekNo."' 
                    ORDER BY Periode DESC";
            $this->db->limit(1);
            $query = $this->db->query($sql);		
            $result = $query->result();
            return $result[0];
        }

        public function getOutstandingPortofolioRm($RekNo, $month){
            $whereClause = " AND Periode = '".$month."'";
            /*
            if(!empty($arrMonth)){
                $countMonth = count($arrMonth);
                if($countMonth == 1){
                    $whereClause .= " AND Periode = ".$arrMonth[0];
                }else{
                    $whereClause .= " AND Periode IN (";
                    $i=0;
                    foreach($arrMonth as $row){
                        if($i != 0) $whereClause .= ",";
                        $whereClause .= "'".$row."'";
                        $i++;
                    }
                    $whereClause .= ")";
                }
            }
            */
            $sql = "SELECT Outstanding
                    FROM Portofolio
                    WHERE RekNo = '".$RekNo."' ".$whereClause."
                    ORDER BY Periode";
            $query = $this->db->query($sql);		
            $result = $query->result();
            return $result;
        }
    }
?>