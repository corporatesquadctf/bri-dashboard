<?php

class ApproveAccountPlanning_model extends CI_Model {

    public function getTotalViewApproveAccountPlanning($UserId, $keyword_search_box='', $uker_search_box='', $tahun_search_box='', $status_search_box='') {
        $sql = '
            SELECT "a"."AccountPlanningStatusId", "a"."AccountPlanningId", "a"."DocumentStatusId"
            , "b"."UserId"
            FROM "AccountPlanningStatus" "a"
            RIGHT JOIN "AccountPlanningChecker" "b" ON "a"."AccountPlanningId"="b"."AccountPlanningId"
            WHERE "b"."UserId" = \''.$UserId.'\' 
            AND "a"."AccountPlanningStatusId" = (
            SELECT MAX(AccountPlanningStatusId) FROM AccountPlanningStatus WHERE AccountPlanningId = "b"."AccountPlanningId"
            ) 
            AND "a"."DocumentStatusId" NOT IN (0, 1)
        ';

        $result = $this->db->query($sql)->result_array();  

        return count($result);
    }


    public function getViewApproveAccountPlanning($UserId, $rowperpage, $rowno, $keyword_search_box='', $uker_search_box='', $tahun_search_box='', $status_search_box='') {
        $sql = '
           SELECT "k"."AccountPlanningStatusId", "k"."AccountPlanningId", "k"."DocumentStatusId"
            , "a"."CreatedBy", "a"."AccountPlanningId", "a"."UserId", "a"."CreatedDate"
            , "b"."Year", "b"."FinancialHighlightCurrency" AS "Currency"
            , "c"."VCIF"
            , "d"."Name" AS "CustomerName"
            , "e"."Name" AS "CustomerGroupName", "e"."CustomerGroupId", "e"."Logo"
            , "f"."Name" AS "RMName"
            , "i"."PinjamanTotal" AS "PinjamanTotalGroup", "i"."PinjamanRatas" AS "PinjamanRatasGroup", "i"."SimpananTotal" AS "SimpananTotalGroup", "i"."SimpananRatas" AS "SimpananRatasGroup", "i"."CurrentCPA" AS "CurrentCPAGroup", "i"."ValueChain" AS "ValueChainGroup"
            , "j"."PinjamanTotal" AS "PinjamanTotalAP", "j"."PinjamanRatas" AS "PinjamanRatasAP", "j"."SimpananTotal" AS "SimpananTotalAP", "j"."SimpananRatas" AS "SimpananRatasAP", "j"."CurrentCPA" AS "CurrentCPAAP", "j"."ValueChain" AS "ValueChainAP"

            FROM "AccountPlanningStatus" "k"
            RIGHT JOIN "AccountPlanningChecker" "a" ON "k"."AccountPlanningId"="a"."AccountPlanningId"
            LEFT JOIN "AccountPlanning" "b" ON "b"."AccountPlanningId"="a"."AccountPlanningId"
            LEFT JOIN "AccountPlanningCustomer" "c" ON "a"."AccountPlanningId"="c"."AccountPlanningId" AND "c"."IsMain"=1
            LEFT JOIN "CustomerKorporasi" "d" ON "c"."VCIF"="d"."VCIF"
            LEFT JOIN "CustomerGroup" "e" ON "e"."CustomerGroupId"="d"."CustomerGroupId"
            LEFT JOIN "User" "f" ON "a"."CreatedBy"="f"."UserId" AND "f"."IsActive"=1
            LEFT JOIN "Summary_SimpanPinjamCustomerGroup" "i" ON "d"."CustomerGroupId"="i"."CustomerGroupId"
            LEFT JOIN "Summary_SimpanPinjamAccountPlanning" "j" ON "a"."AccountPlanningId"="j"."AccountPlanningId"

            WHERE "a"."UserId" = \''.$UserId.'\' 
            AND "k"."AccountPlanningStatusId" = (
            SELECT MAX(AccountPlanningStatusId) FROM AccountPlanningStatus WHERE AccountPlanningId = "a"."AccountPlanningId"
            ) 
            AND "k"."DocumentStatusId" NOT IN (0, 1)
        ';

        $sql .= ' ORDER BY "a"."CreatedDate" DESC OFFSET '.$rowno.' ROWS FETCH NEXT '.$rowperpage.' ROWS ONLY';
        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

}
?>