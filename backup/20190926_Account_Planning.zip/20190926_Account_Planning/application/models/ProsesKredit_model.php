<?php
class ProsesKredit_model extends MY_Model {

	function __construct() {
        parent::__construct();
        $this->currentDateTime = date('Y-m-d H:i:s.v');
    }

    function addProsesKredit($data){
        $pipelineId = $data['PipelineId'];
        $statusApplicationId = $data['StatusApplicationId'];
        $statusPutusan = 0;
        $isAkad = 0;
        $userId = $data['UserId'];
        
        $isCommit = 1;
        $this->db->trans_begin();

        $row = array(
            'PipelineId' => $pipelineId,
            'StatusApplicationId' => $statusApplicationId,
            'StatusPutusan' => $statusPutusan,
            'IsAkad' => $isAkad,
            'CreatedBy' => $userId,
            'CreatedDate' => $this->currentDateTime,
            'ModifiedBy' => $userId,
            'ModifiedDate' => $this->currentDateTime
        );

        $this->db->insert('ProsesKredit', $row);
        if ($this->db->trans_status() === FALSE){
            $isCommit = 0;
        }
            
        if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
			$this->db->trans_commit();
			return 1;
		}
    }

    function getProsesKredit($data){
        $whereClause = " WHERE t2.StatusId = 6";

        if($data['Keyword'] != NULL){
            if($whereClause == "") 
                $whereClause .= " WHERE (";
            else
                $whereClause .= " AND (";
            $whereClause .= " t2.CustomerName LIKE '%".$data['Keyword']."%'";
            $whereClause .= " OR t4.DataSourceName LIKE '%".$data['Keyword']."%'";
            $whereClause .= " OR t2.Address LIKE '%".$data['Keyword']."%'";
            $whereClause .= " OR t2.BusinessType LIKE '%".$data['Keyword']."%'";
            $whereClause .= " OR t3.name LIKE '%".$data['Keyword']."%'";
            $whereClause .= " OR t2.Plafond LIKE '%".$data['Keyword']."%'";
            $whereClause .= ")";
        }

        if($data['DivisionId'] != 0){
            if ($whereClause == "") 
                $conn = " WHERE ";
            else $conn = " AND ";
            $whereClause .= $conn." t3.UnitKerjaId = ".$data['DivisionId'];
        }

        if($data['UsulanPlafond'] != 0){
            if ($whereClause == "") 
                $conn = " WHERE ";
            else $conn = " AND ";
            switch($data['UsulanPlafond']){
                case 1:
                    $whereClause .= $conn." t2.Plafond < 50000000000";
                    break;
                case 2:
                    $whereClause .= $conn." t2.Plafond >= 50000000000";
                    break;
            }            
        }

        if($data['CreatedBy'] != 0){
            if ($whereClause == "") 
                $conn = " WHERE ";
            else $conn = " AND ";
            $whereClause .= $conn. " t1.CreatedBy = '".$data['CreatedBy']."'";
        }
        
        $sql = "SELECT  t1.*, 
                        t2.CustomerName, t2.Address, t2.BusinessType, t2.Plafond,
                        t3.Name AS RMName,
                        t4.DataSourceName AS StatusPermohonan,
                        t5.Name AS StatusApplicationName
                FROM ProsesKredit t1
                LEFT JOIN Pipeline t2 ON t1.PipelineId = t2.PipelineId
                LEFT JOIN [User] t3 ON t1.CreatedBy = t3.UserId
                LEFT JOIN PipelineDataSource t4 ON t2.DataSourceId = t4.PipelineDataSourceId
                LEFT JOIN Role t5 ON t1.StatusApplicationId = t5.RoleId ".$whereClause."
                ORDER BY ModifiedDate DESC";
        
        $query = $this->db->query($sql);		
        $result = $query->result();
        return $result;
    }

    function getDetailProsesKredit($prosesKreditId){
        $where = array(
            't1.ProsesKreditId' => $prosesKreditId
        );

        $this->db->select("t1.*, t2.CustomerName, t2.plafond, t3.DataSourceName AS StatusPermohonan, t4.Name AS RMName, t4.UnitKerjaId AS DivisionId");
        $this->db->from("ProsesKredit t1");
        $this->db->join('Pipeline t2', 't1.PipelineId = t2.PipelineId', 'left');
        $this->db->join('PipelineDataSource t3', 't2.DataSourceId = t3.PipelineDataSourceId', 'left');
        $this->db->join('User t4', 't1.CreatedBy = t4.Userid', 'left');
        $this->db->where($where);

        $queryData = $this->db->get();
        $result = $queryData->result();
        return $result[0];
    }

    function getHistoryProsesKredit($prosesKreditId, $statusApplicationId = null){
        if($statusApplicationId == null){
            $where = array(
                't1.ProsesKreditId' => $prosesKreditId
            );
        }else{
            $where = array(
                't1.ProsesKreditId' => $prosesKreditId,
                't2.RoleId' => $statusApplicationId
            );
        }

        $this->db->select("t1.*, t2.Name as CreatedByName, t4.Name AS ROLE_NAME");
        $this->db->from('ProsesKreditLog t1');
        $this->db->join('User t2', 't1.CreatedBy = t2.UserId ', 'left');
        $this->db->join('Role t4', 't1.StatusApplicationId = t4.RoleId ', 'left');
        $this->db->where($where);
        $this->db->order_by('t1.CreatedDate','DESC');
        $result = $this->db->get()->result();
        return $result;
    }

    function updateStatusProsesKredit($data){
        $prosesKreditId = $data['prosesKreditId'];
        $isApproved = $data['isApproved'];
        $statusApplicationId = $data['tujuanId'];
        $comment = $data['comment'];
        $putusanId = $data['putusanId'];
        $userId = $data['userId'];
        $divisionId = $data['divisionId'];
        $roleId = $data['roleId'];
        
        $isCommit = 1;
        $this->db->trans_begin();

        if($roleId == 14 && $putusanId != 0){
            $prosesKredit = array(
                'StatusApplicationId' => $statusApplicationId,
                'StatusPutusan' => $putusanId,
                'TanggalPutusan' => $this->currentDateTime,
                'ModifiedBy' => $userId,
                'ModifiedDate' => $this->currentDateTime
            );
        }else{
            $prosesKredit = array(
                'StatusApplicationId' => $statusApplicationId,
                'ModifiedBy' => $userId,
                'ModifiedDate' => $this->currentDateTime
            );
        }
        
        $where = array(
            'prosesKreditId' => $prosesKreditId
        );
        $result = $this->db->update('ProsesKredit', $prosesKredit, $where);
        if($result != 1){
            $isCommit = 0;
        }else{
            if($this->addLogProsesKredit($prosesKreditId, $isApproved, $statusApplicationId, $comment, $userId)){
                switch($isApproved){
                    case 0:
                        $comment = 'Pengembalian Paket Kredit'; break;
                    case 1:
                        $comment = 'Pengiriman Paket Kredit'; break;
                    default: break;
                }
                switch($statusApplicationId){
                    case 12: 
                        $statusApplicationUserId = $this->getProsesKreditMaker($prosesKreditId);
                        $this->notification_model->addNotif($statusApplicationUserId, "Monitoring Proses Kredit", $comment, "", "monitoring/proseskredit/detail/".$prosesKreditId); 
                        if ($this->db->trans_status() === FALSE){
                            $isCommit = 0;
                        }
                        break;
                    default : 
                        $rsUser = $this->getUserInformation($statusApplicationId, $divisionId);
                        foreach($rsUser as $row){
                            $this->notification_model->addNotif($row->id, "Monitoring Proses Kredit", $comment, "", "monitoring/proseskredit/detail/".$prosesKreditId); 
                            if ($this->db->trans_status() === FALSE){
                                $isCommit = 0;
                            }
                        }
                        break;
                }
                
            }else $isCommit = 0;                  
        }

        if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
			$this->db->trans_commit();
			return 1;
		}
    }

    function multipleCommentProsesKredit($data){
        $isCommit = 1;
        $this->db->trans_begin();
        foreach($data['arrProsesKreditId'] as $row){
            $isApproved = NULL;
            $statusApplicationId = NULL;
            $comment = $data['comment'];
            $userId = $data['userId'];
            $result = $this->addLogProsesKredit($row, $isApproved, $statusApplicationId, $comment, $userId);
            if(!$result) {
                $isCommit = 0; 
                break;
            }else{
                $RM = $this->getProsesKreditMaker($row);
                $comment = "Komentar Proses Kredit";
                $this->notification_model->addNotif($RM, "Monitoring Proses Kredit", $comment, "", "monitoring/proseskredit/detail/".$row);                
            }
        }
        if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
			$this->db->trans_commit();
			return 1;
		}
    }

    function prosesAkadKredit($data){
        $userId = $data['userId'];
        $prosesKreditId = $data['prosesKreditId'];
        $tanggalAkad = $data['tanggalAkad'];
        $notarisName = $data['notarisName'];
        $desc = $data['desc'];
        $isCommit = 1;
        $this->db->trans_begin();
        $prosesKredit = array(
            'IsAkad' => 1,
            'TanggalAkad' => $tanggalAkad,
            'NamaNotaris' => $notarisName,
            'Keterangan' => $desc,
            'ModifiedBy' => $userId,
            'ModifiedDate' => $this->currentDateTime
        );        
        $where = array(
            'prosesKreditId' => $prosesKreditId
        );
        $result = $this->db->update('ProsesKredit', $prosesKredit, $where);
        if($isCommit == 0){
			$this->db->trans_rollback();
			return 0;
		}else{
			$this->db->trans_commit();
			return 1;
		}
    }

    function addLogProsesKredit($prosesKreditId, $isApproved, $statusApplicationId, $comment, $createdBy){
        $data = array(
            'ProsesKreditId' => $prosesKreditId,
            'IsApproved' => $isApproved,
            'StatusApplicationId' => $statusApplicationId,
            'Comment' => $comment,
            'CreatedBy' => $createdBy,
            'CreatedDate' => $this->currentDateTime
        );        
        $this->db->insert('ProsesKreditLog', $data);
        if ($this->db->trans_status() === FALSE){
            return 0;
        }else return 1;
    }

    function getTujuanProsesKreditOption($arrRole = null){
        $this->db->select('RoleId AS ID, Name AS ROLE_NAME');
        $this->db->from('Role');
        $this->db->where('IsActive', 1);
        if($arrRole != null){
            $countRole = count($arrRole);
            if($countRole == 1){
                $this->db->where('RoleId', $arrRole[0]);
            }else{
                $this->db->where_in('RoleId', $arrRole);
            }
        }
        $this->db->order_by('ROLE_NAME','ASC');
        $result = $this->db->get()->result();
        return $result;
    }

    function getUserInformation($roleId, $divisionId = null){
        if ($divisionId == null){
            $where = array(
                'RoleId' => $roleId,
                'IsActive' => 1
            );
        }else{
            $where = array(
                'UnitKerjaId' => $divisionId,
                'RoleId' => $roleId,
                'IsActive' => 1
            );
        }
        $this->db->select('UserId AS id, UnitKerjaId AS role_id, Name');
        $this->db->from('User');
        $this->db->where($where);
        $result = $this->db->get()->result();
        return $result;
    }

    function getProsesKreditMaker($prosesKreditId){
        $this->db->select('CreatedBy');
        $this->db->from('ProsesKredit');
        $this->db->where('ProsesKreditId',$prosesKreditId);
        $result = $this->db->get()->result();
        return $result[0]->CreatedBy;
    }

    
}
?>