<?php

class TasklistMyTask_model extends CI_Model {

    function __construct() {
        parent::__construct();

        $current_datetime = new DateTime(date('Y-m-d H:i:s'));
        $this->current_year = $current_datetime->format('Y');
        $this->current_date = $current_datetime->format('Y-m-d');
        $this->current_datetime = $current_datetime->format('Y-m-d H:i:s');
    }

    public function getSummaryCustomer($VCIF) {
        $sql = 'SELECT "a"."VCIF", "a"."PinjamanTotal", "a"."PinjamanRatas", "a"."SimpananTotal", "a"."SimpananRatas", "a"."CurrentCPA", "a"."ValueChain" 
                FROM "Summary_SimpanPinjamCustomerVCIF" "a"
                WHERE "a"."VCIF" = \''. $VCIF.'\'';

        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getTotalViewGroupList($UserId, $searchTxt='') {
        $sql = '
            SELECT COUNT(*) AS "numrows" 
            FROM "DisposisiCustomerGroup" "a" 
            WHERE IsActive=1 AND UserId = \''.$UserId.'\' 
        ';

        if (!empty($searchTxt)) {
            $sql .= " AND (
                CustomerGroupId IN (
                    SELECT CustomerGroupId
                    FROM CustomerGroup
                    WHERE Name LIKE '%".$searchTxt."%'
                )
                OR CustomerGroupId IN (
                    SELECT CustomerGroupId
                    FROM CustomerKorporasi
                    WHERE Name LIKE '%".$searchTxt."%'
                )
            ) ";
        }

        $result = $this->db->query($sql)->result_array();  

        return $result[0]['numrows'];
    }

    public function getViewGroupList($UserId, $rowperpage, $rowno, $searchTxt='') {

        $sql = '
            SELECT 
            "a"."CustomerGroupId", "a"."UserId", 
            "b"."Name" AS "CustomerGroupName", b.[Logo]
            FROM DisposisiCustomerGroup a
            JOIN "CustomerGroup" "b" ON "a"."CustomerGroupId"="b"."CustomerGroupId"
            WHERE "a"."IsActive"=1 AND "a"."UserId" = \''.$UserId.'\' 
        ';

        if (!empty($searchTxt)) {
            $sql .= " AND (b.Name LIKE '%".$searchTxt."%' 
                OR a.CustomerGroupId IN (
                    SELECT CustomerGroupId
                    FROM CustomerKorporasi
                    WHERE Name LIKE '%".$searchTxt."%'
                )
            ) ";
        }

        $sql .= ' ORDER BY StartDate DESC OFFSET '.$rowno.' ROWS FETCH NEXT '.$rowperpage.' ROWS ONLY';
        $result = $this->db->query($sql)->result_array();  

        return $result;
    }

    public function getAccountPlanningId() {
        $sql = "
            SELECT SCOPE_IDENTITY() AS AccountPlanningId;
        ";

        $result = $this->db->query($sql)->result_array();   

        return $result[0]['AccountPlanningId'];
   }
    public function insertAccountPlanning($year, $userId) {

        $sql = "INSERT INTO AccountPlanning(Year, CreatedDate, CreatedBy)
            VALUES('".$year."', SYSDATETIME(), '".$userId."')";
        $this->db->query($sql);
        $sql = "SELECT SCOPE_IDENTITY() AS AccountPlanningId";
        $result = $this->db->query($sql)->result_array();  
        $apId = $result[0]['AccountPlanningId'];
        //$this->db->trans_complete();

         $data = array(
            'AccountPlanningId'       => $apId, 
            'UserId'                => $userId
        );

        $query = $this->db->query('transAccountPlanningOwnerCreate ?,?',$data);
        $error = $this->db->error();

        if($error['code']<>0) {
            $result = array(
                'status' => 'error',
                'message'=> $error['message']
            );
        } else {
            $result = array(
                'status' => 'success',
                'message'=> $apId
            );
        }

         return $result;
    }

    public function insertCustomerAP($data) {

        foreach ($data as $key => $value) {
            $query = $this->db->query('transAccountPlanningAddCustomer ?,?,?,?,?',$value);
            $error = $this->db->error();
            //print_r($error); die();
            if($error['code']<>0) {
                $result = array(
                    'status' => 'error',
                    'message'=> $error['message']
                );
                break;
            } else {
                $result = array(
                    'status' => 'success'
                );
            }
        }

        return $result;

    }
}
