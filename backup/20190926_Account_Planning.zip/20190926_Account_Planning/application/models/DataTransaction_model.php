<?php

class DataTransaction_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $today = new DateTime(date('Y-m-d H:i:s'));
        $this->year_current = $today->format('Y');
        $this->todays = $today->format('Y-m-d H:i:s');
    }

    public function getPinjamanLastUpdateDate(){
        $sql = "SELECT FORMAT(MAX(Period),'dd MMMM yyyy') LastUpdateDate FROM(
            SELECT max(Period) Period
            FROM Summary_LastPinjamanCifDaily
            UNION ALL 
            SELECT max(Period) Period
            FROM Summary_LastPinjamanCifMonthly
        ) A";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getSimpananLastUpdateDate(){
        $sql = "SELECT FORMAT(MAX(Period),'dd MMMM yyyy') LastUpdateDate FROM(
            SELECT max(Period) Period
            FROM Summary_LastSimpananCifDaily
            UNION ALL 
            SELECT max(Period) Period
            FROM Summary_LastSimpananCifMonthly
        ) A";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getCpaLastUpdateDate(){
        $sql = "SELECT FORMAT(MAX(Period),'dd MMMM yyyy') LastUpdateDate 
            FROM Summary_LastCpaCif";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataPinjamanGroup($groupId){
        $sql = "SELECT *FROM 
            (
                SELECT ISNULL(SUM(BakiDebet),0) TotalPinjaman
                FROM Summary_LastPinjamanCifDaily
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerGroup A, CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE A.CustomerGroupId=B.CustomerGroupId
                        AND B.VCIF=C.VCIF
                        AND A.CustomerGroupId=".$groupId."
                )
            ) A,
            (
                SELECT ISNULL(AVG(BakiDebetRatas),0) RatasPinjaman
                FROM Summary_LastPinjamanCifMonthly
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerGroup A, CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE A.CustomerGroupId=B.CustomerGroupId
                        AND B.VCIF=C.VCIF
                        AND A.CustomerGroupId=".$groupId."
                )
            ) B";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataSimpananGroup($groupId){
        $sql = "SELECT *FROM 
            (
                SELECT ISNULL(SUM(Saldo),0) TotalSimpanan
                FROM Summary_LastSimpananCifDaily
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerGroup A, CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE A.CustomerGroupId=B.CustomerGroupId
                        AND B.VCIF=C.VCIF
                        AND A.CustomerGroupId=".$groupId."
                )
            ) A,
            (
                SELECT ISNULL(AVG(AverageSaldo),0) RatasSimpanan
                FROM Summary_LastSimpananCifMonthly
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerGroup A, CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE A.CustomerGroupId=B.CustomerGroupId
                        AND B.VCIF=C.VCIF
                        AND A.CustomerGroupId=".$groupId."
                )
            ) B";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataCpaGroup($groupId){
        $sql = "SELECT ISNULL(SUM(Cpa),0) Cpa
            FROM Summary_LastCpaCif
            WHERE Cif IN(
                SELECT C.CIF
                FROM CustomerGroup A, CustomerKorporasi B, DetailCustomerKorporasi C
                WHERE A.CustomerGroupId=B.CustomerGroupId
                    AND B.VCIF=C.VCIF
                    AND A.CustomerGroupId=".$groupId."
            )";
        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataPinjamanVcif($Vcif){
        $sql = "SELECT *FROM 
            (
                SELECT ISNULL(SUM(BakiDebet),0) TotalPinjaman
                FROM Summary_LastPinjamanCifDaily
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE B.VCIF=C.VCIF
                        AND B.VCIF='".$Vcif."'
                )
            ) A,
            (
                SELECT ISNULL(AVG(BakiDebetRatas),0) RatasPinjaman
                FROM Summary_LastPinjamanCifMonthly
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE B.VCIF=C.VCIF
                        AND B.VCIF='".$Vcif."'
                )
            ) B";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataSimpananVcif($Vcif){
        $sql = "SELECT *FROM 
            (
                SELECT ISNULL(SUM(Saldo),0) TotalSimpanan
                FROM Summary_LastSimpananCifDaily
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE B.VCIF=C.VCIF
                        AND B.VCIF='".$Vcif."'
                )
            ) A,
            (
                SELECT ISNULL(AVG(AverageSaldo),0) RatasSimpanan
                FROM Summary_LastSimpananCifMonthly
                WHERE Cif IN(
                    SELECT C.CIF
                    FROM CustomerKorporasi B, DetailCustomerKorporasi C
                    WHERE B.VCIF=C.VCIF
                        AND B.VCIF='".$Vcif."'
                )
            ) B";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataCpaVcif($Vcif){
        $sql = "SELECT ISNULL(SUM(Cpa),0) Cpa
            FROM Summary_LastCpaCif
            WHERE Cif IN(
                SELECT C.CIF
                FROM CustomerKorporasi B, DetailCustomerKorporasi C
                WHERE B.VCIF=C.VCIF
                    AND B.VCIF='".$Vcif."'
            )";
        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataSimpananAccountPlanning($accountPlanningId){
    	$sql = "
    		SELECT *FROM 
			(
			    SELECT ISNULL(SUM(Saldo),0) TotalSimpanan
			    FROM Summary_LastSimpananCifDaily
			    WHERE Cif IN(
			        SELECT B.CIF
					FROM AccountPlanningCustomer A, DetailCustomerKorporasi B
					WHERE A.VCIF=B.VCIF 
						AND AccountPlanningId=".$accountPlanningId."
			    )
			) A,
			(
			    SELECT ISNULL(AVG(AverageSaldo),0) RatasSimpanan
			    FROM Summary_LastSimpananCifMonthly
			    WHERE Cif IN(
			        SELECT B.CIF
					FROM AccountPlanningCustomer A, DetailCustomerKorporasi B
					WHERE A.VCIF=B.VCIF 
						AND AccountPlanningId=".$accountPlanningId."
			    )
			) B
    	";
    	$result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataPinjamanAccountPlanning($accountPlanningId){
        $sql = "SELECT *FROM 
            (
                SELECT ISNULL(SUM(BakiDebet),0) TotalPinjaman
                FROM Summary_LastPinjamanCifDaily
                WHERE Cif IN(
                    SELECT B.CIF
					FROM AccountPlanningCustomer A, DetailCustomerKorporasi B
					WHERE A.VCIF=B.VCIF 
						AND AccountPlanningId=".$accountPlanningId."
                )
            ) A,
            (
                SELECT ISNULL(AVG(BakiDebetRatas),0) RatasPinjaman
                FROM Summary_LastPinjamanCifMonthly
                WHERE Cif IN(
                    SELECT B.CIF
					FROM AccountPlanningCustomer A, DetailCustomerKorporasi B
					WHERE A.VCIF=B.VCIF 
						AND AccountPlanningId=".$accountPlanningId."
                )
            ) B";

        $result = $this->db->query($sql);

        return $result->row_array();
    }

    public function getDataCpaAccountPlanning($accountPlanningId){
        $sql = "SELECT ISNULL(SUM(Cpa),0) Cpa
            FROM Summary_LastCpaCif
            WHERE Cif IN(
                SELECT B.CIF
					FROM AccountPlanningCustomer A, DetailCustomerKorporasi B
					WHERE A.VCIF=B.VCIF 
						AND AccountPlanningId=".$accountPlanningId."
            )";
        $result = $this->db->query($sql);

        return $result->row_array();
    }

}

?>